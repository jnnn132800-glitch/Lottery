import fs from 'fs';
import path from 'path';
import {
  ConfigRule,
  Transaction,
  CustomerProfile,
  ArchivedDraw,
  BillPaymentRecord,
  AuditLogEntry,
  AuditActionType,
  DataIntegrityReport,
  SystemBackupPayload,
} from '../types/lottery';
import {
  INITIAL_CONFIG_SETTINGS,
  INITIAL_TRANSACTIONS,
  INITIAL_CUSTOMERS,
} from '../data/initialData';
import {
  normalizeLotteryNumber,
  isValidLotteryNumber,
  findConfigRule,
  evaluateNumberRisk,
  reconcileTransactionsRisk,
  editBillTransactions,
  EditableBillItem,
  getCurrentThaiTimestamp,
  getNextBillId,
  validateSystemDataIntegrity,
  createSystemBackupPayload,
  verifySystemBackupPayload,
} from '../utils/lotteryLogic';

export interface ServerDatabaseState {
  configs: ConfigRule[];
  transactions: Transaction[];
  customers: CustomerProfile[];
  archivedDraws: ArchivedDraw[];
  paymentRecords: Record<string, BillPaymentRecord>;
  auditLogs: AuditLogEntry[];
  processedIdempotencyKeys: Record<string, { billId: string; timestamp: string }>;
  isMarketOpen: boolean;
  isPeriodLocked: boolean;
  currentDrawPeriod: string;
}

export class LotteryServerEngine {
  private dbFilePath: string;
  private backupDirPath: string;
  private state: ServerDatabaseState;
  private writeQueue: Promise<unknown> = Promise.resolve();

  constructor(customDbPath?: string) {
    this.dbFilePath = customDbPath || path.resolve(process.cwd(), 'data', 'lottery_db.json');
    this.backupDirPath = path.resolve(path.dirname(this.dbFilePath), 'backups');
    this.state = this.loadFromDisk();
  }

  private ensureDirectories(): void {
    const dir = path.dirname(this.dbFilePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(this.backupDirPath)) {
      fs.mkdirSync(this.backupDirPath, { recursive: true });
    }
  }

  private getInitialState(): ServerDatabaseState {
    return {
      configs: structuredClone(INITIAL_CONFIG_SETTINGS),
      transactions: structuredClone(INITIAL_TRANSACTIONS),
      customers: structuredClone(INITIAL_CUSTOMERS),
      archivedDraws: [],
      paymentRecords: {},
      auditLogs: [
        {
          id: `AUD_INIT_${Date.now()}`,
          timestamp: getCurrentThaiTimestamp(),
          action: 'UPSERT_CONFIG',
          actor: 'SYSTEM',
          targetId: 'INITIAL_DB',
          summary: 'เริ่มต้นฐานข้อมูลหลัก (Server Authoritative Storage)',
        },
      ],
      processedIdempotencyKeys: {},
      isMarketOpen: true,
      isPeriodLocked: false,
      currentDrawPeriod: 'งวด 16 พ.ย. 2569',
    };
  }

  private loadFromDisk(): ServerDatabaseState {
    try {
      this.ensureDirectories();
      if (fs.existsSync(this.dbFilePath)) {
        const raw = fs.readFileSync(this.dbFilePath, 'utf-8');
        const parsed = JSON.parse(raw) as Partial<ServerDatabaseState>;
        if (Array.isArray(parsed.configs) && Array.isArray(parsed.transactions)) {
          return {
            configs: parsed.configs,
            transactions: parsed.transactions,
            customers: Array.isArray(parsed.customers) ? parsed.customers : structuredClone(INITIAL_CUSTOMERS),
            archivedDraws: Array.isArray(parsed.archivedDraws) ? parsed.archivedDraws : [],
            paymentRecords: parsed.paymentRecords || {},
            auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
            processedIdempotencyKeys: parsed.processedIdempotencyKeys || {},
            isMarketOpen: parsed.isMarketOpen ?? true,
            isPeriodLocked: parsed.isPeriodLocked ?? false,
            currentDrawPeriod: parsed.currentDrawPeriod || 'งวด 16 พ.ย. 2569',
          };
        }
      }
    } catch (err) {
      console.error('[LotteryServerEngine] Failed to load DB, initializing fresh state:', err);
    }
    const initial = this.getInitialState();
    this.saveToDiskSync(initial);
    return initial;
  }

  private saveToDiskSync(stateToSave: ServerDatabaseState): void {
    try {
      this.ensureDirectories();
      const tempPath = `${this.dbFilePath}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(stateToSave, null, 2), 'utf-8');
      fs.renameSync(tempPath, this.dbFilePath);
    } catch (err) {
      console.error('[LotteryServerEngine] Failed to persist DB:', err);
    }
  }

  /**
   * Serializes concurrent mutations using a Promise mutex lock to prevent Race Conditions
   */
  public withWriteLock<T>(operation: () => Promise<T> | T): Promise<T> {
    const next = this.writeQueue.then(() => operation());
    this.writeQueue = next.catch(() => undefined);
    return next;
  }

  private appendAuditLog(params: {
    action: AuditActionType;
    actor?: string;
    targetId: string;
    summary: string;
    idempotencyKey?: string;
    metadata?: Record<string, unknown>;
  }): AuditLogEntry {
    const entry: AuditLogEntry = {
      id: `AUD_${Date.now()}_${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
      timestamp: getCurrentThaiTimestamp(),
      action: params.action,
      actor: params.actor || 'POS_OPERATOR',
      targetId: params.targetId,
      summary: params.summary,
      idempotencyKey: params.idempotencyKey,
      metadata: params.metadata,
    };
    this.state.auditLogs = [entry, ...this.state.auditLogs].slice(0, 500);
    return entry;
  }

  public getStateSnapshot(): {
    state: ServerDatabaseState;
    integrity: DataIntegrityReport;
    gasConfigured: boolean;
  } {
    const integrity = validateSystemDataIntegrity({
      configs: this.state.configs,
      transactions: this.state.transactions,
      customers: this.state.customers,
      archivedDraws: this.state.archivedDraws,
    });
    return {
      state: structuredClone(this.state),
      integrity,
      gasConfigured: Boolean(process.env.GAS_WEBAPP_URL),
    };
  }

  /**
   * Forward payload to Google Apps Script Web App if configured in server environment
   * (No API key/secret is ever exposed to the frontend)
   */
  private async forwardToGoogleSheets(action: string, payload: unknown): Promise<void> {
    const gasUrl = process.env.GAS_WEBAPP_URL;
    if (!gasUrl) return;
    try {
      await fetch(gasUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          secret: process.env.GAS_API_SECRET || '',
          payload,
        }),
      });
    } catch (err) {
      console.warn('[GAS Forward] Warning: could not sync to Google Sheets:', err);
    }
  }

  /**
   * Server-side Bill Creation with:
   * - Market Open & Period Lock check
   * - Idempotency Key duplicate guard
   * - Strict number format & 'ปิดรับ' validation
   * - Authoritative risk split & historical payoutRate snapshot
   * - Audit Log recording
   */
  public async createBill(input: {
    idempotencyKey: string;
    billId?: string;
    customerName: string;
    discountPercent?: number;
    drawPeriod?: string;
    items: Array<{ type: string; number: string; amount: number }>;
    actor?: string;
  }): Promise<{
    success: boolean;
    duplicate?: boolean;
    error?: string;
    billId?: string;
    createdTransactions?: Transaction[];
    transactions?: Transaction[];
    auditEntry?: AuditLogEntry;
  }> {
    return this.withWriteLock(async () => {
      if (!input.idempotencyKey || typeof input.idempotencyKey !== 'string') {
        return { success: false, error: 'ต้องระบุ Idempotency Key เพื่อป้องกันการส่งบิลซ้ำ' };
      }

      // 1. Check Idempotency Key (Prevent duplicate bill submission)
      const existingIdem = this.state.processedIdempotencyKeys[input.idempotencyKey];
      if (existingIdem) {
        const existingBillRows = this.state.transactions.filter(
          (t) => t.billId === existingIdem.billId
        );
        return {
          success: true,
          duplicate: true,
          billId: existingIdem.billId,
          createdTransactions: existingBillRows,
          transactions: structuredClone(this.state.transactions),
        };
      }

      // 2. Check Period Lock and Market Status
      if (this.state.isPeriodLocked) {
        return {
          success: false,
          error: 'งวดนี้ถูกปิดและล็อกข้อมูลแล้ว ห้ามบันทึกรายการเพิ่มโดยไม่ได้รับอนุญาต',
        };
      }
      if (!this.state.isMarketOpen) {
        return {
          success: false,
          error: 'ขณะนี้ระบบปิดรับแทงชั่วคราว ไม่สามารถบันทึกบิลได้',
        };
      }

      if (!Array.isArray(input.items) || input.items.length === 0) {
        return { success: false, error: 'ไม่มีรายการตัวเลขในบิล' };
      }

      // 3. Validate each item on Server before committing
      const validatedItems: Array<{ type: string; number: string; amount: number }> = [];
      for (let i = 0; i < input.items.length; i++) {
        const raw = input.items[i];
        const rawNumStr = String(raw.number ?? '').trim();
        if (!isValidLotteryNumber(rawNumStr, raw.type)) {
          return {
            success: false,
            error: `รายการที่ ${i + 1}: เลข "${raw.number}" ไม่ถูกต้องสำหรับประเภท ${raw.type}`,
          };
        }
        const normNum = normalizeLotteryNumber(rawNumStr, String(raw.type ?? ''));
        const amt = Number(raw.amount) || 0;
        if (amt <= 0) {
          return {
            success: false,
            error: `รายการที่ ${i + 1}: จำนวนเงินต้องมากกว่า 0 บาท`,
          };
        }
        const rule = findConfigRule(raw.type, normNum, this.state.configs);
        if (rule.status === 'ปิดรับ' || rule.maxRisk <= 0) {
          return {
            success: false,
            error: `เลข ${normNum} (${raw.type}) อยู่ในสถานะปิดรับแทง ไม่สามารถบันทึกบิลได้`,
          };
        }
        validatedItems.push({ type: raw.type, number: normNum, amount: amt });
      }

      // 4. Authoritative Server-side Risk & Historical Payout Calculation
      const billId = input.billId && !this.state.transactions.some((t) => t.billId === input.billId)
        ? input.billId
        : getNextBillId(this.state.transactions);
      const nowStr = getCurrentThaiTimestamp();
      const customerName = (input.customerName || 'ลูกค้าทั่วไป').trim() || 'ลูกค้าทั่วไป';
      const discountPercent = Math.max(0, Math.min(50, Number(input.discountPercent) || 0));
      const drawPeriod = input.drawPeriod || this.state.currentDrawPeriod;

      const workingTransactions = [...this.state.transactions];
      const createdTransactions: Transaction[] = [];

      validatedItems.forEach((item, idx) => {
        const calc = evaluateNumberRisk(
          item.type,
          item.number,
          item.amount,
          this.state.configs,
          workingTransactions,
          []
        );
        const tx: Transaction = {
          id: `TX_${billId}_${Date.now()}_${idx + 1}`,
          idempotencyKey: input.idempotencyKey,
          timestamp: nowStr,
          billId,
          customerName,
          type: item.type,
          number: item.number,
          amount: item.amount,
          payoutRate: calc.payoutRate,
          status: calc.status,
          sentAmount: calc.sentAmount,
          keepAmount: calc.keepAmount,
          discountPercent,
          drawPeriod,
        };
        workingTransactions.push(tx);
        createdTransactions.push(tx);
      });

      this.state.transactions = workingTransactions;
      this.state.processedIdempotencyKeys[input.idempotencyKey] = {
        billId,
        timestamp: nowStr,
      };

      const totalBillAmount = createdTransactions.reduce((s, t) => s + t.amount, 0);
      const auditEntry = this.appendAuditLog({
        action: 'CREATE_BILL',
        actor: input.actor || customerName,
        targetId: billId,
        summary: `บันทึกบิล ${billId} ลูกค้า "${customerName}" จำนวน ${createdTransactions.length} รายการ ยอดรวม ${totalBillAmount.toLocaleString()} ฿`,
        idempotencyKey: input.idempotencyKey,
        metadata: {
          billId,
          customerName,
          itemsCount: createdTransactions.length,
          totalBillAmount,
        },
      });

      this.saveToDiskSync(this.state);
      void this.forwardToGoogleSheets('CREATE_BILL', { billId, createdTransactions });

      return {
        success: true,
        duplicate: false,
        billId,
        createdTransactions,
        transactions: structuredClone(this.state.transactions),
        auditEntry,
      };
    });
  }

  /**
   * Server-side Bill Edit with Risk Reconciliation & Audit Log
   */
  public async editBill(input: {
    billId: string;
    customerName: string;
    discountPercent: number;
    items: EditableBillItem[];
    actor?: string;
  }): Promise<{
    success: boolean;
    error?: string;
    transactions?: Transaction[];
    auditEntry?: AuditLogEntry;
  }> {
    return this.withWriteLock(async () => {
      if (this.state.isPeriodLocked) {
        return {
          success: false,
          error: 'งวดนี้ถูกปิดและล็อกข้อมูลแล้ว ห้ามแก้ไขบิลโดยไม่ได้รับอนุญาต',
        };
      }

      const result = editBillTransactions(
        this.state.transactions,
        input.billId,
        { customerName: input.customerName, discountPercent: input.discountPercent },
        input.items,
        this.state.configs
      );

      if (!result.success) {
        return { success: false, error: result.error };
      }

      this.state.transactions = result.transactions;
      const updatedRows = this.state.transactions.filter((t) => t.billId === input.billId);
      const newTotal = updatedRows.reduce((s, t) => s + t.amount, 0);

      const auditEntry = this.appendAuditLog({
        action: 'EDIT_BILL',
        actor: input.actor || 'POS_OPERATOR',
        targetId: input.billId,
        summary: `แก้ไขบิล ${input.billId} (${input.customerName}) คงเหลือ ${updatedRows.length} รายการ ยอดรวมใหม่ ${newTotal.toLocaleString()} ฿ พร้อมคำนวณเพดานความเสี่ยงใหม่`,
      });

      this.saveToDiskSync(this.state);
      void this.forwardToGoogleSheets('EDIT_BILL', { billId: input.billId, updatedRows });

      return {
        success: true,
        transactions: structuredClone(this.state.transactions),
        auditEntry,
      };
    });
  }

  /**
   * Server-side Bill Deletion / Cancellation with Risk Reconciliation & Audit Log
   */
  public async deleteBill(
    billId: string,
    actor = 'POS_OPERATOR'
  ): Promise<{
    success: boolean;
    error?: string;
    transactions?: Transaction[];
    auditEntry?: AuditLogEntry;
  }> {
    return this.withWriteLock(async () => {
      if (this.state.isPeriodLocked) {
        return {
          success: false,
          error: 'งวดนี้ถูกปิดและล็อกข้อมูลแล้ว ห้ามยกเลิกบิลโดยไม่ได้รับอนุญาต',
        };
      }

      const targetRows = this.state.transactions.filter((t) => t.billId === billId);
      if (targetRows.length === 0) {
        return { success: false, error: `ไม่พบบิล ${billId} ในระบบ` };
      }

      const remaining = this.state.transactions.filter((t) => t.billId !== billId);
      this.state.transactions = reconcileTransactionsRisk(remaining, this.state.configs);

      const canceledAmount = targetRows.reduce((s, t) => s + t.amount, 0);
      const auditEntry = this.appendAuditLog({
        action: 'DELETE_BILL',
        actor,
        targetId: billId,
        summary: `ยกเลิกบิล ${billId} (${targetRows[0]?.customerName || '-'}) จำนวน ${targetRows.length} รายการ ยอด ${canceledAmount.toLocaleString()} ฿ และคืนเพดานความเสี่ยง`,
      });

      this.saveToDiskSync(this.state);
      void this.forwardToGoogleSheets('DELETE_BILL', { billId });

      return {
        success: true,
        transactions: structuredClone(this.state.transactions),
        auditEntry,
      };
    });
  }

  /**
   * Server-side Config Update (Upsert / Delete / Reset)
   */
  public async updateConfigs(input: {
    action: 'upsert' | 'delete' | 'reset';
    rule?: ConfigRule;
    type?: string;
    number?: string;
  }): Promise<{
    success: boolean;
    error?: string;
    configs?: ConfigRule[];
    auditEntry?: AuditLogEntry;
  }> {
    return this.withWriteLock(async () => {
      if (input.action === 'reset') {
        this.state.configs = structuredClone(INITIAL_CONFIG_SETTINGS);
        const auditEntry = this.appendAuditLog({
          action: 'RESET_CONFIGS',
          targetId: 'ALL_CONFIGS',
          summary: 'รีเซ็ตตารางเรทจ่ายและเพดานความเสี่ยงกลับเป็นค่าเริ่มต้น',
        });
        this.saveToDiskSync(this.state);
        return { success: true, configs: structuredClone(this.state.configs), auditEntry };
      }

      if (input.action === 'delete' && input.type && input.number) {
        if (input.number === '*') {
          return { success: false, error: 'ไม่สามารถลบเรทพื้นฐาน (*) ได้' };
        }
        this.state.configs = this.state.configs.filter(
          (c) => !(c.type === input.type && c.number === input.number)
        );
        const auditEntry = this.appendAuditLog({
          action: 'DELETE_CONFIG',
          targetId: `${input.type}:${input.number}`,
          summary: `ลบกฎความเสี่ยงเฉพาะเลข ${input.type} [${input.number}]`,
        });
        this.saveToDiskSync(this.state);
        return { success: true, configs: structuredClone(this.state.configs), auditEntry };
      }

      if (input.action === 'upsert' && input.rule) {
        const rule = input.rule;
        const cleanNumber =
          rule.number.trim() === '*'
            ? '*'
            : normalizeLotteryNumber(rule.number, rule.type);

        if (cleanNumber !== '*' && !isValidLotteryNumber(cleanNumber, rule.type)) {
          return {
            success: false,
            error: `เลข "${rule.number}" ไม่ถูกต้องสำหรับประเภท ${rule.type}`,
          };
        }

        const sanitizedRule: ConfigRule = {
          type: rule.type,
          number: cleanNumber,
          payoutRate: Math.max(0, Number(rule.payoutRate) || 0),
          maxRisk: Math.max(0, Number(rule.maxRisk) || 0),
          status: rule.status,
        };

        const idx = this.state.configs.findIndex(
          (c) => c.type === sanitizedRule.type && c.number === sanitizedRule.number
        );
        if (idx >= 0) {
          this.state.configs[idx] = sanitizedRule;
        } else {
          this.state.configs.push(sanitizedRule);
        }

        const auditEntry = this.appendAuditLog({
          action: 'UPSERT_CONFIG',
          targetId: `${sanitizedRule.type}:${sanitizedRule.number}`,
          summary: `ตั้งค่า ${sanitizedRule.type} เลข [${sanitizedRule.number}] เรทจ่าย ${sanitizedRule.payoutRate} เพดาน ${sanitizedRule.maxRisk.toLocaleString()} (${sanitizedRule.status})`,
        });
        this.saveToDiskSync(this.state);
        return { success: true, configs: structuredClone(this.state.configs), auditEntry };
      }

      return { success: false, error: 'พารามิเตอร์สำหรับการตั้งค่าไม่ถูกต้อง' };
    });
  }

  /**
   * Sync Auxiliary State (Customers, Archived Draws, Payment Records, Market/Lock Status)
   */
  public async syncMetadata(input: {
    customers?: CustomerProfile[];
    archivedDraws?: ArchivedDraw[];
    paymentRecords?: Record<string, BillPaymentRecord>;
    transactions?: Transaction[];
    isMarketOpen?: boolean;
    isPeriodLocked?: boolean;
    currentDrawPeriod?: string;
    auditAction?: AuditActionType;
    auditSummary?: string;
    auditTargetId?: string;
  }): Promise<{
    success: boolean;
    state: ServerDatabaseState;
  }> {
    return this.withWriteLock(async () => {
      if (Array.isArray(input.customers)) {
        this.state.customers = input.customers;
      }
      if (Array.isArray(input.archivedDraws)) {
        this.state.archivedDraws = input.archivedDraws;
      }
      if (input.paymentRecords && typeof input.paymentRecords === 'object') {
        this.state.paymentRecords = input.paymentRecords;
      }
      if (Array.isArray(input.transactions)) {
        this.state.transactions = input.transactions;
      }
      if (typeof input.isMarketOpen === 'boolean') {
        this.state.isMarketOpen = input.isMarketOpen;
      }
      if (typeof input.isPeriodLocked === 'boolean') {
        this.state.isPeriodLocked = input.isPeriodLocked;
      }
      if (typeof input.currentDrawPeriod === 'string' && input.currentDrawPeriod.trim()) {
        this.state.currentDrawPeriod = input.currentDrawPeriod.trim();
      }
      if (input.auditAction && input.auditSummary) {
        this.appendAuditLog({
          action: input.auditAction,
          targetId: input.auditTargetId || 'SYSTEM_STATE',
          summary: input.auditSummary,
        });
      }
      this.saveToDiskSync(this.state);
      return {
        success: true,
        state: structuredClone(this.state),
      };
    });
  }

  /**
   * Export Full System Backup with Checksum
   */
  public exportBackup(): SystemBackupPayload {
    return createSystemBackupPayload({
      configs: this.state.configs,
      transactions: this.state.transactions,
      customers: this.state.customers,
      archivedDraws: this.state.archivedDraws,
      paymentRecords: this.state.paymentRecords,
      auditLogs: this.state.auditLogs,
    });
  }

  /**
   * Verify & Restore System Backup (Automatically saves a pre-restore snapshot on disk first)
   */
  public async restoreBackup(payload: unknown): Promise<{
    success: boolean;
    error?: string;
    preRestoreBackupFile?: string;
    integrityReport?: DataIntegrityReport;
    state?: ServerDatabaseState;
  }> {
    return this.withWriteLock(async () => {
      const verification = verifySystemBackupPayload(payload);
      if (!verification.isValid || !verification.parsed) {
        return {
          success: false,
          error: verification.error || 'ไฟล์สำรองข้อมูลไม่ผ่านการตรวจสอบความถูกต้อง',
          integrityReport: verification.integrityReport,
        };
      }

      // Save pre-restore snapshot before overwriting
      this.ensureDirectories();
      const preRestoreFilename = `pre_restore_${Date.now()}.json`;
      const preRestorePath = path.join(this.backupDirPath, preRestoreFilename);
      fs.writeFileSync(
        preRestorePath,
        JSON.stringify(this.exportBackup(), null, 2),
        'utf-8'
      );

      const { data } = verification.parsed;
      this.state.configs = data.configs;
      this.state.transactions = data.transactions;
      this.state.customers = Array.isArray(data.customers) ? data.customers : [];
      this.state.archivedDraws = Array.isArray(data.archivedDraws) ? data.archivedDraws : [];
      this.state.paymentRecords = data.paymentRecords || {};
      if (Array.isArray(data.auditLogs) && data.auditLogs.length > 0) {
        this.state.auditLogs = data.auditLogs;
      }

      this.appendAuditLog({
        action: 'RESTORE_BACKUP',
        targetId: verification.parsed.checksum,
        summary: `กู้คืนฐานข้อมูลจากไฟล์สำรอง (${verification.parsed.exportedAt}) สำเร็จ [สำรองข้อมูลเดิมไว้ที่ ${preRestoreFilename}]`,
      });

      this.saveToDiskSync(this.state);
      return {
        success: true,
        preRestoreBackupFile: preRestoreFilename,
        integrityReport: verification.integrityReport,
        state: structuredClone(this.state),
      };
    });
  }
}
