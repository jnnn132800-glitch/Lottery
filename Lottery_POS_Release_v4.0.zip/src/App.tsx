/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  LotteryType,
  RiskStatus,
  ConfigRule,
  Transaction,
  SummaryRisk,
  BasketItem,
  ArchivedDraw,
  CustomerProfile,
  InputMode,
  SoundSettings,
  AuditLogEntry,
  SyncStatusType,
} from './types/lottery';
import {
  DEFAULT_SOUND_SETTINGS,
  playBillSavedSound,
  playHalfPayWarningSound,
  playClosedErrorSound,
  playKeyClickSound,
} from './utils/soundEffects';
import {
  INITIAL_CONFIG_SETTINGS,
  INITIAL_TRANSACTIONS,
  INITIAL_SUMMARY_RISK,
  INITIAL_CUSTOMERS,
} from './data/initialData';
import {
  evaluateNumberRisk,
  reverseNumber,
  nineteenDoors,
  swipeFront,
  swipeBack,
  calculateSummaryRisk,
  reconcileTransactionsRisk,
  calculateUnifiedAccountingSummary,
  getTransactionPayoutRate,
  editBillTransactions,
  EditableBillItem,
  parseFastBetText,
  getCurrentThaiTimestamp,
  getNextBillId,
  RiskEvaluationResult,
  validateSystemDataIntegrity,
  createSystemBackupPayload,
  verifySystemBackupPayload,
} from './utils/lotteryLogic';
import {
  fetchServerState,
  flushOfflineQueue,
  getOfflineQueue,
  apiCreateBill,
  apiEditBill,
  apiDeleteBill,
  apiUpdateConfigs,
  apiSyncMetadata,
  apiExportBackup,
  apiRestoreBackup,
} from './utils/apiClient';
import { CODE_GS_SOURCE, INDEX_HTML_SOURCE } from './data/gasSource';
import { Numpad } from './components/Numpad';
import { HalfPayConfirmModal } from './components/HalfPayConfirmModal';
import { SlipReceiptModal } from './components/SlipReceiptModal';
import { TransactionsTable } from './components/TransactionsTable';
import { RiskSummaryView } from './components/RiskSummaryView';
import { ConfigSettingsView } from './components/ConfigSettingsView';
import { GoogleAppsScriptExport } from './components/GoogleAppsScriptExport';
import { ToastNotification, ToastMessage } from './components/ToastNotification';
import { GridSelectorView, GridBetType } from './components/GridSelectorView';
import { ResultSettlementView } from './components/ResultSettlementView';
import { CutoffTimerBanner, CutoffConfig } from './components/CutoffTimerBanner';
import {
  Receipt,
  ShoppingCart,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Ban,
  ArrowLeftRight,
  DoorOpen,
  ArrowRightToLine,
  ArrowLeftToLine,
  User,
  PlusCircle,
  FileSpreadsheet,
  Settings,
  ShieldAlert,
  Smartphone,
  Check,
  Grid3X3,
  Trophy,
  Lock,
  Percent,
  Calendar,
  Volume2,
  VolumeX,
} from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<
    'pos' | 'grid' | 'transactions' | 'risk' | 'settlement' | 'settings' | 'gas'
  >('pos');
  // Default to true so Samsung S22 5G (360x780 / 19.5:9) sizing is active immediately
  const [isMobileFrameView, setIsMobileFrameView] = useState(true);

  // Current Draw Period & Archived Draws History
  const [currentDrawPeriod, setCurrentDrawPeriod] = useState<string>(() => {
    return localStorage.getItem('lottery_current_draw_period') || 'งวดวันที่ 16 พ.ย. 2569';
  });

  const [archivedDraws, setArchivedDraws] = useState<ArchivedDraw[]>(() => {
    const saved = localStorage.getItem('lottery_archived_draws');
    return saved ? JSON.parse(saved) : [];
  });

  const handleUpdateDrawPeriod = (period: string) => {
    setCurrentDrawPeriod(period);
    localStorage.setItem('lottery_current_draw_period', period);
    addToast({
      type: 'success',
      title: '📅 อัปเดตชื่องวดสำเร็จ',
      message: `เปลี่ยนชื่องวดปัจจุบันเป็น "${period}" เรียบร้อยแล้ว`,
    });
  };

  // Notification Sound Settings State
  const [soundSettings, setSoundSettings] = useState<SoundSettings>(() => {
    const saved = localStorage.getItem('lottery_sound_settings');
    if (saved) {
      try {
        return { ...DEFAULT_SOUND_SETTINGS, ...JSON.parse(saved) };
      } catch {
        return DEFAULT_SOUND_SETTINGS;
      }
    }
    return DEFAULT_SOUND_SETTINGS;
  });

  const handleUpdateSoundSettings = (newSettings: SoundSettings) => {
    setSoundSettings(newSettings);
    localStorage.setItem('lottery_sound_settings', JSON.stringify(newSettings));
  };

  // Cutoff Timer & Market Lock State (defaults to enabled: false so users are never auto-locked out in the afternoon/evening unless they turn on the timer or lock manually)
  const [cutoffConfig, setCutoffConfig] = useState<CutoffConfig>(() => {
    const saved = localStorage.getItem('lottery_cutoff_config_v2');
    return saved
      ? JSON.parse(saved)
      : { enabled: false, cutoffTime: '15:30', manualForceClosed: false };
  });

  const handleUpdateCutoffConfig = (newCfg: CutoffConfig) => {
    setCutoffConfig(newCfg);
    localStorage.setItem('lottery_cutoff_config_v2', JSON.stringify(newCfg));
  };

  // Evaluate whether betting market is currently closed
  const isMarketClosed = (() => {
    if (cutoffConfig.manualForceClosed) return true;
    if (!cutoffConfig.enabled) return false;
    const now = new Date();
    const [hh, mm] = cutoffConfig.cutoffTime.split(':').map(Number);
    const target = new Date(now);
    target.setHours(hh || 15, mm || 30, 0, 0);
    return now.getTime() >= target.getTime();
  })();

  // Core State with LocalStorage
  const [configs, setConfigs] = useState<ConfigRule[]>(() => {
    const saved = localStorage.getItem('lottery_configs');
    return saved ? JSON.parse(saved) : INITIAL_CONFIG_SETTINGS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('lottery_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [summaryRisks, setSummaryRisks] = useState<SummaryRisk[]>(() => {
    const saved = localStorage.getItem('lottery_summary_risks');
    return saved ? JSON.parse(saved) : INITIAL_SUMMARY_RISK;
  });

  // Customer Profiles State (หมวด 5: Customer Management)
  const [customers, setCustomers] = useState<CustomerProfile[]>(() => {
    try {
      const saved = localStorage.getItem('lottery_customers');
      return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
    } catch {
      return INITIAL_CUSTOMERS;
    }
  });

  const handleSaveCustomer = (cust: CustomerProfile) => {
    setCustomers((prev) => {
      const exists = prev.some((c) => c.id === cust.id);
      const next = exists
        ? prev.map((c) => (c.id === cust.id ? cust : c))
        : [...prev, cust];
      localStorage.setItem('lottery_customers', JSON.stringify(next));
      return next;
    });
    addToast({
      type: 'success',
      title: '👤 บันทึกข้อมูลลูกค้าสำเร็จ',
      message: `บันทึก "${cust.name}" (ส่วนลดเริ่มต้น ${cust.defaultDiscountPercent}%) เรียบร้อยแล้ว`,
    });
  };

  const handleDeleteCustomer = (id: string) => {
    const target = customers.find((c) => c.id === id);
    if (!target) return;
    setCustomers((prev) => {
      const next = prev.filter((c) => c.id !== id);
      localStorage.setItem('lottery_customers', JSON.stringify(next));
      return next;
    });
    addToast({
      type: 'info',
      title: '🗑️ ลบรายชื่อลูกค้าแล้ว',
      message: `ลบ "${target.name}" ออกจากทะเบียนลูกค้าแล้ว`,
    });
  };

  // Period Closing Lock State (หมวด 8: ข้อมูลงวดที่ปิดแล้วห้ามเปลี่ยนโดยไม่ได้รับอนุญาต)
  const [isPeriodLocked, setIsPeriodLocked] = useState<boolean>(false);
  const [activeDrawBackup, setActiveDrawBackup] = useState<{
    drawPeriod: string;
    transactions: Transaction[];
  } | null>(null);

  // Phase 4: Server Sync Status, Offline Queue Count, Audit Logs & Submission Mutex Lock
  const [syncStatus, setSyncStatus] = useState<SyncStatusType>('synced');
  const [offlineQueueCount, setOfflineQueueCount] = useState<number>(() => getOfflineQueue().length);
  const [isSubmittingBill, setIsSubmittingBill] = useState<boolean>(false);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem('lottery_audit_logs');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const appendLocalAuditLog = (entry: AuditLogEntry) => {
    setAuditLogs((prev) => {
      const next = [entry, ...prev.filter((e) => e.id !== entry.id)].slice(0, 300);
      localStorage.setItem('lottery_audit_logs', JSON.stringify(next));
      return next;
    });
  };

  // Live Data Integrity Report
  const integrityReport = useMemo(
    () =>
      validateSystemDataIntegrity({
        configs,
        transactions,
        customers,
        archivedDraws,
      }),
    [configs, transactions, customers, archivedDraws]
  );

  // Initial Hydrate & Offline Queue Flush with Backend Server
  useEffect(() => {
    let mounted = true;
    const syncWithServer = async () => {
      setSyncStatus('syncing');
      const flushRes = await flushOfflineQueue();
      if (!mounted) return;
      setOfflineQueueCount(flushRes.remainingCount);

      const serverSnap = await fetchServerState();
      if (!mounted) return;
      if (serverSnap && serverSnap.state) {
        if (Array.isArray(serverSnap.state.configs) && serverSnap.state.configs.length > 0) {
          setConfigs(serverSnap.state.configs);
        }
        if (Array.isArray(serverSnap.state.transactions)) {
          setTransactions(serverSnap.state.transactions);
        }
        if (Array.isArray(serverSnap.state.customers) && serverSnap.state.customers.length > 0) {
          setCustomers(serverSnap.state.customers);
        }
        if (Array.isArray(serverSnap.state.auditLogs) && serverSnap.state.auditLogs.length > 0) {
          setAuditLogs(serverSnap.state.auditLogs);
          localStorage.setItem('lottery_audit_logs', JSON.stringify(serverSnap.state.auditLogs));
        }
        setSyncStatus(flushRes.remainingCount > 0 ? 'offline' : 'synced');
      } else {
        setSyncStatus('offline');
      }
    };
    void syncWithServer();
    return () => {
      mounted = false;
    };
  }, []);

  // Fast Paste LINE/SMS Modal State
  const [showFastPaste, setShowFastPaste] = useState<boolean>(false);
  const [fastPasteText, setFastPasteText] = useState<string>('');

  // Current Input State
  const [currentType, setCurrentType] = useState<LotteryType>('2ตัวบน');
  const [currentNumber, setCurrentNumber] = useState('');
  const [currentAmount, setCurrentAmount] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [activeField, setActiveField] = useState<InputMode>('number');
  const [basket, setBasket] = useState<BasketItem[]>([]);
  const [isBasketOpen, setIsBasketOpen] = useState(false);

  // Modals
  const [halfPayModalOpen, setHalfPayModalOpen] = useState(false);
  const [pendingHalfPayData, setPendingHalfPayData] = useState<{
    evalResult: RiskEvaluationResult;
    type: string;
    number: string;
    amount: number;
  } | null>(null);

  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [lastSavedBill, setLastSavedBill] = useState<{
    billId: string;
    customerName: string;
    timestamp: string;
    drawPeriod: string;
    discountPercent: number;
    items: Transaction[];
  } | null>(null);

  // Toast Notifications State & Helpers
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (toast: Omit<ToastMessage, 'id'>) => {
    const id = `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newToast: ToastMessage = { ...toast, id };
    setToasts((prev) => [...prev, newToast]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('lottery_configs', JSON.stringify(configs));
  }, [configs]);

  useEffect(() => {
    localStorage.setItem('lottery_transactions', JSON.stringify(transactions));
    const updatedSummary = calculateSummaryRisk(transactions, configs);
    setSummaryRisks(updatedSummary);
    localStorage.setItem('lottery_summary_risks', JSON.stringify(updatedSummary));
  }, [transactions, configs]);

  useEffect(() => {
    localStorage.setItem('lottery_archived_draws', JSON.stringify(archivedDraws));
  }, [archivedDraws]);

  // Current Next Bill ID
  const currentBillId = getNextBillId(transactions);

  // Max digits for current type
  const maxDigitsForType = currentType.startsWith('3') ? 3 : currentType.startsWith('2') ? 2 : 1;
  const isNumberComplete = currentNumber.length === maxDigitsForType;

  // Real-time evaluation of current input
  const currentAmtNumber = Number(currentAmount) || 0;
  const liveEvaluation: RiskEvaluationResult = evaluateNumberRisk(
    currentType,
    currentNumber,
    currentAmtNumber,
    configs,
    transactions,
    basket
  );

  // Numpad Key Press Handler
  const handleNumpadKey = (key: string) => {
    playKeyClickSound(soundSettings);
    if (activeField === 'number') {
      if (currentNumber.length < maxDigitsForType) {
        const nextNum = currentNumber + key;
        setCurrentNumber(nextNum);
        if (nextNum.length === maxDigitsForType) {
          // Immediately evaluate when user finishes keying the number
          const ev = evaluateNumberRisk(
            currentType,
            nextNum,
            currentAmtNumber || 1,
            configs,
            transactions,
            basket
          );
          if (ev.status === 'ปิดรับ' || !ev.canAccept) {
            playClosedErrorSound(soundSettings);
          } else if (ev.status === 'อั้นจ่าย') {
            playHalfPayWarningSound(soundSettings);
          }
          if (!currentAmount) {
            setActiveField('amount');
          }
        }
      }
    } else {
      if (currentAmount.length < 7) {
        setCurrentAmount((prev) => (prev === '0' ? key : prev + key));
      }
    }
  };

  const handleNumpadClear = () => {
    if (activeField === 'number') {
      setCurrentNumber('');
    } else {
      setCurrentAmount('');
    }
  };

  const handleNumpadDelete = () => {
    if (activeField === 'number') {
      setCurrentNumber((prev) => prev.slice(0, -1));
    } else {
      setCurrentAmount((prev) => prev.slice(0, -1));
    }
  };

  const handleQuickAmount = (amount: number) => {
    setCurrentAmount(String(amount));
  };

  const handleSelectType = (type: LotteryType) => {
    setCurrentType(type);
    setCurrentNumber('');
    setActiveField('number');
  };

  // Handle Thai Lottery Shortcuts
  const handleShortcut = (shortcut: 'reverse' | '19door' | 'swipeFront' | 'swipeBack') => {
    if (isPeriodLocked) {
      addToast({
        type: 'error',
        title: '🔒 งวดนี้ถูกล็อกการแก้ไข',
        message: 'ข้อมูลงวดที่ปิดแล้วห้ามเพิ่มหรือแก้ไขรายการโดยไม่ได้รับอนุญาต',
      });
      return;
    }
    if (isMarketClosed) {
      addToast({
        type: 'error',
        title: '🔒 ระบบปิดรับแทงแล้ว',
        message: 'ไม่สามารถเพิ่มรายการได้เนื่องจากเลยเวลาปิดรับโพย หรือถูกล็อกปิดรับด่วน',
      });
      return;
    }

    const amt = Number(currentAmount) || 0;
    if (amt <= 0) {
      addToast({
        type: 'warning',
        title: '⚠️ ยังไม่ได้ระบุจำนวนเงิน',
        message: 'กรุณาระบุจำนวนเงิน (บาท) ก่อนกดปุ่มลัด',
      });
      setActiveField('amount');
      return;
    }

    let numbersToAdd: string[] = [];

    if (shortcut === 'reverse') {
      if (!currentNumber) {
        addToast({
          type: 'warning',
          title: '⚠️ ยังไม่ได้ระบุตัวเลข',
          message: `กรุณาระบุตัวเลข ${maxDigitsForType} หลักก่อนกดกลับเลข`,
        });
        return;
      }
      if (currentNumber.length !== maxDigitsForType) {
        addToast({
          type: 'warning',
          title: '⚠️ จำนวนหลักไม่ครบ',
          message: `เลข ${currentType} ต้องระบุให้ครบ ${maxDigitsForType} หลักก่อนกดกลับเลข (เช่น ถ้ามีเลข 0 ต้องใส่ 0x หรือ x0 เช่น 05, 50)`,
        });
        return;
      }
      numbersToAdd = reverseNumber(currentNumber);
    } else if (shortcut === '19door') {
      if (!currentType.startsWith('2')) {
        addToast({
          type: 'info',
          title: 'ℹ️ ประเภทเลขไม่รองรับ',
          message: 'ปุ่มลัด 19 ประตู ใช้สำหรับเลข 2 ตัวบน / 2 ตัวล่าง',
        });
        return;
      }
      if (!currentNumber) {
        addToast({
          type: 'warning',
          title: '⚠️ ยังไม่ได้ระบุเลขหลัก',
          message: 'กรุณาระบุเลขหลัก 1 ตัว (0-9) ก่อนกด 19 ประตู (เช่น ใส่ 0 เพื่อรูดเลข 0x และ x0 รวม 19 ตัว)',
        });
        return;
      }
      const digit = currentNumber[0];
      numbersToAdd = nineteenDoors(digit);
    } else if (shortcut === 'swipeFront') {
      if (!currentType.startsWith('2')) {
        addToast({
          type: 'info',
          title: 'ℹ️ ประเภทเลขไม่รองรับ',
          message: 'ปุ่มลัด รูดหน้า ใช้สำหรับเลข 2 ตัวบน / 2 ตัวล่าง',
        });
        return;
      }
      if (!currentNumber) {
        addToast({
          type: 'warning',
          title: '⚠️ ยังไม่ได้ระบุเลขหลัก',
          message: 'กรุณาระบุเลข 1 ตัว (0-9) ก่อนกดรูดหน้า (เช่น ใส่ 0 เพื่อสร้าง 00 ถึง 09)',
        });
        return;
      }
      const digit = currentNumber[0];
      numbersToAdd = swipeFront(digit);
    } else if (shortcut === 'swipeBack') {
      if (!currentType.startsWith('2')) {
        addToast({
          type: 'info',
          title: 'ℹ️ ประเภทเลขไม่รองรับ',
          message: 'ปุ่มลัด รูดหลัง ใช้สำหรับเลข 2 ตัวบน / 2 ตัวล่าง',
        });
        return;
      }
      if (!currentNumber) {
        addToast({
          type: 'warning',
          title: '⚠️ ยังไม่ได้ระบุเลขหลัก',
          message: 'กรุณาระบุเลข 1 ตัว (0-9) ก่อนกดรูดหลัง (เช่น ใส่ 0 เพื่อสร้าง 00, 10, ... 90)',
        });
        return;
      }
      const digit = currentNumber[0];
      numbersToAdd = swipeBack(digit);
    }

    if (!numbersToAdd.length) return;

    let closedCount = 0;
    let halfPayCount = 0;
    const newItems: BasketItem[] = [];

    numbersToAdd.forEach((num) => {
      const ev = evaluateNumberRisk(currentType, num, amt, configs, transactions, [...basket, ...newItems]);
      if (ev.status === 'ปิดรับ' || !ev.canAccept) {
        closedCount++;
        return;
      }
      if (ev.status === 'อั้นจ่าย') {
        halfPayCount++;
      }
      newItems.push({
        id: `${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
        type: currentType,
        number: num,
        amount: amt,
        payoutRate: ev.payoutRate,
        status: ev.status,
        sentAmount: ev.sentAmount,
        keepAmount: ev.keepAmount,
      });
    });

    if (newItems.length > 0) {
      setBasket((prev) => [...prev, ...newItems]);
      setCurrentNumber('');
      setActiveField('number');

      if (halfPayCount > 0) {
        playHalfPayWarningSound(soundSettings);
        addToast({
          type: 'warning',
          title: `⚠️ มีเลขอั้นจ่าย ${halfPayCount} รายการ`,
          message: `เพิ่ม ${newItems.length} รายการเข้าตะกร้าแล้ว (มีเลขอั้นจ่าย ${halfPayCount} รายการ อัตราจ่ายพิเศษ)`,
        });
      } else {
        addToast({
          type: 'success',
          title: `✅ เพิ่มสำเร็จ ${newItems.length} รายการ`,
          message: `เพิ่มรายการเข้าตะกร้าเรียบร้อยแล้ว`,
        });
      }

      if (closedCount > 0) {
        if (halfPayCount === 0) {
          playClosedErrorSound(soundSettings);
        }
        addToast({
          type: 'error',
          title: `⛔ คัดออกเลขปิดรับ ${closedCount} ตัว`,
          message: `มีเลขปิดรับแทง ${closedCount} ตัวเนื่องจากยอดเต็มเพดานความเสี่ยง จึงไม่นำเข้าตะกร้า`,
        });
      }
    } else {
      playClosedErrorSound(soundSettings);
      addToast({
        type: 'error',
        title: '⛔ ไม่สามารถเพิ่มรายการได้',
        message: 'ตัวเลขทั้งหมดที่เลือกอยู่ในสถานะ "ปิดรับแทง" (เต็มเพดานความเสี่ยง)',
      });
    }
  };

  // Add Current Single Item to Basket
  const handleAddToBasket = () => {
    if (isPeriodLocked) {
      addToast({
        type: 'error',
        title: '🔒 งวดนี้ถูกล็อกการแก้ไข',
        message: 'ข้อมูลงวดที่ปิดแล้วห้ามเพิ่มหรือแก้ไขรายการโดยไม่ได้รับอนุญาต',
      });
      return;
    }
    if (isMarketClosed) {
      addToast({
        type: 'error',
        title: '🔒 ระบบปิดรับแทงแล้ว',
        message: 'หมดเวลารับโพยแล้ว หรือระบบถูกล็อกปิดรับด่วน กรุณากดเปิดรับต่อหากต้องการทำรายการ',
      });
      return;
    }

    if (!currentNumber) {
      addToast({
        type: 'warning',
        title: '⚠️ กรุณาระบุตัวเลข',
        message: `กรุณากรอกตัวเลขให้ครบ ${maxDigitsForType} หลัก`,
      });
      setActiveField('number');
      return;
    }

    if (currentNumber.length !== maxDigitsForType) {
      if (maxDigitsForType === 2) {
        addToast({
          type: 'warning',
          title: '⚠️ เลข 2 ตัวต้องใส่ 2 หลัก',
          message: 'เลข 2 ตัวไม่สามารถเลือกเพียง 1 ตัวเลขแล้วกดแทงได้! ถ้าแทงเลขที่มี 0 ต้องใส่ 0x หรือ x0 เช่น 05, 50, 00',
        });
      } else if (maxDigitsForType === 3) {
        addToast({
          type: 'warning',
          title: '⚠️ เลข 3 ตัวต้องใส่ 3 หลัก',
          message: 'เลข 3 ตัวต้องกรอกให้ครบ 3 หลัก (ถ้าแทงเลขที่มี 0 ต้องใส่ 0xx, x0x, xx0, 0x0 หรือ 00x เช่น 058, 508, 580)',
        });
      } else {
        addToast({
          type: 'warning',
          title: '⚠️ จำนวนหลักไม่ครบ',
          message: `กรุณากรอกตัวเลขให้ครบ ${maxDigitsForType} หลัก`,
        });
      }
      setActiveField('number');
      return;
    }

    if (currentAmtNumber <= 0) {
      addToast({
        type: 'warning',
        title: '⚠️ ยังไม่ได้ระบุจำนวนเงิน',
        message: 'กรุณาระบุจำนวนเงิน (บาท) ก่อนกดเพิ่มลงตะกร้า',
      });
      setActiveField('amount');
      return;
    }

    if (!liveEvaluation.canAccept || liveEvaluation.status === 'ปิดรับ') {
      playClosedErrorSound(soundSettings);
      addToast({
        type: 'error',
        title: '⛔ เลขปิดรับแทง (เต็มเพดานความเสี่ยง)',
        message: `${currentType} เลข [${currentNumber}] ปิดรับแทงแล้ว ยอดเดิมพันสะสมเกินเพดานความเสี่ยงที่ตั้งไว้`,
      });
      return;
    }

    if (liveEvaluation.status === 'อั้นจ่าย') {
      playHalfPayWarningSound(soundSettings);
      setPendingHalfPayData({
        evalResult: liveEvaluation,
        type: currentType,
        number: currentNumber,
        amount: currentAmtNumber,
      });
      setHalfPayModalOpen(true);
      return;
    }

    pushToBasket(liveEvaluation, currentType, currentNumber, currentAmtNumber);
  };

  const pushToBasket = (
    ev: RiskEvaluationResult,
    type: string,
    number: string,
    amount: number
  ) => {
    const newItem: BasketItem = {
      id: `${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      type,
      number,
      amount,
      payoutRate: ev.payoutRate,
      status: ev.status,
      sentAmount: ev.sentAmount,
      keepAmount: ev.keepAmount,
    };

    setBasket((prev) => [...prev, newItem]);
    setCurrentNumber('');
    setActiveField('number');

    if (ev.status === 'อั้นจ่าย') {
      addToast({
        type: 'warning',
        title: '⚠️ แจ้งเตือนเลขอั้นจ่าย (จ่ายครึ่งราคา)',
        message: `${type} เลข [${number}] ยอด ฿${amount.toLocaleString()} เป็นเลขอั้นจ่าย เรทจ่าย ${ev.payoutRate} บ. (บันทึกลงตะกร้าแล้ว)`,
      });
    } else if (ev.sentAmount > 0) {
      addToast({
        type: 'info',
        title: '📤 มีการกระจายความเสี่ยง (ส่งต่อ)',
        message: `${type} เลข [${number}] ฿${amount.toLocaleString()} (ถือเอง ฿${ev.keepAmount.toLocaleString()} / ส่งต่อ ฿${ev.sentAmount.toLocaleString()})`,
      });
    } else {
      addToast({
        type: 'success',
        title: '✅ เพิ่มลงตะกร้าแล้ว',
        message: `${type} เลข [${number}] จำนวน ฿${amount.toLocaleString()} (จ่าย ${ev.payoutRate} บ.)`,
      });
    }
  };

  const handleConfirmHalfPay = () => {
    if (pendingHalfPayData) {
      pushToBasket(
        pendingHalfPayData.evalResult,
        pendingHalfPayData.type,
        pendingHalfPayData.number,
        pendingHalfPayData.amount
      );
      setHalfPayModalOpen(false);
      setPendingHalfPayData(null);
    }
  };

  // Remove single item from basket and re-allocate risk for remaining basket items
  const handleRemoveBasketItem = (id: string) => {
    const item = basket.find((b) => b.id === id);
    setBasket((prev) => {
      const remaining = prev.filter((b) => b.id !== id);
      const recalculated: BasketItem[] = [];
      remaining.forEach((bItem) => {
        const ev = evaluateNumberRisk(
          bItem.type,
          bItem.number,
          bItem.amount,
          configs,
          transactions,
          recalculated
        );
        recalculated.push({
          ...bItem,
          payoutRate: bItem.payoutRate ?? ev.payoutRate,
          keepAmount: ev.keepAmount,
          sentAmount: ev.sentAmount,
        });
      });
      return recalculated;
    });
    if (item) {
      addToast({
        type: 'info',
        title: '🗑️ ลบรายการออกแล้ว',
        message: `ลบ ${item.type} [${item.number}] ยอด ฿${item.amount.toLocaleString()} ออกจากตะกร้าและคำนวณเพดานใหม่แล้ว`,
      });
    }
  };

  // Clear Basket - Non-blocking, instant execution with Undo safety
  const handleClearBasket = () => {
    if (!basket.length) {
      addToast({
        type: 'info',
        title: 'ℹ️ ตะกร้าว่างเปล่า',
        message: 'ไม่มีรายการในตะกร้าให้ล้าง',
      });
      return;
    }
    const backup = [...basket];
    const count = basket.length;
    setBasket([]);
    addToast({
      type: 'info',
      title: '🗑️ ล้างตะกร้าเรียบร้อย',
      message: `ลบรายการทั้งหมด ${count} รายการออกจากตะกร้าแล้ว`,
      undoAction: () => {
        setBasket(backup);
        addToast({
          type: 'success',
          title: '🔄 กู้คืนรายการสำเร็จ',
          message: `กู้คืนรายการในตะกร้าทั้ง ${count} รายการเรียบร้อยแล้ว`,
        });
      },
      undoLabel: `กู้คืน (${count} รายการ)`,
    });
  };

  // Confirm and Save Bill (Wait for Server Confirmation before declaring success; prevents duplicate Race Conditions)
  const handleConfirmSaveBill = async () => {
    if (isSubmittingBill) return;
    if (isPeriodLocked) {
      addToast({
        type: 'error',
        title: '🔒 งวดนี้ถูกล็อกการแก้ไข',
        message: 'ข้อมูลงวดที่ปิดแล้วห้ามบันทึกบิลเพิ่มโดยไม่ได้รับอนุญาต',
      });
      return;
    }
    if (isMarketClosed) {
      addToast({
        type: 'error',
        title: '🔒 ระบบปิดรับแทงแล้ว',
        message: 'ไม่สามารถบันทึกบิลได้เนื่องจากหมดเวลารับโพยแล้ว กรุณาปลดล็อกเวลาหากต้องการบันทึกบิลนี้',
      });
      return;
    }

    if (!basket.length) {
      addToast({
        type: 'warning',
        title: '⚠️ ตะกร้าว่างเปล่า',
        message: 'ยังไม่มีรายการในตะกร้าสำหรับบันทึกบิล',
      });
      return;
    }

    setIsSubmittingBill(true);
    setSyncStatus('syncing');

    const now = getCurrentThaiTimestamp();
    const billId = currentBillId;
    const custName = customerName.trim() || 'ลูกค้าทั่วไป';
    const cleanDiscount = Math.max(0, Math.min(50, Number(discountPercent) || 0));
    const billIdempotencyKey = `IDEM_${billId}_${Date.now()}`;

    try {
      const serverRes = await apiCreateBill({
        idempotencyKey: billIdempotencyKey,
        billId,
        customerName: custName,
        discountPercent: cleanDiscount,
        drawPeriod: currentDrawPeriod,
        items: basket.map((b) => ({
          type: b.type,
          number: b.number,
          amount: b.amount,
        })),
      });

      if (!serverRes.confirmedByServer && !serverRes.queuedOffline) {
        // Server explicitly rejected the bill (e.g. validation error / closed number)
        setSyncStatus('error');
        playClosedErrorSound(soundSettings);
        addToast({
          type: 'error',
          title: '⛔ Server ปฏิเสธการบันทึกบิล',
          message: serverRes.error || 'ข้อมูลไม่ผ่านการตรวจสอบจาก Server',
        });
        return;
      }

      if (serverRes.confirmedByServer && serverRes.transactions && serverRes.createdTransactions) {
        // Authoritative Server Confirmation received!
        setTransactions(serverRes.transactions);
        if (serverRes.auditEntry) {
          appendLocalAuditLog(serverRes.auditEntry);
        }
        setSyncStatus('synced');
        setLastSavedBill({
          billId: serverRes.billId || billId,
          customerName: custName,
          timestamp: serverRes.createdTransactions[0]?.timestamp || now,
          drawPeriod: currentDrawPeriod,
          discountPercent: cleanDiscount,
          items: serverRes.createdTransactions,
        });
      } else {
        // Offline Fallback: Queued in Offline Queue with explicit offline notice
        const newTransactions: Transaction[] = basket.map((item, idx) => ({
          id: `TX_${billId}_${Date.now()}_${idx + 1}`,
          idempotencyKey: billIdempotencyKey,
          timestamp: now,
          billId,
          customerName: custName,
          type: item.type,
          number: item.number,
          amount: item.amount,
          payoutRate: item.payoutRate,
          status: item.status,
          sentAmount: item.sentAmount,
          keepAmount: item.keepAmount,
          discountPercent: cleanDiscount,
          drawPeriod: currentDrawPeriod,
        }));
        setTransactions((prev) => [...prev, ...newTransactions]);
        setOfflineQueueCount(getOfflineQueue().length);
        setSyncStatus('offline');
        appendLocalAuditLog({
          id: `AUD_OFFLINE_${Date.now()}`,
          timestamp: now,
          action: 'CREATE_BILL',
          actor: custName,
          targetId: billId,
          summary: `[รอซิงก์ออฟไลน์] บันทึกบิล ${billId} จำนวน ${newTransactions.length} รายการ`,
          idempotencyKey: billIdempotencyKey,
        });
        setLastSavedBill({
          billId,
          customerName: custName,
          timestamp: now,
          drawPeriod: currentDrawPeriod,
          discountPercent: cleanDiscount,
          items: newTransactions,
        });
        addToast({
          type: 'warning',
          title: `📡 บันทึกลงคิวออฟไลน์ (${billId})`,
          message: 'ขณะนี้ไม่ได้เชื่อมต่อ Server ระบบเก็บลง Offline Queue และจะซิงก์อัตโนมัติเมื่อออนไลน์',
        });
      }

      // Reset Basket & form
      setBasket([]);
      setIsBasketOpen(false);
      setCurrentNumber('');
      setCurrentAmount('');
      setCustomerName('');
      setActiveField('number');

      // Play Bill Saved notification chime & open receipt modal
      playBillSavedSound(soundSettings);
      setReceiptModalOpen(true);
    } finally {
      setIsSubmittingBill(false);
    }
  };

  // Handle adding batch of items from 10x10 Grid Selector
  const handleAddGridBatchToBasket = (
    items: BasketItem[],
    summary: {
      selectedCount: number;
      halfPayCount: number;
      closedCount: number;
      betType: GridBetType;
      totalAmount: number;
    }
  ) => {
    if (isMarketClosed) {
      addToast({
        type: 'error',
        title: '🔒 ระบบปิดรับแทงแล้ว',
        message: 'ไม่สามารถเพิ่มรายการจากแผงได้เนื่องจากขณะนี้อยู่ในสถานะปิดรับโพย',
      });
      return;
    }
    if (!items.length) {
      playClosedErrorSound(soundSettings);
      addToast({
        type: 'error',
        title: '⛔ ไม่สามารถเพิ่มรายการได้',
        message: 'ตัวเลขที่เลือกทั้งหมดอยู่ในสถานะปิดรับแทง (เต็มเพดานความเสี่ยง)',
      });
      return;
    }

    setBasket((prev) => [...prev, ...items]);

    if (summary.halfPayCount > 0) {
      playHalfPayWarningSound(soundSettings);
      addToast({
        type: 'warning',
        title: `⚠️ มีเลขอั้นจ่าย ${summary.halfPayCount} รายการ`,
        message: `เพิ่ม ${items.length} รายการเข้าตะกร้าแล้ว (ประเภท ${summary.betType} ยอดรวม ฿${summary.totalAmount.toLocaleString()} บ.) โดยมีเลขอั้นจ่ายคิดเรทพิเศษ`,
      });
    } else {
      addToast({
        type: 'success',
        title: `✅ เพิ่มสำเร็จ ${items.length} รายการ`,
        message: `เพิ่มเลขจากแผง ${summary.selectedCount} ตัว (ประเภท ${summary.betType}) รวม ฿${summary.totalAmount.toLocaleString()} บ. ลงตะกร้าแล้ว`,
      });
    }

    if (summary.closedCount > 0) {
      if (summary.halfPayCount === 0) {
        playClosedErrorSound(soundSettings);
      }
      addToast({
        type: 'error',
        title: `⛔ คัดออกเลขปิดรับ ${summary.closedCount} ตัว`,
        message: `มีเลขปิดรับแทง ${summary.closedCount} ตัวเนื่องจากยอดเต็มเพดานความเสี่ยง จึงไม่นำเข้าตะกร้า`,
      });
    }
  };

  // View / Reprint past receipt
  const handleViewPastReceipt = (billId: string) => {
    const items = transactions.filter((t) => t.billId === billId);
    if (items.length) {
      setLastSavedBill({
        billId,
        customerName: items[0].customerName,
        timestamp: items[0].timestamp,
        drawPeriod: items[0].drawPeriod || currentDrawPeriod,
        discountPercent: items[0].discountPercent || 0,
        items,
      });
      setReceiptModalOpen(true);
    }
  };

  // Re-bet / Clone Past Bill into Current Basket
  const handleRebetBill = (billId: string) => {
    if (isMarketClosed) {
      addToast({
        type: 'error',
        title: '🔒 ระบบปิดรับแทงแล้ว',
        message: 'ไม่สามารถแทงซ้ำได้เนื่องจากขณะนี้อยู่ในสถานะปิดรับโพย กรุณากดเปิดรับต่อหากต้องการทำรายการ',
      });
      return;
    }

    const pastItems = transactions.filter((t) => t.billId === billId);
    if (!pastItems.length) return;

    const clonedBasketItems: BasketItem[] = [];
    let closedCount = 0;
    let halfPayCount = 0;

    pastItems.forEach((tx) => {
      const ev = evaluateNumberRisk(
        tx.type,
        tx.number,
        tx.amount,
        configs,
        transactions,
        [...basket, ...clonedBasketItems]
      );

      if (ev.status === 'ปิดรับ' || !ev.canAccept) {
        closedCount++;
        return;
      }

      if (ev.status === 'อั้นจ่าย') {
        halfPayCount++;
      }

      clonedBasketItems.push({
        id: `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        type: tx.type,
        number: tx.number,
        amount: tx.amount,
        payoutRate: ev.payoutRate,
        status: ev.status,
        sentAmount: ev.sentAmount,
        keepAmount: ev.keepAmount,
      });
    });

    if (clonedBasketItems.length > 0) {
      setBasket((prev) => [...prev, ...clonedBasketItems]);
      if (pastItems[0].customerName && !customerName) {
        setCustomerName(pastItems[0].customerName);
      }
      if (pastItems[0].discountPercent !== undefined) {
        setDiscountPercent(pastItems[0].discountPercent);
      }
      setIsBasketOpen(true);

      if (halfPayCount > 0) {
        addToast({
          type: 'warning',
          title: `🔁 แทงซ้ำบิล ${billId} (${clonedBasketItems.length} รายการ)`,
          message: `ดึงรายการของ "${pastItems[0].customerName}" เข้าตะกร้าแล้ว (มีเลขอั้นจ่าย ${halfPayCount} รายการตามเรทปัจจุบัน)`,
        });
      } else {
        addToast({
          type: 'success',
          title: `🔁 แทงซ้ำบิล ${billId} สำเร็จ!`,
          message: `ดึงรายการทั้งหมด ${clonedBasketItems.length} รายการของ "${pastItems[0].customerName}" เข้าตะกร้าพร้อมยืนยันบิลใหม่ทันที`,
        });
      }

      if (closedCount > 0) {
        addToast({
          type: 'error',
          title: `⛔ คัดออกเลขปิดรับ ${closedCount} รายการ`,
          message: `มีเลขในบิลเดิมที่ปัจจุบันเต็มเพดานความเสี่ยงแล้ว ${closedCount} รายการ จึงไม่นำเข้าตะกร้า`,
        });
      }
    } else {
      addToast({
        type: 'error',
        title: '⛔ ไม่สามารถแทงซ้ำได้',
        message: `เลขทั้งหมดในบิล ${billId} ปัจจุบันอยู่ในสถานะปิดรับแทง (เต็มเพดานความเสี่ยง)`,
      });
    }
  };

  // Void / Delete a mistaken bill (Instant with Undo Toast + Risk Re-allocation + Server Sync)
  const handleDeleteBill = (billId: string) => {
    if (isPeriodLocked) {
      addToast({
        type: 'error',
        title: '🔒 งวดนี้ถูกล็อกการแก้ไข',
        message: 'ข้อมูลงวดที่ปิดแล้วห้ามลบบิลโดยไม่ได้รับอนุญาต กรุณากดปลดล็อกงวดก่อนหากจำเป็น',
      });
      return;
    }
    const removedItems = transactions.filter((t) => t.billId === billId);
    if (!removedItems.length) return;
    const backup = [...transactions];
    const remaining = transactions.filter((t) => t.billId !== billId);
    const reconciled = reconcileTransactionsRisk(remaining, configs);
    setTransactions(reconciled);

    void apiDeleteBill(billId).then((res) => {
      if (res.confirmedByServer && res.auditEntry) {
        appendLocalAuditLog(res.auditEntry);
      }
    });

    addToast({
      type: 'info',
      title: `🗑️ ยกเลิกบิล ${billId} แล้ว`,
      message: `ลบรายการในบิล ${billId} (${removedItems.length} รายการ) และเกลี่ยยอดถือสู้เอง/ตีออกใหม่ตามลำดับเวลาแล้ว`,
      undoAction: () => {
        setTransactions(backup);
        void apiSyncMetadata({
          transactions: backup,
          auditAction: 'CREATE_BILL',
          auditTargetId: billId,
          auditSummary: `กู้คืนบิล ${billId} ที่ถูกยกเลิก`,
        });
        addToast({
          type: 'success',
          title: `🔄 กู้คืนบิล ${billId} สำเร็จ`,
          message: `นำบิล ${billId} กลับเข้าสู่ระบบเรียบร้อยแล้ว`,
        });
      },
      undoLabel: `กู้คืนบิล ${billId}`,
    });
  };

  // Edit an existing bill and automatically reconcile risk across all bills + Server Sync
  const handleEditBill = (
    billId: string,
    updatedMeta: { customerName: string; discountPercent: number },
    updatedItems: EditableBillItem[]
  ) => {
    if (isPeriodLocked) {
      addToast({
        type: 'error',
        title: '🔒 งวดนี้ถูกล็อกการแก้ไข',
        message: 'ข้อมูลงวดที่ปิดแล้วห้ามแก้ไขบิลโดยไม่ได้รับอนุญาต',
      });
      return;
    }
    const backup = [...transactions];
    const result = editBillTransactions(
      transactions,
      billId,
      updatedMeta,
      updatedItems,
      configs
    );
    if (!result.success) {
      playClosedErrorSound(soundSettings);
      addToast({
        type: 'error',
        title: `⛔ แก้ไขบิล ${billId} ไม่สำเร็จ`,
        message: result.error || 'ข้อมูลไม่ถูกต้อง',
      });
      return;
    }

    setTransactions(result.transactions);
    void apiEditBill({
      billId,
      customerName: updatedMeta.customerName,
      discountPercent: updatedMeta.discountPercent,
      items: updatedItems,
    }).then((res) => {
      if (res.confirmedByServer && res.auditEntry) {
        appendLocalAuditLog(res.auditEntry);
      }
    });

    addToast({
      type: 'success',
      title: `✏️ แก้ไขบิล ${billId} สำเร็จ`,
      message: `อัปเดตข้อมูลบิล ${billId} และคำนวณเกลี่ยยอด Keep / Sent ใหม่เรียบร้อยแล้ว`,
      undoAction: () => {
        setTransactions(backup);
        void apiSyncMetadata({
          transactions: backup,
          auditAction: 'EDIT_BILL',
          auditTargetId: billId,
          auditSummary: `ยกเลิกการแก้ไขบิล ${billId} คืนค่าเดิม`,
        });
        addToast({
          type: 'info',
          title: `🔄 ยกเลิกการแก้ไขบิล ${billId}`,
          message: 'คืนค่าข้อมูลบิลกลับเป็นก่อนแก้ไขแล้ว',
        });
      },
      undoLabel: 'เลิกทำ (Undo)',
    });
  };

  // Fast Paste LINE/SMS Handler
  const handleImportFastPasteToBasket = () => {
    if (isPeriodLocked || isMarketClosed) {
      addToast({
        type: 'error',
        title: '🔒 ไม่สามารถนำเข้าโพยได้',
        message: 'ระบบอยู่ในสถานะปิดรับหรือล็อกงวดแล้ว',
      });
      return;
    }
    const parsed = parseFastBetText(fastPasteText);
    const validLines = parsed.filter((p) => p.isValid && p.amount > 0);
    if (!validLines.length) {
      addToast({
        type: 'warning',
        title: '⚠️ ไม่พบรายการที่ถูกต้อง',
        message: 'กรุณาตรวจสอบรูปแบบโพย เช่น 38=100x100 หรือ 538=100x50 หรือ 45 บน 100',
      });
      return;
    }

    const newBasketItems: BasketItem[] = [];
    let closedCount = 0;
    let halfPayCount = 0;

    validLines.forEach((line, idx) => {
      const ev = evaluateNumberRisk(
        line.type,
        line.number,
        line.amount,
        configs,
        transactions,
        [...basket, ...newBasketItems]
      );
      if (ev.status === 'ปิดรับ' || !ev.canAccept) {
        closedCount++;
        return;
      }
      if (ev.status === 'อั้นจ่าย') {
        halfPayCount++;
      }
      newBasketItems.push({
        id: `FAST_${Date.now()}_${idx}`,
        type: line.type,
        number: line.number,
        amount: line.amount,
        payoutRate: ev.payoutRate,
        status: ev.status,
        sentAmount: ev.sentAmount,
        keepAmount: ev.keepAmount,
      });
    });

    if (newBasketItems.length > 0) {
      setBasket((prev) => [...prev, ...newBasketItems]);
      setFastPasteText('');
      setShowFastPaste(false);
      if (halfPayCount > 0) {
        playHalfPayWarningSound(soundSettings);
      }
      addToast({
        type: halfPayCount > 0 ? 'warning' : 'success',
        title: `📋 นำเข้าโพยสำเร็จ ${newBasketItems.length} รายการ`,
        message:
          closedCount > 0
            ? `เพิ่มเข้าตะกร้า ${newBasketItems.length} รายการ (คัดออกเลขปิดรับ ${closedCount} รายการ)`
            : `เพิ่มรายการจากโพยด่วนเข้าตะกร้าเรียบร้อยแล้ว`,
      });
    } else {
      playClosedErrorSound(soundSettings);
      addToast({
        type: 'error',
        title: '⛔ เลขในโพยทั้งหมดปิดรับแทง',
        message: `ไม่สามารถนำเข้าได้เนื่องจากเลขทั้ง ${closedCount} รายการอยู่ในสถานะปิดรับ`,
      });
    }
  };

  // Archive Current Draw & Start New Draw (ข้อ 4)
  const handleArchiveAndStartNewDraw = (
    nextDrawName: string,
    winTop3?: string,
    winBottom2?: string
  ) => {
    const backupTransactions = [...transactions];
    const backupDrawPeriod = currentDrawPeriod;
    const savedTop3 = winTop3 ?? localStorage.getItem('lottery_win_top3') ?? '';
    const savedBottom2 = winBottom2 ?? localStorage.getItem('lottery_win_bottom2') ?? '';

    const accounting = calculateUnifiedAccountingSummary(transactions);

    const newArchive: ArchivedDraw = {
      id: `ARCH_${Date.now()}`,
      drawPeriod: currentDrawPeriod,
      archivedAt: getCurrentThaiTimestamp(),
      isLocked: true,
      winningTop3: savedTop3,
      winningBottom2: savedBottom2,
      totalGrossSales: accounting.totalGrossSales,
      totalNetSales: accounting.totalNetSales,
      totalKeepAmount: accounting.totalKeepAmount,
      totalSentAmount: accounting.totalSentAmount,
      transactionsCount: transactions.length,
      billsCount: accounting.billsCount,
      transactions: backupTransactions,
    };

    setArchivedDraws((prev) => [newArchive, ...prev]);
    setTransactions([]);
    setBasket([]);
    setIsPeriodLocked(false);
    setActiveDrawBackup(null);
    setCurrentDrawPeriod(nextDrawName);
    localStorage.setItem('lottery_current_draw_period', nextDrawName);

    addToast({
      type: 'success',
      title: `📦 ปิดงวด "${backupDrawPeriod}" สำเร็จ!`,
      message: `เก็บโพย ${backupTransactions.length} รายการเข้าคลังประวัติ (ล็อกงวดแล้ว) เริ่มต้นรับโพย "${nextDrawName}" (บิล B001)`,
      undoAction: () => {
        setTransactions(backupTransactions);
        setCurrentDrawPeriod(backupDrawPeriod);
        localStorage.setItem('lottery_current_draw_period', backupDrawPeriod);
        setArchivedDraws((prev) => prev.filter((a) => a.id !== newArchive.id));
      },
      undoLabel: 'ยกเลิกการปิดงวด',
    });
  };

  // Restore an Archived Draw back to workspace in Locked Read-Only Mode first
  const handleRestoreArchivedDraw = (archive: ArchivedDraw) => {
    if (!isPeriodLocked && !activeDrawBackup) {
      setActiveDrawBackup({
        drawPeriod: currentDrawPeriod,
        transactions: [...transactions],
      });
    }

    setTransactions(archive.transactions);
    setCurrentDrawPeriod(archive.drawPeriod);
    setIsPeriodLocked(archive.isLocked ?? true);
    localStorage.setItem('lottery_current_draw_period', archive.drawPeriod);
    if (archive.winningTop3) {
      localStorage.setItem('lottery_win_top3', archive.winningTop3);
    }
    if (archive.winningBottom2) {
      localStorage.setItem('lottery_win_bottom2', archive.winningBottom2);
    }

    addToast({
      type: 'info',
      title: `🔒 เปิดดูงวดที่ปิดแล้ว "${archive.drawPeriod}"`,
      message: `อยู่ในโหมดล็อกการแก้ไข (${archive.transactionsCount} รายการ) เพื่อป้องกันการเปลี่ยนแปลงข้อมูลย้อนหลังโดยไม่ได้รับอนุญาต`,
    });
  };

  const handleReturnToActiveDraw = () => {
    if (!activeDrawBackup) {
      setIsPeriodLocked(false);
      return;
    }
    setTransactions(activeDrawBackup.transactions);
    setCurrentDrawPeriod(activeDrawBackup.drawPeriod);
    localStorage.setItem('lottery_current_draw_period', activeDrawBackup.drawPeriod);
    setIsPeriodLocked(false);
    setActiveDrawBackup(null);
    addToast({
      type: 'success',
      title: '✅ กลับสู่งวดปัจจุบันแล้ว',
      message: `สลับกลับมาที่ "${activeDrawBackup.drawPeriod}" พร้อมรับโพยต่อได้ตามปกติ`,
    });
  };

  const handleDeleteArchivedDraw = (id: string) => {
    const target = archivedDraws.find((a) => a.id === id);
    if (!target) return;
    const backup = [...archivedDraws];
    setArchivedDraws((prev) => prev.filter((a) => a.id !== id));
    addToast({
      type: 'info',
      title: `🗑️ ลบประวัติ "${target.drawPeriod}" แล้ว`,
      message: 'ลบข้อมูลคลังประวัติงวดนี้ออกจากระบบแล้ว',
      undoAction: () => {
        setArchivedDraws(backup);
      },
      undoLabel: 'กู้คืนประวัติงวด',
    });
  };

  // Config Management (Upsert by type + number to prevent duplicates + Server Sync)
  const handleAddConfig = (rule: ConfigRule) => {
    const existingIdx = configs.findIndex(
      (c) => c.type === rule.type && c.number === rule.number
    );
    if (existingIdx >= 0) {
      setConfigs((prev) =>
        prev.map((c, idx) => (idx === existingIdx ? rule : c))
      );
      addToast({
        type: 'success',
        title: '⚙️ อัปเดตกฎการตั้งค่าสำเร็จ',
        message: `อัปเดต ${rule.type} เลข [${rule.number}] เป็นสถานะ "${rule.status}" (จ่าย ${rule.payoutRate} บ. / เพดาน ฿${rule.maxRisk.toLocaleString()})`,
      });
    } else {
      setConfigs((prev) => [rule, ...prev]);
      addToast({
        type: 'success',
        title: '⚙️ เพิ่มกฎการตั้งค่าสำเร็จ',
        message: `เพิ่มกฎ ${rule.type} เลข [${rule.number}] สถานะ "${rule.status}" เรียบร้อยแล้ว`,
      });
    }
    void apiUpdateConfigs({ action: 'upsert', rule }).then((res) => {
      if (res.confirmedByServer && res.auditEntry) {
        appendLocalAuditLog(res.auditEntry);
      }
    });
  };

  const handleDeleteConfig = (index: number) => {
    const target = configs[index];
    setConfigs((prev) => prev.filter((_, i) => i !== index));
    if (target) {
      void apiUpdateConfigs({
        action: 'delete',
        type: target.type,
        number: target.number,
      }).then((res) => {
        if (res.confirmedByServer && res.auditEntry) {
          appendLocalAuditLog(res.auditEntry);
        }
      });
    }
  };

  const handleResetDefault = () => {
    const backupConfigs = [...configs];
    const backupTransactions = [...transactions];
    setConfigs(INITIAL_CONFIG_SETTINGS);
    setTransactions(INITIAL_TRANSACTIONS);
    setSummaryRisks(INITIAL_SUMMARY_RISK);
    void apiUpdateConfigs({ action: 'reset' }).then((res) => {
      if (res.confirmedByServer && res.auditEntry) {
        appendLocalAuditLog(res.auditEntry);
      }
    });
    addToast({
      type: 'info',
      title: '🔄 คืนค่าเริ่มต้นเรียบร้อยแล้ว',
      message: 'รีเซ็ตข้อมูลการตั้งค่าและรายการตัวอย่างกลับเป็นค่าเริ่มต้นแล้ว',
      undoAction: () => {
        setConfigs(backupConfigs);
        setTransactions(backupTransactions);
      },
      undoLabel: 'เลิกทำ (Undo)',
    });
  };

  // Phase 4: Full System Backup & Restore Handlers
  const handleExportFullBackup = async () => {
    const serverBackup = await apiExportBackup();
    const payload =
      serverBackup ||
      createSystemBackupPayload({
        configs,
        transactions,
        customers,
        archivedDraws,
        paymentRecords: {},
        auditLogs,
      });

    const jsonStr = JSON.stringify(payload, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `LotteryPOS_Backup_${new Date().toISOString().slice(0, 10)}.json`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    addToast({
      type: 'success',
      title: '💾 สำรองฐานข้อมูลสำเร็จ',
      message: `ดาวน์โหลดไฟล์ JSON พร้อมรหัสตรวจสอบ ${payload.checksum} เรียบร้อยแล้ว`,
    });
  };

  const handleRestoreFullBackup = async (rawJson: string) => {
    try {
      const parsed = JSON.parse(rawJson);
      const localCheck = verifySystemBackupPayload(parsed);
      if (!localCheck.isValid || !localCheck.parsed) {
        playClosedErrorSound(soundSettings);
        addToast({
          type: 'error',
          title: '⛔ ไฟล์สำรองข้อมูลไม่ถูกต้อง',
          message: localCheck.error || 'ไม่สามารถกู้คืนข้อมูลได้',
        });
        return;
      }

      // Save automatic pre-restore snapshot in localStorage before restoring
      const preRestoreBackup = createSystemBackupPayload({
        configs,
        transactions,
        customers,
        archivedDraws,
        paymentRecords: {},
        auditLogs,
      });
      localStorage.setItem('lottery_pre_restore_snapshot', JSON.stringify(preRestoreBackup));

      const serverRestore = await apiRestoreBackup(localCheck.parsed);
      const restoredData = serverRestore.state || localCheck.parsed.data;

      setConfigs(restoredData.configs);
      setTransactions(restoredData.transactions);
      if (Array.isArray(restoredData.customers)) {
        setCustomers(restoredData.customers);
        localStorage.setItem('lottery_customers', JSON.stringify(restoredData.customers));
      }
      if (Array.isArray(restoredData.archivedDraws)) {
        setArchivedDraws(restoredData.archivedDraws);
      }
      if (Array.isArray(restoredData.auditLogs)) {
        setAuditLogs(restoredData.auditLogs);
      }

      addToast({
        type: 'success',
        title: '✅ กู้คืนฐานข้อมูลสำเร็จ!',
        message: `กู้คืนข้อมูล (${restoredData.transactions.length} รายการ) เรียบร้อยแล้ว พร้อมสำรองข้อมูลเดิมก่อนทับอัตโนมัติ`,
      });
    } catch {
      playClosedErrorSound(soundSettings);
      addToast({
        type: 'error',
        title: '⛔ รูปแบบไฟล์ JSON ไม่ถูกต้อง',
        message: 'กรุณาเลือกไฟล์สำรองข้อมูล (.json) ที่ส่งออกจากระบบ Lottery POS เท่านั้น',
      });
    }
  };

  // Export CSV Handlers
  const exportCSV = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent =
      '\uFEFF' +
      headers.join(',') +
      '\n' +
      rows.map((row) => row.map((val) => `"${val}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportTransactionsCSV = () => {
    const headers = [
      'Timestamp',
      'Draw_Period',
      'Bill_ID',
      'Customer_Name',
      'Type',
      'Number',
      'Amount',
      'Payout_Rate',
      'Discount_Percent',
      'Status',
      'Sent_Amount',
      'Keep_Amount',
    ];
    const rows = transactions.map((t) => [
      t.timestamp,
      t.drawPeriod || currentDrawPeriod,
      t.billId,
      t.customerName,
      t.type,
      t.number,
      t.amount,
      getTransactionPayoutRate(t, configs),
      t.discountPercent || 0,
      t.status,
      t.sentAmount,
      t.keepAmount,
    ]);
    exportCSV('Transactions.csv', headers, rows);
  };

  const handleExportArchivedDrawCSV = (arch: ArchivedDraw) => {
    const headers = [
      'Timestamp',
      'Draw_Period',
      'Bill_ID',
      'Customer_Name',
      'Type',
      'Number',
      'Amount',
      'Payout_Rate',
      'Discount_Percent',
      'Status',
      'Sent_Amount',
      'Keep_Amount',
    ];
    const rows = arch.transactions.map((t) => [
      t.timestamp,
      t.drawPeriod || arch.drawPeriod,
      t.billId,
      t.customerName,
      t.type,
      t.number,
      t.amount,
      getTransactionPayoutRate(t, configs),
      t.discountPercent || 0,
      t.status,
      t.sentAmount,
      t.keepAmount,
    ]);
    const safeName = arch.drawPeriod.replace(/[^a-zA-Z0-9ก-๙_-]/g, '_');
    exportCSV(`Archive_${safeName}.csv`, headers, rows);
  };

  const handleExportSummaryRiskCSV = () => {
    const headers = [
      'Type',
      'Number',
      'Total_Amount',
      'Keep_Amount',
      'Sent_Amount',
      'Payout_Rate',
      'Potential_Payout',
      'Estimated_Profit',
      'Max_Risk_Limit',
      'Over_Limit_Amount',
      'Status',
    ];
    const rows = summaryRisks.map((r) => [
      r.type,
      r.number,
      r.totalAmount,
      r.keepAmount,
      r.sentAmount,
      r.payoutRate,
      r.potentialPayout,
      r.estimatedProfitIfDrawn,
      r.maxRiskLimit,
      r.overLimitAmount,
      r.status,
    ]);
    exportCSV('Summary_Risk.csv', headers, rows);
  };

  const handleExportConfigCSV = () => {
    const headers = ['Type', 'Number', 'PayoutRate', 'MaxRisk', 'Status'];
    const rows = configs.map((c) => [c.type, c.number, c.payoutRate, c.maxRisk, c.status]);
    exportCSV('Config_Settings.csv', headers, rows);
  };

  // Basket Totals & Discount Calculations
  const basketTotalAmount = basket.reduce((s, it) => s + it.amount, 0);
  const basketDiscountAmount = Math.round((basketTotalAmount * (Number(discountPercent) || 0)) / 100);
  const basketNetAmount = basketTotalAmount - basketDiscountAmount;
  const basketTotalKeep = basket.reduce((s, it) => s + it.keepAmount, 0);
  const basketTotalSent = basket.reduce((s, it) => s + it.sentAmount, 0);

  return (
    <div className="min-h-[100dvh] bg-[#020617] text-slate-100 flex flex-col items-center justify-start font-['Prompt',sans-serif] selection:bg-emerald-500 selection:text-slate-950">
      {/* Desktop Mode Switcher Bar (Hidden on actual smartphones < 640px where native S22 fit is automatic) */}
      <div className="hidden sm:flex w-full bg-slate-950/90 border-b border-slate-800/80 px-4 py-1.5 items-center justify-between text-xs z-50">
        <div className="flex items-center gap-2 text-slate-400">
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-semibold text-slate-200">Samsung Galaxy S22 5G</span>
          <span>·</span>
          <span className="text-[11px] font-mono text-slate-400">
            6.1&quot; Dynamic AMOLED 2X · FHD+ (1080×2340 / 360×780px) · 120Hz
          </span>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
          <button
            type="button"
            onClick={() => setIsMobileFrameView(true)}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
              isMobileFrameView
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ขนาดหน้าจอ S22 5G (360×780)
          </button>
          <button
            type="button"
            onClick={() => setIsMobileFrameView(false)}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
              !isMobileFrameView
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ขยายเต็มจอคอมพิวเตอร์
          </button>
        </div>
      </div>

      {/* Main Viewport Shell:
          - On actual smartphones (<640px): 100% native width & height (360x780 on Samsung S22 5G)
          - On desktop in S22 Mode: Exact 360px × 780px (19.5:9) Samsung S22 5G Dynamic AMOLED 2X frame
          - On desktop in Wide Mode: Full max-w-7xl responsive container */}
      <div
        className={`w-full flex flex-col transition-all duration-150 ${
          isMobileFrameView
            ? 'sm:w-[372px] sm:h-[804px] sm:my-3 sm:rounded-[38px] sm:border-[6px] sm:border-slate-800 sm:shadow-[0_0_50px_rgba(16,185,129,0.12)] sm:overflow-hidden bg-[#050811] min-h-[100dvh] sm:min-h-0 relative'
            : 'max-w-7xl min-h-[100dvh] bg-slate-950'
        }`}
      >
        {/* Samsung S22 5G Infinity-O Top Status Bar (Only visible inside desktop S22 frame preview) */}
        {isMobileFrameView && (
          <div className="hidden sm:flex items-center justify-between px-5 pt-1.5 pb-1 bg-[#050811] text-[10px] font-mono text-slate-400 select-none shrink-0">
            <span className="font-semibold text-slate-300">5G · 120Hz</span>
            {/* Infinity-O Punch Hole Camera */}
            <div className="w-3 h-3 rounded-full bg-black border border-slate-800/90 shadow-inner" />
            <span className="text-emerald-400 font-semibold">AMOLED 2X</span>
          </div>
        )}

        {/* Compact Top App Header & 7-Tab Navigation (Fits 360px width with 0 overflow) */}
        <header className="bg-slate-900/95 backdrop-blur-md border-b border-slate-800/90 sticky top-0 z-40 px-2.5 py-1.5 shrink-0">
          <div className="flex flex-col gap-1.5">
            {/* Row 1: Brand + Bill ID + Draw Period | Sound Toggle + Basket */}
            <div className="flex items-center justify-between gap-1">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-slate-950 font-bold shadow-xs shrink-0">
                  <Receipt className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h1 className="font-bold text-xs tracking-tight text-white leading-none whitespace-nowrap">
                      LOTTERY POS
                    </h1>
                    <button
                      type="button"
                      onClick={() => setActiveTab('settings')}
                      className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center gap-0.5 cursor-pointer truncate max-w-[135px]"
                      title="คลิกเพื่อเปลี่ยนงวด หรือปิดงวดเริ่มงวดใหม่"
                    >
                      <Calendar className="w-2.5 h-2.5 shrink-0" />
                      <span className="truncate">{currentDrawPeriod}</span>
                    </button>
                  </div>
                  <div className="text-[10px] text-slate-400 leading-tight mt-0.5 flex items-center gap-1.5">
                    <span>
                      บิล: <strong className="text-sky-400 font-mono">{currentBillId}</strong>
                    </span>
                    {discountPercent > 0 && (
                      <span className="text-indigo-400 font-semibold">
                        · ลด {discountPercent}%
                      </span>
                    )}
                    <span
                      className={`inline-flex items-center gap-1 text-[9px] font-mono px-1.5 py-0.2 rounded ${
                        syncStatus === 'synced'
                          ? 'bg-emerald-500/15 text-emerald-400'
                          : syncStatus === 'syncing'
                          ? 'bg-sky-500/15 text-sky-400'
                          : 'bg-amber-500/15 text-amber-300'
                      }`}
                      title="สถานะการเชื่อมต่อฐานข้อมูล Server"
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          syncStatus === 'synced'
                            ? 'bg-emerald-400'
                            : syncStatus === 'syncing'
                            ? 'bg-sky-400 animate-pulse'
                            : 'bg-amber-400'
                        }`}
                      />
                      <span>
                        {syncStatus === 'synced'
                          ? 'DB Sync'
                          : syncStatus === 'syncing'
                          ? 'Syncing...'
                          : offlineQueueCount > 0
                          ? `Offline(${offlineQueueCount})`
                          : 'Local'}
                      </span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Quick Actions: Sound Mute + Cart */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() =>
                    handleUpdateSoundSettings({
                      ...soundSettings,
                      enabled: !soundSettings.enabled,
                    })
                  }
                  className={`p-1.5 rounded-lg border transition-transform duration-75 active:scale-95 cursor-pointer ${
                    soundSettings.enabled
                      ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/35'
                      : 'bg-slate-800 text-slate-500 border-slate-700'
                  }`}
                  title={
                    soundSettings.enabled
                      ? `เปิดเสียงแจ้งเตือนอยู่ (${soundSettings.volume}%)`
                      : 'ปิดเสียงแจ้งเตือนอยู่'
                  }
                >
                  {soundSettings.enabled ? (
                    <Volume2 className="w-3.5 h-3.5" />
                  ) : (
                    <VolumeX className="w-3.5 h-3.5" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setIsBasketOpen(true)}
                  className="relative px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 cursor-pointer flex items-center gap-1 transition-transform duration-75"
                  title="ดูตะกร้าบิล"
                >
                  <ShoppingCart className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-mono text-[10px] font-bold text-emerald-300">
                    {basket.length}
                  </span>
                </button>
              </div>
            </div>

            {/* Row 2: 7-Tab Navigation Grid fitted for 360px Samsung S22 5G */}
            <nav className="grid grid-cols-7 gap-0.5 bg-slate-950/90 p-0.5 rounded-xl border border-slate-800/80">
              <button
                type="button"
                onClick={() => setActiveTab('pos')}
                className={`py-1 px-0.5 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  activeTab === 'pos'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Smartphone className="w-3 h-3" />
                <span className="leading-none whitespace-nowrap">คีย์เลข</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('grid')}
                className={`py-1 px-0.5 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  activeTab === 'grid'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Grid3X3 className="w-3 h-3" />
                <span className="leading-none whitespace-nowrap">00-99</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('transactions')}
                className={`py-1 px-0.5 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  activeTab === 'transactions'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileSpreadsheet className="w-3 h-3" />
                <span className="leading-none whitespace-nowrap">
                  บิล({transactions.length})
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('risk')}
                className={`py-1 px-0.5 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  activeTab === 'risk'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <ShieldAlert className="w-3 h-3" />
                <span className="leading-none whitespace-nowrap">ความเสี่ยง</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('settlement')}
                className={`py-1 px-0.5 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  activeTab === 'settlement'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Trophy className="w-3 h-3" />
                <span className="leading-none whitespace-nowrap">ตรวจหวย</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('settings')}
                className={`py-1 px-0.5 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  activeTab === 'settings'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Settings className="w-3 h-3" />
                <span className="leading-none whitespace-nowrap">ตั้งค่า</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('gas')}
                className={`py-1 px-0.5 rounded-lg text-[10px] font-bold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  activeTab === 'gas'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-amber-400/90 hover:bg-amber-500/10'
                }`}
              >
                <span className="text-[9px] font-mono leading-none mt-0.5">GS</span>
                <span className="leading-none whitespace-nowrap">Code.gs</span>
              </button>
            </nav>
          </div>
        </header>

        {/* Scrollable Content Area Inside S22 5G Viewport */}
        <main className="flex-1 overflow-y-auto s22-scroll w-full p-2 sm:p-2.5 pb-4">
          {/* Period Lock Protection Banner (หมวด 8: ข้อมูลงวดที่ปิดแล้วห้ามเปลี่ยนโดยไม่ได้รับอนุญาต) */}
          {isPeriodLocked && (
            <div className="mb-2.5 p-2.5 rounded-xl bg-amber-950/90 border border-amber-500/60 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-amber-200">
                <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="font-bold text-amber-300 block">
                    โหมดดูข้อมูลงวดที่ปิดแล้ว ({currentDrawPeriod})
                  </span>
                  <span className="text-[10px] text-amber-200/80">
                    ล็อกการเพิ่ม/แก้ไข/ลบบิลเพื่อป้องกันข้อมูลย้อนหลังเปลี่ยนโดยไม่ได้รับอนุญาต
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setIsPeriodLocked(false);
                    addToast({
                      type: 'warning',
                      title: '🔓 ปลดล็อกการแก้ไขงวดนี้แล้ว',
                      message: `อนุญาตให้แก้ไขข้อมูลใน "${currentDrawPeriod}" ชั่วคราว`,
                    });
                  }}
                  className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 text-[10px] font-bold cursor-pointer"
                >
                  ปลดล็อกแก้ไข
                </button>
                {activeDrawBackup && (
                  <button
                    type="button"
                    onClick={handleReturnToActiveDraw}
                    className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-[10px] font-bold cursor-pointer"
                  >
                    กลับงวดปัจจุบัน
                  </button>
                )}
              </div>
            </div>
          )}

          {activeTab === 'pos' && (
            <div className="flex flex-col items-center">
              {/* POS Container calibrated for 360x780 Samsung S22 5G */}
              <div
                className={`w-full ${
                  isMobileFrameView
                    ? 'max-w-full bg-slate-900/60 rounded-2xl border border-slate-800/80 p-2'
                    : 'max-w-md bg-slate-900/60 rounded-3xl border border-slate-800/80 shadow-xl p-4'
                }`}
              >
                {/* Cut-off Countdown & Market Lock Banner */}
                <CutoffTimerBanner
                  cutoffConfig={cutoffConfig}
                  onUpdateCutoffConfig={handleUpdateCutoffConfig}
                  isMarketClosed={isMarketClosed}
                />

                {/* Customer Name & Discount % Row + Customer Quick Select */}
                <div className="space-y-1.5 mb-2">
                  <div className="grid grid-cols-12 gap-1.5">
                    <div className="col-span-8 relative">
                      <User className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="ชื่อลูกค้า / สายเดินโพย"
                        className="w-full pl-8 pr-2 py-1.5 bg-slate-950/90 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                      />
                    </div>
                    <div className="col-span-4 relative" title="ส่วนลดค่าโพย / ค่าคอมมิชชั่น (%)">
                      <Percent className="w-3 h-3 absolute left-2 top-1/2 -translate-y-1/2 text-indigo-400" />
                      <select
                        value={discountPercent}
                        onChange={(e) => setDiscountPercent(Number(e.target.value))}
                        className="w-full pl-6 pr-1 py-1.5 bg-slate-950/90 border border-indigo-500/40 rounded-xl text-xs text-indigo-300 font-bold focus:outline-none focus:border-indigo-400 cursor-pointer"
                      >
                        <option value={0}>ลด 0%</option>
                        <option value={5}>ลด 5%</option>
                        <option value={10}>ลด 10%</option>
                        <option value={12}>ลด 12%</option>
                        <option value={15}>ลด 15%</option>
                        <option value={20}>ลด 20%</option>
                        <option value={25}>ลด 25%</option>
                        <option value={30}>ลด 30%</option>
                      </select>
                    </div>
                  </div>

                  {/* Quick Customer Chips + Fast Paste LINE Toggle */}
                  <div className="flex items-center justify-between gap-1 flex-wrap">
                    <div className="flex items-center gap-1 flex-wrap">
                      {customers.slice(0, 4).map((c) => {
                        const isSelected = customerName === c.name;
                        return (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => {
                              setCustomerName(c.name);
                              setDiscountPercent(c.defaultDiscountPercent);
                            }}
                            className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold border transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-sky-500 text-slate-950 border-sky-400 font-bold'
                                : 'bg-slate-950/80 text-slate-300 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            {c.name} ({c.defaultDiscountPercent}%)
                          </button>
                        );
                      })}
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowFastPaste(!showFastPaste)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                        showFastPaste
                          ? 'bg-amber-500 text-slate-950 border-amber-400'
                          : 'bg-slate-800 text-amber-300 border-amber-500/30 hover:bg-slate-750'
                      }`}
                    >
                      📋 วางโพย LINE
                    </button>
                  </div>

                  {/* Fast Paste LINE/SMS Accordion */}
                  {showFastPaste && (
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-amber-500/40 space-y-2 animate-in fade-in">
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>วางข้อความโพยหลายบรรทัด (เช่น 38=100x50, 45 บน 200, 38=100 กลับ)</span>
                        <button
                          type="button"
                          onClick={() => setShowFastPaste(false)}
                          className="text-slate-500 hover:text-white cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>
                      <textarea
                        rows={3}
                        value={fastPasteText}
                        onChange={(e) => setFastPasteText(e.target.value)}
                        placeholder={'05 = 100x50\n45 บน 200\n538 = 100x50\n38 = 100 กลับ'}
                        className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-400"
                      />
                      <div className="flex justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => setFastPasteText('')}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-[11px] cursor-pointer"
                        >
                          ล้างข้อความ
                        </button>
                        <button
                          type="button"
                          onClick={handleImportFastPasteToBasket}
                          className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] cursor-pointer"
                        >
                          แปลงเข้าตะกร้าทันที
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* 6 Lottery Type Buttons — All 6 visible in 1 row on 360px Samsung S22 5G */}
                <div className="grid grid-cols-6 gap-1 mb-2">
                  {(
                    [
                      { id: '2ตัวบน', short: '2บน' },
                      { id: '2ตัวล่าง', short: '2ล่าง' },
                      { id: '3ตัวตรง', short: '3ตรง' },
                      { id: '3ตัวโต๊ด', short: '3โต๊ด' },
                      { id: 'วิ่งบน', short: 'วิ่งบน' },
                      { id: 'วิ่งล่าง', short: 'วิ่งล่าง' },
                    ] as { id: LotteryType; short: string }[]
                  ).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectType(item.id)}
                      className={`py-1.5 px-1 rounded-xl text-[11px] font-semibold whitespace-nowrap transition-transform duration-75 active:scale-95 cursor-pointer text-center ${
                        currentType === item.id
                          ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm border border-emerald-400'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-750 border border-slate-700/60'
                      }`}
                    >
                      {item.short}
                    </button>
                  ))}
                </div>

                {/* Digital Screen Display (Number & Amount) */}
                <div
                  className={`bg-slate-950 rounded-2xl p-2.5 border-2 transition-all duration-150 mb-2 shadow-inner ${
                    activeField === 'number'
                      ? 'border-emerald-500/80 shadow-emerald-500/10 shadow-md'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="grid grid-cols-2 gap-2 items-center">
                    {/* Number Field */}
                    <div
                      onClick={() => setActiveField('number')}
                      className="cursor-pointer select-none"
                    >
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>เลข ({currentType})</span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          ({currentNumber.length}/{maxDigitsForType} หลัก)
                        </span>
                      </div>
                      <div className="text-2xl font-bold font-mono tabular-nums text-amber-400 tracking-wider min-h-[32px] flex items-center">
                        {currentNumber ? (
                          currentNumber
                        ) : (
                          <span className="text-slate-600 font-normal text-lg">-</span>
                        )}
                      </div>
                    </div>

                    {/* Amount Field */}
                    <div
                      onClick={() => setActiveField('amount')}
                      className={`text-right cursor-pointer select-none px-2 py-1 rounded-xl transition-all ${
                        activeField === 'amount' ? 'bg-slate-900 border border-emerald-500/40' : ''
                      }`}
                    >
                      <div className="text-[10px] text-slate-400">จำนวนเงิน (บาท)</div>
                      <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400 tracking-tight min-h-[32px] flex items-center justify-end">
                        ฿{currentAmount ? Number(currentAmount).toLocaleString() : '0'}
                      </div>
                    </div>
                  </div>

                  {/* Live Real-time Risk Validation Alert Banner */}
                  <div className="mt-1.5 pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 overflow-hidden">
                      {!isNumberComplete && currentNumber.length > 0 ? (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40 whitespace-nowrap">
                          <AlertTriangle className="w-2.5 h-2.5 text-sky-400" />
                          <span>รอครบ {maxDigitsForType} หลัก</span>
                        </span>
                      ) : !isNumberComplete && currentNumber.length === 0 ? (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-700 whitespace-nowrap">
                          <span>รอระบุเลข</span>
                        </span>
                      ) : liveEvaluation.alertType === 'green' ? (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 whitespace-nowrap">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          <span>ปกติ</span>
                        </span>
                      ) : liveEvaluation.alertType === 'yellow' ? (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/50 whitespace-nowrap">
                          <AlertTriangle className="w-2.5 h-2.5" />
                          <span>{liveEvaluation.status}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/50 whitespace-nowrap">
                          <Ban className="w-2.5 h-2.5" />
                          <span>ปิดรับ</span>
                        </span>
                      )}

                      <span className="text-[10px] text-slate-400 truncate">
                        {!isNumberComplete && currentNumber.length > 0
                          ? maxDigitsForType === 2
                            ? `ต้องใส่ 2 หลัก เช่น 0${currentNumber} หรือ ${currentNumber}0`
                            : `ต้องใส่ครบ 3 หลัก เช่น 0xx, x0x, xx0`
                          : !isNumberComplete
                          ? `ใส่เลข ${maxDigitsForType} หลัก (มี 0 ใส่ 0x, x0)`
                          : liveEvaluation.alertMessage}
                      </span>
                    </div>

                    <div className="text-right text-[10px] whitespace-nowrap pl-1.5 shrink-0">
                      <span className="text-slate-400">จ่าย:</span>{' '}
                      <span className="font-mono font-bold text-slate-200">
                        {liveEvaluation.payoutRate}
                      </span>
                      บ.
                    </div>
                  </div>
                </div>

                {/* Quick Amounts */}
                <div className="grid grid-cols-6 gap-1 mb-1.5">
                  {[10, 20, 50, 100, 500, 1000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => handleQuickAmount(amt)}
                      className="py-1 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 rounded-lg text-[11px] font-mono font-semibold border border-slate-700/60 transition-transform duration-75 cursor-pointer"
                    >
                      {amt}
                    </button>
                  ))}
                </div>

                {/* Thai Lottery Shortcuts Row */}
                <div className="grid grid-cols-4 gap-1 mb-2">
                  <button
                    type="button"
                    onClick={() => handleShortcut('reverse')}
                    className="py-1.5 px-1 bg-indigo-950/50 hover:bg-indigo-900/60 active:scale-95 text-indigo-300 rounded-xl text-[11px] font-semibold border border-indigo-700/50 flex items-center justify-center gap-1 transition-transform duration-75 cursor-pointer"
                    title="กลับเลข (2 ตัวกลับ, 3 ตัวกลับ 6 ประตู)"
                  >
                    <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span>กลับเลข</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleShortcut('19door')}
                    className="py-1.5 px-1 bg-indigo-950/50 hover:bg-indigo-900/60 active:scale-95 text-indigo-300 rounded-xl text-[11px] font-semibold border border-indigo-700/50 flex items-center justify-center gap-1 transition-transform duration-75 cursor-pointer"
                    title="19 ประตู (สำหรับเลข 2 ตัว)"
                  >
                    <DoorOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span>19ประตู</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleShortcut('swipeFront')}
                    className="py-1.5 px-1 bg-indigo-950/50 hover:bg-indigo-900/60 active:scale-95 text-indigo-300 rounded-xl text-[11px] font-semibold border border-indigo-700/50 flex items-center justify-center gap-1 transition-transform duration-75 cursor-pointer"
                    title="รูดหน้า (0d - 9d)"
                  >
                    <ArrowRightToLine className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span>รูดหน้า</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleShortcut('swipeBack')}
                    className="py-1.5 px-1 bg-indigo-950/50 hover:bg-indigo-900/60 active:scale-95 text-indigo-300 rounded-xl text-[11px] font-semibold border border-indigo-700/50 flex items-center justify-center gap-1 transition-transform duration-75 cursor-pointer"
                    title="รูดหลัง (d0 - d9)"
                  >
                    <ArrowLeftToLine className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span>รูดหลัง</span>
                  </button>
                </div>

                {/* Custom 120Hz Mobile Numpad */}
                <div className="mb-2">
                  <Numpad
                    onKeyPress={handleNumpadKey}
                    onClear={handleNumpadClear}
                    onDelete={handleNumpadDelete}
                  />
                </div>

                {/* Add to Basket Button */}
                {isMarketClosed ? (
                  <button
                    type="button"
                    onClick={() =>
                      handleUpdateCutoffConfig({
                        ...cutoffConfig,
                        manualForceClosed: false,
                        enabled: false,
                      })
                    }
                    className="w-full py-2.5 px-3 rounded-xl bg-rose-950/90 hover:bg-rose-900 border border-rose-500/70 text-rose-200 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-lg transition-all"
                  >
                    <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>ปิดรับแทงอยู่ (แตะเพื่อเปิดรับโพยต่อ)</span>
                  </button>
                ) : !isNumberComplete ? (
                  <button
                    type="button"
                    disabled
                    className="w-full py-2.5 px-3 rounded-xl bg-slate-800 border border-slate-700/80 text-slate-400 font-bold text-xs flex items-center justify-center gap-1.5 cursor-not-allowed opacity-85 select-none"
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span className="truncate">
                      {currentNumber.length === 0
                        ? `ระบุเลขให้ครบ ${maxDigitsForType} หลัก (เช่น ${maxDigitsForType === 2 ? '0x หรือ x0' : '0xx, x0x, xx0'})`
                        : maxDigitsForType === 2
                        ? `เลข 2 ตัวต้องใส่ 2 หลัก (เช่น 0${currentNumber} หรือ ${currentNumber}0)`
                        : `เลข 3 ตัวต้องใส่ 3 หลัก (${currentNumber.length}/3)`}
                    </span>
                  </button>
                ) : liveEvaluation.alertType === 'red' || !liveEvaluation.canAccept ? (
                  <button
                    type="button"
                    disabled
                    className="w-full py-2.5 px-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-400 font-bold text-xs flex items-center justify-center gap-1.5 cursor-not-allowed opacity-80"
                  >
                    <Ban className="w-4 h-4" />
                    <span>เลขปิดรับ (เต็มเพดานความเสี่ยง)</span>
                  </button>
                ) : liveEvaluation.alertType === 'yellow' ? (
                  <button
                    type="button"
                    onClick={handleAddToBasket}
                    className="w-full py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-transform duration-75 shadow-md shadow-amber-500/20 cursor-pointer"
                  >
                    <AlertTriangle className="w-4 h-4" />
                    <span>
                      {liveEvaluation.status === 'อั้นจ่าย'
                        ? `เพิ่มลงตะกร้า (เลขอั้นจ่าย ${liveEvaluation.payoutRate} บ.)`
                        : `เพิ่มลงตะกร้า (เกินเพดาน · ตีเกินส่งต่อ)`}
                    </span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleAddToBasket}
                    className="w-full py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98] text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-transform duration-75 shadow-md shadow-emerald-500/25 cursor-pointer"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>เพิ่มลงตะกร้า</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* 10x10 Number Grid Tab (00-99 Multi-Selection) */}
          {activeTab === 'grid' && (
            <div>
              <CutoffTimerBanner
                cutoffConfig={cutoffConfig}
                onUpdateCutoffConfig={handleUpdateCutoffConfig}
                isMarketClosed={isMarketClosed}
              />
              <GridSelectorView
                configs={configs}
                transactions={transactions}
                basket={basket}
                onAddBatchToBasket={handleAddGridBatchToBasket}
                onOpenBasket={() => setIsBasketOpen(true)}
                onNumberRiskSound={(alertType) => {
                  if (alertType === 'closed') {
                    playClosedErrorSound(soundSettings);
                  } else {
                    playHalfPayWarningSound(soundSettings);
                  }
                }}
              />
            </div>
          )}

          {/* Transactions Tab */}
          {activeTab === 'transactions' && (
            <TransactionsTable
              transactions={transactions}
              isPeriodLocked={isPeriodLocked}
              onExportCSV={handleExportTransactionsCSV}
              onViewReceipt={handleViewPastReceipt}
              onDeleteBill={handleDeleteBill}
              onEditBill={handleEditBill}
              onRebetBill={handleRebetBill}
            />
          )}

          {/* Risk Summary Tab */}
          {activeTab === 'risk' && (
            <RiskSummaryView
              summaryRisks={summaryRisks}
              transactions={transactions}
              configs={configs}
              onExportCSV={handleExportSummaryRiskCSV}
            />
          )}

          {/* Result & Settlement Tab */}
          {activeTab === 'settlement' && (
            <ResultSettlementView
              transactions={transactions}
              configs={configs}
              drawPeriod={currentDrawPeriod}
              onViewReceipt={handleViewPastReceipt}
              onArchiveCurrentDraw={(top3, bottom2) =>
                handleArchiveAndStartNewDraw('งวดใหม่', top3, bottom2)
              }
            />
          )}

          {/* Config Settings & Draw Archive Tab */}
          {activeTab === 'settings' && (
            <ConfigSettingsView
              configs={configs}
              soundSettings={soundSettings}
              onUpdateSoundSettings={handleUpdateSoundSettings}
              currentDrawPeriod={currentDrawPeriod}
              onUpdateDrawPeriod={handleUpdateDrawPeriod}
              archivedDraws={archivedDraws}
              currentTransactionsCount={transactions.length}
              onArchiveAndStartNewDraw={(nextName) => handleArchiveAndStartNewDraw(nextName)}
              onRestoreArchivedDraw={handleRestoreArchivedDraw}
              onDeleteArchivedDraw={handleDeleteArchivedDraw}
              onExportArchivedDrawCSV={handleExportArchivedDrawCSV}
              onAddConfig={handleAddConfig}
              onDeleteConfig={handleDeleteConfig}
              onResetDefault={handleResetDefault}
              onExportCSV={handleExportConfigCSV}
              customers={customers}
              onSaveCustomer={handleSaveCustomer}
              onDeleteCustomer={handleDeleteCustomer}
              auditLogs={auditLogs}
              integrityReport={integrityReport}
              onExportFullBackup={handleExportFullBackup}
              onRestoreFullBackup={handleRestoreFullBackup}
            />
          )}

          {/* Google Apps Script Source Code & Guide Tab */}
          {activeTab === 'gas' && (
            <GoogleAppsScriptExport
              codeGsSource={CODE_GS_SOURCE}
              indexHtmlSource={INDEX_HTML_SOURCE}
            />
          )}
        </main>

        {/* Bottom Slip Bar (POS Mode) — Anchored inside S22 5G Viewport */}
        {activeTab === 'pos' && (
          <div className="bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-3 py-2 z-30 shrink-0">
            <div className="max-w-md mx-auto flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[10px] text-slate-400 flex items-center gap-1">
                  <span>ตะกร้า ({basket.length} รายการ)</span>
                  {discountPercent > 0 && (
                    <span className="px-1 py-0.2 rounded bg-indigo-500/20 text-indigo-300 font-bold text-[9px]">
                      ลด {discountPercent}%
                    </span>
                  )}
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-base font-bold font-mono tabular-nums text-amber-400">
                    ฿{basketNetAmount.toLocaleString()}
                  </span>
                  {discountPercent > 0 && basketTotalAmount > 0 && (
                    <span className="text-[11px] font-mono text-slate-500 line-through">
                      ฿{basketTotalAmount.toLocaleString()}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                {basket.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearBasket}
                    className="py-2 px-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 active:scale-95 text-rose-400 font-semibold text-xs border border-rose-500/30 flex items-center gap-1 cursor-pointer transition-transform duration-75"
                    title="ล้างตะกร้าทั้งหมด"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setIsBasketOpen(true)}
                  className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center gap-1 cursor-pointer transition-transform duration-75"
                >
                  <ShoppingCart className="w-3.5 h-3.5 text-emerald-400" />
                  <span>ตะกร้า</span>
                  {basket.length > 0 && (
                    <span className="bg-emerald-500 text-slate-950 font-bold text-[10px] px-1.5 rounded-full">
                      {basket.length}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  disabled={basket.length === 0}
                  onClick={handleConfirmSaveBill}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center gap-1 transition-transform duration-75 cursor-pointer ${
                    basket.length > 0
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20 active:scale-95'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>ยืนยันบิล</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Samsung S22 5G Gesture Navigation Pill (Only visible inside desktop S22 frame preview) */}
        {isMobileFrameView && (
          <div className="hidden sm:flex justify-center py-1.5 bg-[#050811] shrink-0">
            <div className="w-28 h-1 rounded-full bg-slate-700/80" />
          </div>
        )}
      </div>

      {/* Basket Drawer / Slide-Over */}
      {isBasketOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-slate-900 border-l border-slate-800 max-w-md w-full h-full flex flex-col shadow-2xl">
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-bold text-base text-slate-100 leading-tight">
                    ตะกร้าบิล ({basket.length} รายการ)
                  </h3>
                  <span className="text-[11px] text-emerald-400 font-medium">
                    {currentDrawPeriod}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsBasketOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Risk Breakdown Chips */}
            <div className="p-3 bg-slate-950 border-b border-slate-800/80 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 rounded-xl bg-slate-800/60">
                <span className="text-[10px] text-slate-400 block">ยอดหน้าโพย</span>
                <span className="font-mono font-bold text-slate-100">
                  ฿{basketTotalAmount.toLocaleString()}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-emerald-950/30 border border-emerald-800/40">
                <span className="text-[10px] text-emerald-400 block">ยอดถือเอง</span>
                <span className="font-mono font-bold text-emerald-400">
                  ฿{basketTotalKeep.toLocaleString()}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-rose-950/30 border border-rose-800/40">
                <span className="text-[10px] text-rose-400 block">ส่งต่อ (ตีเกิน)</span>
                <span className="font-mono font-bold text-rose-400">
                  ฿{basketTotalSent.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Customer Info & Discount % in Drawer */}
            <div className="px-4 py-3 bg-slate-850 border-b border-slate-800 space-y-2.5">
              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-8">
                  <label className="text-[11px] text-slate-400 block mb-1">
                    บิล: <strong className="text-sky-400 font-mono">{currentBillId}</strong> • ชื่อลูกค้า
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="ระบุชื่อลูกค้า (เช่น นาย ก)"
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div className="col-span-4">
                  <label className="text-[11px] text-indigo-300 font-semibold block mb-1">
                    ส่วนลดค่าโพย (%)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min={0}
                      max={50}
                      value={discountPercent}
                      onChange={(e) =>
                        setDiscountPercent(Math.max(0, Math.min(50, Number(e.target.value) || 0)))
                      }
                      className="w-full px-2.5 py-1.5 bg-slate-900 border border-indigo-500/50 rounded-lg text-xs font-mono font-bold text-indigo-300 text-center focus:outline-none"
                    />
                    <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">
                      %
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Discount % Chips */}
              <div className="flex items-center gap-1 flex-wrap">
                <span className="text-[10px] text-slate-400 mr-1">ลดด่วน:</span>
                {[0, 5, 10, 12, 15, 20, 25, 30].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setDiscountPercent(pct)}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold cursor-pointer transition-all ${
                      discountPercent === pct
                        ? 'bg-indigo-500 text-white shadow-xs'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            {/* Item List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {basket.length === 0 ? (
                <div className="text-center py-16 text-slate-500">
                  <ShoppingCart className="w-12 h-12 mx-auto stroke-1 mb-2 opacity-50" />
                  <p className="text-sm">ยังไม่มีรายการในตะกร้า</p>
                  <p className="text-xs text-slate-600 mt-1">
                    เลือกประเภท ใส่เลข และระบุราคาเพื่อเพิ่มบิล
                  </p>
                </div>
              ) : (
                basket.map((item, idx) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-between hover:border-slate-600 transition-all"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-400 font-mono">#{idx + 1}</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            item.status === 'ปกติ'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {item.status}
                        </span>
                        <span className="text-xs font-semibold text-slate-300">{item.type}</span>
                        <span className="text-base font-bold font-mono text-amber-400">
                          {item.number}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
                        <span>
                          ถือเอง: <strong className="text-emerald-400 font-mono">฿{item.keepAmount.toLocaleString()}</strong>
                        </span>
                        {item.sentAmount > 0 && (
                          <span>
                            ตีเกิน: <strong className="text-rose-400 font-mono">฿{item.sentAmount.toLocaleString()}</strong>
                          </span>
                        )}
                        <span>จ่าย: {item.payoutRate} บ.</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-sm text-slate-100">
                        ฿{item.amount.toLocaleString()}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveBasketItem(item.id)}
                        className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-700/60 cursor-pointer"
                        title="ลบรายการนี้"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Drawer Footer Actions */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/90 space-y-2">
              {discountPercent > 0 && basketTotalAmount > 0 && (
                <div className="space-y-1 pb-1.5 border-b border-slate-800/80 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>ยอดรวมหน้าโพย:</span>
                    <span className="font-mono">฿{basketTotalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-indigo-400 font-semibold">
                    <span>หักส่วนลดค่าโพย ({discountPercent}%):</span>
                    <span className="font-mono">-฿{basketDiscountAmount.toLocaleString()}</span>
                  </div>
                </div>
              )}

              <div className="flex justify-between items-center text-sm font-semibold mb-2">
                <span className="text-slate-300">
                  {discountPercent > 0 ? 'ยอดรับชำระสุทธิ:' : 'รวมทั้งสิ้น:'}
                </span>
                <span className="text-xl font-bold font-mono text-emerald-400">
                  ฿{basketNetAmount.toLocaleString()}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleClearBasket}
                  disabled={!basket.length}
                  className="py-2.5 px-3 rounded-xl border border-rose-500/30 bg-rose-950/20 hover:bg-rose-950/40 text-rose-400 font-semibold text-xs flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer active:scale-95 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>ล้างตะกร้า</span>
                </button>
                <button
                  type="button"
                  onClick={handleConfirmSaveBill}
                  disabled={!basket.length}
                  className="py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 disabled:opacity-50 cursor-pointer transition-all"
                >
                  <Check className="w-4 h-4" />
                  <span>ยืนยันบันทึกบิล</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Yellow Alert Modal (เลขอั้นจ่าย Confirmation) */}
      <HalfPayConfirmModal
        isOpen={halfPayModalOpen}
        evaluation={pendingHalfPayData ? pendingHalfPayData.evalResult : null}
        type={pendingHalfPayData ? pendingHalfPayData.type : ''}
        number={pendingHalfPayData ? pendingHalfPayData.number : ''}
        amount={pendingHalfPayData ? pendingHalfPayData.amount : 0}
        onConfirm={handleConfirmHalfPay}
        onCancel={() => {
          setHalfPayModalOpen(false);
          setPendingHalfPayData(null);
        }}
      />

      {/* Slip Receipt Modal */}
      {lastSavedBill && (
        <SlipReceiptModal
          isOpen={receiptModalOpen}
          billId={lastSavedBill.billId}
          customerName={lastSavedBill.customerName}
          timestamp={lastSavedBill.timestamp}
          drawPeriod={lastSavedBill.drawPeriod}
          discountPercent={lastSavedBill.discountPercent}
          items={lastSavedBill.items}
          onClose={() => setReceiptModalOpen(false)}
        />
      )}

      {/* Toast Notification Container */}
      <ToastNotification toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
