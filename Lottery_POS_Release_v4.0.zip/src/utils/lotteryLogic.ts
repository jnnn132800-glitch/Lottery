import {
  ConfigRule,
  RiskStatus,
  Transaction,
  SummaryRisk,
  BasketItem,
  CustomerProfile,
  ArchivedDraw,
  BillPaymentRecord,
  AuditLogEntry,
  DataIntegrityIssue,
  DataIntegrityReport,
  SystemBackupPayload,
} from '../types/lottery';

/**
 * Permutations helper for Thai Lottery
 */
export function getPermutations(str: string): string[] {
  if (str.length <= 1) return [str];
  const results = new Set<string>();

  const permute = (arr: string[], m: string[] = []) => {
    if (arr.length === 0) {
      results.add(m.join(''));
    } else {
      for (let i = 0; i < arr.length; i++) {
        const curr = arr.slice();
        const next = curr.splice(i, 1);
        permute(curr.slice(), m.concat(next));
      }
    }
  };

  permute(str.split(''));
  return Array.from(results).sort();
}

/**
 * กลับเลข (Reverse / Permutations)
 * - 2 ตัว: 38 -> [38, 83]
 * - 3 ตัว: 538 -> [538, 583, 358, 385, 853, 835]
 */
export function reverseNumber(num: string): string[] {
  if (!num) return [];
  if (num.length === 2 || num.length === 3) {
    return getPermutations(num);
  }
  return [num];
}

/**
 * 19 ประตู (19 Doors)
 * Input 1 digit (0-9) -> returns all 19 2-digit numbers containing that digit
 * e.g. '8' -> 08, 18, 28, 38, 48, 58, 68, 78, 88, 98, 80, 81, 82, 83, 84, 85, 86, 87, 89
 */
export function nineteenDoors(digit: string): string[] {
  if (!digit || digit.length !== 1 || !/^\d$/.test(digit)) return [];
  const d = digit;
  const list: string[] = [];
  // Swipe back (0d -> 9d)
  for (let i = 0; i <= 9; i++) {
    list.push(`${i}${d}`);
  }
  // Swipe front (d0 -> d9, skip dd since already added)
  for (let i = 0; i <= 9; i++) {
    const n = `${d}${i}`;
    if (!list.includes(n)) {
      list.push(n);
    }
  }
  return list;
}

/**
 * รูดหน้า (Swipe Front)
 * Input 1 digit -> d0, d1, ..., d9 (10 numbers)
 */
export function swipeFront(digit: string): string[] {
  if (!digit || digit.length !== 1 || !/^\d$/.test(digit)) return [];
  const list: string[] = [];
  for (let i = 0; i <= 9; i++) {
    list.push(`${digit}${i}`);
  }
  return list;
}

/**
 * รูดหลัง (Swipe Back)
 * Input 1 digit -> 0d, 1d, ..., 9d (10 numbers)
 */
export function swipeBack(digit: string): string[] {
  if (!digit || digit.length !== 1 || !/^\d$/.test(digit)) return [];
  const list: string[] = [];
  for (let i = 0; i <= 9; i++) {
    list.push(`${i}${digit}`);
  }
  return list;
}

/**
 * Normalize a 1, 2, or 3 digit lottery number string while preserving leading zeros
 */
export function normalizeLotteryNumber(num: string, type: string): string {
  const digitsOnly = String(num ?? '').replace(/\D/g, '');
  if (!digitsOnly) return '';
  if (type.startsWith('3')) {
    return digitsOnly.slice(0, 3).padStart(3, '0');
  }
  if (type.startsWith('2')) {
    return digitsOnly.slice(0, 2).padStart(2, '0');
  }
  return digitsOnly.slice(0, 1);
}

/**
 * Validate whether a lottery number string matches the exact digit length for its type
 */
export function isValidLotteryNumber(num: string, type: string): boolean {
  const clean = String(num ?? '').trim();
  if (type.startsWith('3')) return /^\d{3}$/.test(clean);
  if (type.startsWith('2')) return /^\d{2}$/.test(clean);
  if (type.startsWith('วิ่ง')) return /^\d{1}$/.test(clean);
  return /^\d{1,3}$/.test(clean);
}

/**
 * Look up Config rule for (type, number)
 */
export function findConfigRule(type: string, number: string, configSettings: ConfigRule[]): ConfigRule {
  // 1. Look for exact number match
  const exact = configSettings.find((r) => r.type === type && r.number === number);
  if (exact) {
    return {
      ...exact,
      payoutRate: Math.max(0, Number(exact.payoutRate) || 0),
      maxRisk: Math.max(0, Number(exact.maxRisk) || 0),
    };
  }

  // 2. Look for wildcard '*' match
  const wildcard = configSettings.find((r) => r.type === type && r.number === '*');
  if (wildcard) {
    return {
      ...wildcard,
      payoutRate: Math.max(0, Number(wildcard.payoutRate) || 0),
      maxRisk: Math.max(0, Number(wildcard.maxRisk) || 0),
    };
  }

  // Fallback default
  return {
    type,
    number: '*',
    payoutRate: type.startsWith('3ตัวต') && type.includes('โต๊ด')
      ? 150
      : type.startsWith('3')
      ? 900
      : type.startsWith('2')
      ? 90
      : type === 'วิ่งล่าง'
      ? 4.2
      : 3.2,
    maxRisk: 20000,
    status: 'ปกติ',
  };
}

/**
 * Get the historical payout rate at the time a transaction was accepted.
 * Falls back to ConfigRule only if legacy data did not store payoutRate.
 */
export function getTransactionPayoutRate(
  tx: Transaction,
  configSettings: ConfigRule[]
): number {
  if (tx.status === 'ปิดรับ') return 0;
  if (typeof tx.payoutRate === 'number' && !isNaN(tx.payoutRate) && tx.payoutRate >= 0) {
    return tx.payoutRate;
  }
  const rule = findConfigRule(tx.type, tx.number, configSettings);
  return Math.max(0, Number(rule.payoutRate) || 0);
}

/**
 * Reconcile keepAmount and sentAmount chronologically across all transactions
 * whenever a bill is voided/deleted or edited, while preserving each transaction's
 * historical payoutRate at the time of sale.
 */
export function reconcileTransactionsRisk(
  transactions: Transaction[],
  configSettings: ConfigRule[]
): Transaction[] {
  const accumulatedByKey: Record<string, number> = {};

  return transactions.map((tx) => {
    const historicalRate = getTransactionPayoutRate(tx, configSettings);

    // Closed ('ปิดรับ') rows do not consume risk limit or hold keepAmount
    if (tx.status === 'ปิดรับ') {
      return {
        ...tx,
        payoutRate: 0,
        keepAmount: 0,
        sentAmount: Math.max(0, Number(tx.sentAmount) || Number(tx.amount) || 0),
      };
    }

    const rule = findConfigRule(tx.type, tx.number, configSettings);
    const key = `${tx.type}_${tx.number}`;
    const prevAccumulated = accumulatedByKey[key] || 0;
    const amt = Math.max(0, Number(tx.amount) || 0);

    // Effective maxRisk from current rule (if rule was later closed, keep existing maxRisk or 0)
    const maxRiskLimit = Math.max(0, Number(rule.maxRisk) || 0);
    const availableRoom = Math.max(0, maxRiskLimit - prevAccumulated);
    const keepAmount = Math.min(amt, availableRoom);
    const sentAmount = amt - keepAmount;

    accumulatedByKey[key] = prevAccumulated + amt;

    return {
      ...tx,
      amount: amt,
      payoutRate: historicalRate,
      keepAmount,
      sentAmount,
    };
  });
}

/**
 * Evaluate Risk for a single item before adding to basket
 */
export interface RiskEvaluationResult {
  rule: ConfigRule;
  status: RiskStatus;
  payoutRate: number;
  maxRiskLimit: number;
  currentAccumulated: number;
  newTotal: number;
  keepAmount: number;
  sentAmount: number;
  canAccept: boolean;
  alertType: 'green' | 'yellow' | 'red';
  alertMessage: string;
}

export function evaluateNumberRisk(
  type: string,
  number: string,
  amount: number,
  configSettings: ConfigRule[],
  transactions: Transaction[],
  basketItems: BasketItem[] = []
): RiskEvaluationResult {
  const rule = findConfigRule(type, number, configSettings);
  const cleanAmount = Math.max(0, Number(amount) || 0);

  // Calculate current accumulated risk from past active transactions (exclude 'ปิดรับ')
  const txTotal = transactions
    .filter((t) => t.type === type && t.number === number && t.status !== 'ปิดรับ')
    .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

  // Plus items in current basket for the same (type, number)
  const basketTotal = basketItems
    .filter((b) => b.type === type && b.number === number && b.status !== 'ปิดรับ')
    .reduce((sum, b) => sum + (Number(b.amount) || 0), 0);

  const currentAccumulated = txTotal + basketTotal;
  const newTotal = currentAccumulated + cleanAmount;

  let status: RiskStatus = rule.status;
  let canAccept = true;
  let alertType: 'green' | 'yellow' | 'red' = 'green';
  let alertMessage = 'บันทึกได้ปกติ';
  let keepAmount = 0;
  let sentAmount = 0;

  // Case 1: Config is explicitly 'ปิดรับ' or MaxRisk is 0
  if (rule.status === 'ปิดรับ' || rule.maxRisk <= 0) {
    status = 'ปิดรับ';
    canAccept = false;
    alertType = 'red';
    alertMessage = `เลข ${number} ปิดรับแทง (เต็มเพดานความเสี่ยง 0 บาท)`;
    keepAmount = 0;
    sentAmount = cleanAmount;
    return {
      rule,
      status,
      payoutRate: rule.payoutRate,
      maxRiskLimit: rule.maxRisk,
      currentAccumulated,
      newTotal,
      keepAmount,
      sentAmount,
      canAccept,
      alertType,
      alertMessage,
    };
  }

  // Room remaining to hold
  const availableRoom = Math.max(0, rule.maxRisk - currentAccumulated);

  if (cleanAmount > 0) {
    keepAmount = Math.min(cleanAmount, availableRoom);
    sentAmount = cleanAmount - keepAmount;
  }

  // Case 2: Config is 'อั้นจ่าย' (e.g. half price / special payout rate)
  if (rule.status === 'อั้นจ่าย') {
    status = 'อั้นจ่าย';
    canAccept = true;
    alertType = 'yellow';
    alertMessage = `เลขอั้นจ่าย! อัตราจ่ายพิเศษ ${rule.payoutRate} บาท (เพดาน ${rule.maxRisk.toLocaleString()} บ.)`;
    if (sentAmount > 0) {
      alertMessage += ` | ตีเกินส่งต่อ ${sentAmount.toLocaleString()} บ.`;
    }
  } else if (newTotal > rule.maxRisk) {
    // Normal rule but exceeded maxRisk limit
    if (availableRoom === 0) {
      // Completely filled maxRisk, all must be sent or closed
      alertType = 'yellow';
      alertMessage = `ยอดถือเต็มเพดาน (${rule.maxRisk.toLocaleString()} บ.) ยอดทั้งหมด ${sentAmount.toLocaleString()} บ. จะเป็นยอดตีเกิน (ส่งต่อ)`;
    } else {
      alertType = 'yellow';
      alertMessage = `เกินเพดานความเสี่ยง! ถือเองได้ ${keepAmount.toLocaleString()} บ. ตีเกินส่งต่อ ${sentAmount.toLocaleString()} บ.`;
    }
  } else {
    // Normal green
    status = 'ปกติ';
    alertType = 'green';
    alertMessage = `ปกติ อัตราจ่าย ${rule.payoutRate} บ. (เหลือเพดาน ${Math.max(0, rule.maxRisk - newTotal).toLocaleString()} บ.)`;
  }

  return {
    rule,
    status,
    payoutRate: rule.payoutRate,
    maxRiskLimit: rule.maxRisk,
    currentAccumulated,
    newTotal,
    keepAmount,
    sentAmount,
    canAccept,
    alertType,
    alertMessage,
  };
}

/**
 * Re-calculate Summary Risk table from Transactions with estimated profit & payout calculations.
 * Uses each transaction's historical payoutRate at the time of sale and excludes 'ปิดรับ' from active liability.
 */
export function calculateSummaryRisk(
  transactions: Transaction[],
  configSettings: ConfigRule[]
): SummaryRisk[] {
  const map = new Map<
    string,
    {
      type: string;
      number: string;
      totalAmount: number;
      keepAmount: number;
      sentAmount: number;
      historicalPotentialPayout: number;
      latestPayoutRate: number;
      hasActiveTx: boolean;
      allClosed: boolean;
    }
  >();

  // Category revenue held map (only from valid active bets)
  const categoryKeepMap: Record<string, number> = {};

  transactions.forEach((tx) => {
    const key = `${tx.type}_${tx.number}`;
    const isClosed = tx.status === 'ปิดรับ';
    const txRate = getTransactionPayoutRate(tx, configSettings);

    const curr = map.get(key) || {
      type: tx.type,
      number: tx.number,
      totalAmount: 0,
      keepAmount: 0,
      sentAmount: 0,
      historicalPotentialPayout: 0,
      latestPayoutRate: txRate,
      hasActiveTx: false,
      allClosed: true,
    };

    const amt = Math.max(0, Number(tx.amount) || 0);
    const keep = isClosed ? 0 : Math.max(0, Number(tx.keepAmount) || 0);
    const sent = isClosed
      ? Math.max(0, Number(tx.sentAmount) || amt)
      : Math.max(0, Number(tx.sentAmount) || 0);

    curr.totalAmount += amt;
    curr.keepAmount += keep;
    curr.sentAmount += sent;
    curr.historicalPotentialPayout += keep * txRate;
    if (!isClosed) {
      curr.latestPayoutRate = txRate;
      curr.hasActiveTx = true;
      curr.allClosed = false;
    }
    map.set(key, curr);

    if (!isClosed) {
      categoryKeepMap[tx.type] = (categoryKeepMap[tx.type] || 0) + keep;
    }
  });

  const list: SummaryRisk[] = [];
  map.forEach((item) => {
    const rule = findConfigRule(item.type, item.number, configSettings);
    const isClosedItem = item.allClosed || rule.status === 'ปิดรับ';
    const effectiveRate = item.hasActiveTx
      ? item.keepAmount > 0
        ? Number((item.historicalPotentialPayout / item.keepAmount).toFixed(2))
        : item.latestPayoutRate
      : rule.payoutRate;
    const overLimit = item.sentAmount;
    const potentialPayout = isClosedItem && !item.hasActiveTx ? 0 : item.historicalPotentialPayout;
    const categoryRevenue = categoryKeepMap[item.type] || 0;
    const estimatedProfitIfDrawn = categoryRevenue - potentialPayout;

    list.push({
      type: item.type,
      number: item.number,
      totalAmount: item.totalAmount,
      maxRiskLimit: rule.maxRisk,
      overLimitAmount: overLimit,
      keepAmount: item.keepAmount,
      sentAmount: item.sentAmount,
      payoutRate: effectiveRate,
      potentialPayout,
      estimatedProfitIfDrawn,
      status: rule.status,
    });
  });

  // Sort by overLimit desc, then totalAmount desc
  list.sort((a, b) => b.overLimitAmount - a.overLimitAmount || b.totalAmount - a.totalAmount);
  return list;
}

export interface CategoryProfitBreakdown {
  type: string;
  numbersCount: number;
  totalAmount: number;
  keepAmount: number;
  sentAmount: number;
  maxPayoutNumber: string;
  maxPayoutRate: number;
  maxPayoutInCategory: number; // กรณีเลขที่มียอดจ่ายสูงสุดในหมวดนี้ออก
  sumAllPayoutsInCategory: number; // ผลรวมยอดจ่ายรางวัลตามเรทของทุกเลขในหมวดนี้
  estimatedProfitVsMaxPayout: number; // keepAmount - maxPayoutInCategory
  estimatedProfitVsSumAll: number; // keepAmount - sumAllPayoutsInCategory
}

/**
 * Expected Profit and Risk Metrics
 */
export interface ProfitSummaryMetrics {
  totalGrossSales: number;
  totalKeepHeld: number;
  totalSentOut: number;
  bestCaseProfit: number; // No winner: keeps 100% of held stakes
  worstCaseNetProfit: number; // If the highest-payout number wins (totalKeepHeld - worstCasePayout)
  worstCaseNumber: string;
  worstCaseType: string;
  worstCasePayout: number;
  totalAllPayoutExposure: number; // ผลรวมการจ่ายรางวัลตามเรทของทุกเลขรวมกัน
  estimatedProfitVsAllExposure: number; // totalKeepHeld - totalAllPayoutExposure
  combinedMaxCategoryPayout: number; // ผลรวมการจ่ายรางวัลสูงสุดของแต่ละหมวดรวมกัน
  estimatedProfitVsCombinedMax: number; // totalKeepHeld - combinedMaxCategoryPayout
  totalEstimatedPayoutExpected: number; // ค่าคาดหมายการจ่ายรางวัลตามความน่าจะเป็น
  expectedProfitAverage: number; // totalKeepHeld - totalEstimatedPayoutExpected
  expectedProfitRate: number; // %
  categoryBreakdowns: CategoryProfitBreakdown[];
}

export function calculateProfitSummaryMetrics(
  transactions: Transaction[],
  summaryRisks: SummaryRisk[]
): ProfitSummaryMetrics {
  const activeTransactions = transactions.filter((tx) => tx.status !== 'ปิดรับ');

  const totalGrossSales = activeTransactions.reduce(
    (s, tx) => s + (Number(tx.amount) || 0),
    0
  );
  const totalKeepHeld = activeTransactions.reduce(
    (s, tx) => s + (Number(tx.keepAmount) || 0),
    0
  );
  const totalSentOut = activeTransactions.reduce(
    (s, tx) => s + (Number(tx.sentAmount) || 0),
    0
  );

  // Best Case: If no number wins
  const bestCaseProfit = totalKeepHeld;

  // Worst Case: Find the single number that causes the biggest payout
  let worstCasePayout = 0;
  let worstCaseNumber = '-';
  let worstCaseType = '-';

  // Group by category for CategoryProfitBreakdown
  const catMap = new Map<string, CategoryProfitBreakdown>();

  let totalAllPayoutExposure = 0;
  let totalEstimatedPayoutExpected = 0;

  summaryRisks.forEach((r) => {
    // Skip purely closed items with 0 keepAmount so they do not distort active sales/sent metrics
    if (r.status === 'ปิดรับ' && r.keepAmount <= 0) {
      return;
    }

    totalAllPayoutExposure += r.potentialPayout;

    if (r.potentialPayout > worstCasePayout) {
      worstCasePayout = r.potentialPayout;
      worstCaseNumber = r.number;
      worstCaseType = r.type;
    }

    const totalCombinations = r.type.startsWith('3') ? 1000 : r.type.startsWith('2') ? 100 : 10;
    const probability = 1 / totalCombinations;
    totalEstimatedPayoutExpected += r.potentialPayout * probability;

    const existing = catMap.get(r.type) || {
      type: r.type,
      numbersCount: 0,
      totalAmount: 0,
      keepAmount: 0,
      sentAmount: 0,
      maxPayoutNumber: '-',
      maxPayoutRate: r.payoutRate,
      maxPayoutInCategory: 0,
      sumAllPayoutsInCategory: 0,
      estimatedProfitVsMaxPayout: 0,
      estimatedProfitVsSumAll: 0,
    };

    existing.numbersCount += 1;
    existing.totalAmount += r.totalAmount;
    existing.keepAmount += r.keepAmount;
    existing.sentAmount += r.sentAmount;
    existing.sumAllPayoutsInCategory += r.potentialPayout;

    if (r.potentialPayout > existing.maxPayoutInCategory) {
      existing.maxPayoutInCategory = r.potentialPayout;
      existing.maxPayoutNumber = r.number;
      existing.maxPayoutRate = r.payoutRate;
    }

    existing.estimatedProfitVsMaxPayout =
      existing.keepAmount - existing.maxPayoutInCategory;
    existing.estimatedProfitVsSumAll =
      existing.keepAmount - existing.sumAllPayoutsInCategory;

    catMap.set(r.type, existing);
  });

  const categoryBreakdowns = Array.from(catMap.values());
  const combinedMaxCategoryPayout = categoryBreakdowns.reduce(
    (s, c) => s + c.maxPayoutInCategory,
    0
  );

  const worstCaseNetProfit = totalKeepHeld - worstCasePayout;
  const estimatedProfitVsAllExposure = totalKeepHeld - totalAllPayoutExposure;
  const estimatedProfitVsCombinedMax = totalKeepHeld - combinedMaxCategoryPayout;
  const expectedProfitAverage = totalKeepHeld - totalEstimatedPayoutExpected;
  const expectedProfitRate =
    totalKeepHeld > 0 ? (expectedProfitAverage / totalKeepHeld) * 100 : 0;

  return {
    totalGrossSales,
    totalKeepHeld,
    totalSentOut,
    bestCaseProfit,
    worstCaseNetProfit,
    worstCaseNumber,
    worstCaseType,
    worstCasePayout,
    totalAllPayoutExposure,
    estimatedProfitVsAllExposure,
    combinedMaxCategoryPayout,
    estimatedProfitVsCombinedMax,
    totalEstimatedPayoutExpected,
    expectedProfitAverage,
    expectedProfitRate,
    categoryBreakdowns,
  };
}

/**
 * Unified Accounting Summary (Single Source of Truth across POS, Transactions, Settlement & Archive)
 */
export interface UnifiedAccountingSummary {
  totalGrossSales: number;
  totalDiscountGiven: number;
  totalNetSales: number;
  totalKeepAmount: number;
  totalSentAmount: number;
  activeTransactionsCount: number;
  totalTransactionsCount: number;
  billsCount: number;
}

export function calculateUnifiedAccountingSummary(
  transactions: Transaction[]
): UnifiedAccountingSummary {
  const billMap = new Map<string, { gross: number; discountPct: number }>();
  let totalGrossSales = 0;
  let totalKeepAmount = 0;
  let totalSentAmount = 0;
  let activeTransactionsCount = 0;

  transactions.forEach((tx) => {
    const isClosed = tx.status === 'ปิดรับ';
    const amt = isClosed ? 0 : Math.max(0, Number(tx.amount) || 0);
    const keep = isClosed ? 0 : Math.max(0, Number(tx.keepAmount) || 0);
    const sent = isClosed ? 0 : Math.max(0, Number(tx.sentAmount) || 0);

    if (!isClosed && amt > 0) {
      activeTransactionsCount += 1;
    }

    totalGrossSales += amt;
    totalKeepAmount += keep;
    totalSentAmount += sent;

    const existingBill = billMap.get(tx.billId) || {
      gross: 0,
      discountPct: Math.max(0, Math.min(50, Number(tx.discountPercent) || 0)),
    };
    existingBill.gross += amt;
    billMap.set(tx.billId, existingBill);
  });

  let totalDiscountGiven = 0;
  billMap.forEach((b) => {
    totalDiscountGiven += Math.round((b.gross * b.discountPct) / 100);
  });

  const totalNetSales = totalGrossSales - totalDiscountGiven;

  return {
    totalGrossSales,
    totalDiscountGiven,
    totalNetSales,
    totalKeepAmount,
    totalSentAmount,
    activeTransactionsCount,
    totalTransactionsCount: transactions.length,
    billsCount: billMap.size,
  };
}

/**
 * Parse Fast Bet Text (รองรับการวางโพยจาก LINE/SMS ทั้งแบบมาตรฐานและคำไทย เช่น บน, ล่าง, โต๊ด, กลับ)
 */
export interface ParsedFastBetLine {
  rawLine: string;
  type: string;
  number: string;
  amount: number;
  isValid: boolean;
  errorReason?: string;
}

export function parseFastBetText(rawText: string): ParsedFastBetLine[] {
  if (!rawText || !rawText.trim()) return [];
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const results: ParsedFastBetLine[] = [];

  lines.forEach((line) => {
    // Pattern 1: "538 = 100x50" or "38 = 100*100" or "05 100x50" (+ optional "กลับ")
    const isReverse = /กลับ|กล/i.test(line);
    const cleaned = line
      .replace(/^(?:\d+[.)]\s*)/, '')
      .replace(/บาท|บ\./gi, '')
      .trim();

    // Check explicit Thai type keywords: e.g. "45 บน 100", "45 ล่าง 100", "538 โต๊ด 100"
    const thaiTypeMatch = cleaned.match(
      /^(\d{1,3})\s*(3ตัวตรง|3ตัวโต๊ด|โต๊ด|เต็ง|บน|ล่าง|วิ่งบน|วิ่งล่าง)\s*(?:=|:|-|\s)?\s*(\d+)$/i
    );
    if (thaiTypeMatch) {
      const num = thaiTypeMatch[1];
      const keyword = thaiTypeMatch[2];
      const amt = Number(thaiTypeMatch[3]) || 0;

      if (amt <= 0) {
        results.push({
          rawLine: line,
          type: '-',
          number: num,
          amount: 0,
          isValid: false,
          errorReason: 'จำนวนเงินต้องมากกว่า 0',
        });
        return;
      }

      let targetType = '2ตัวบน';
      if (keyword === 'โต๊ด' || keyword === '3ตัวโต๊ด') targetType = '3ตัวโต๊ด';
      else if (keyword === 'เต็ง' || keyword === '3ตัวตรง') targetType = num.length === 3 ? '3ตัวตรง' : '2ตัวบน';
      else if (keyword === 'บน') targetType = num.length === 3 ? '3ตัวตรง' : num.length === 2 ? '2ตัวบน' : 'วิ่งบน';
      else if (keyword === 'ล่าง') targetType = num.length === 2 ? '2ตัวล่าง' : 'วิ่งล่าง';
      else if (keyword === 'วิ่งบน') targetType = 'วิ่งบน';
      else if (keyword === 'วิ่งล่าง') targetType = 'วิ่งล่าง';

      const nums = isReverse && (num.length === 2 || num.length === 3) ? reverseNumber(num) : [num];
      nums.forEach((n) => {
        results.push({
          rawLine: line,
          type: targetType,
          number: n,
          amount: amt,
          isValid: true,
        });
      });
      return;
    }

    // Pattern 2: "538 = 100x50" or "38 = 100" or "05 - 200x100 กลับ"
    const cleanNoRev = cleaned.replace(/กลับ|กล/gi, '').trim();
    const stdMatch = cleanNoRev.match(
      /^(\d{2,3})\s*(?:=|:|-|\s)\s*(\d+)(?:\s*[xX*×]\s*(\d+))?$/
    );

    if (stdMatch) {
      const num = stdMatch[1];
      const amt1 = Number(stdMatch[2]) || 0;
      const amt2 = stdMatch[3] !== undefined ? Number(stdMatch[3]) || 0 : 0;

      const nums = isReverse ? reverseNumber(num) : [num];

      if (num.length === 2) {
        nums.forEach((n) => {
          if (amt1 > 0) {
            results.push({
              rawLine: line,
              type: '2ตัวบน',
              number: n,
              amount: amt1,
              isValid: true,
            });
          }
          if (amt2 > 0) {
            results.push({
              rawLine: line,
              type: '2ตัวล่าง',
              number: n,
              amount: amt2,
              isValid: true,
            });
          }
        });
      } else if (num.length === 3) {
        nums.forEach((n) => {
          if (amt1 > 0) {
            results.push({
              rawLine: line,
              type: '3ตัวตรง',
              number: n,
              amount: amt1,
              isValid: true,
            });
          }
        });
        if (amt2 > 0) {
          results.push({
            rawLine: line,
            type: '3ตัวโต๊ด',
            number: num,
            amount: amt2,
            isValid: true,
          });
        }
      }
      return;
    }

    results.push({
      rawLine: line,
      type: '-',
      number: '-',
      amount: 0,
      isValid: false,
      errorReason: 'รูปแบบไม่ถูกต้อง (ตัวอย่าง: 38=100x100 หรือ 538=100x50)',
    });
  });

  return results;
}

/**
 * Format Thai date/time
 */
export function getCurrentThaiTimestamp(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const seconds = String(d.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * Generate next Bill ID e.g. B001, B002
 */
export function getNextBillId(transactions: Transaction[]): string {
  if (!transactions.length) return 'B001';
  let maxNum = 0;
  transactions.forEach((tx) => {
    if (tx.billId && tx.billId.startsWith('B')) {
      const num = parseInt(tx.billId.replace('B', ''), 10);
      if (!isNaN(num) && num > maxNum) maxNum = num;
    }
  });
  return `B${String(maxNum + 1).padStart(3, '0')}`;
}

export interface EditableBillItem {
  originalIndex: number; // Index inside the bill's items array
  type: string;
  number: string;
  amount: number;
  deleted?: boolean;
}

/**
 * Edit an existing bill's customerName, discountPercent, and item rows,
 * then automatically reconcile keepAmount and sentAmount chronologically across all bills.
 */
export function editBillTransactions(
  transactions: Transaction[],
  billId: string,
  updatedMeta: { customerName: string; discountPercent: number },
  updatedItems: EditableBillItem[],
  configSettings: ConfigRule[]
): { success: boolean; error?: string; transactions: Transaction[] } {
  const existingBillRows = transactions.filter((t) => t.billId === billId);
  if (!existingBillRows.length) {
    return { success: false, error: `ไม่พบบิล ${billId} ในระบบ`, transactions };
  }

  const activeEditedItems = updatedItems.filter((it) => !it.deleted && Number(it.amount) > 0);
  if (!activeEditedItems.length) {
    return {
      success: false,
      error: 'บิลต้องมีรายการอย่างน้อย 1 รายการที่มีจำนวนเงินมากกว่า 0 (หากต้องการลบทั้งบิลให้กดปุ่มยกเลิกบิล)',
      transactions,
    };
  }

  const nowStr = getCurrentThaiTimestamp();
  const cleanCustomer = updatedMeta.customerName.trim() || 'ลูกค้าทั่วไป';
  const cleanDiscount = Math.max(0, Math.min(50, Number(updatedMeta.discountPercent) || 0));

  const replacementBillRows: Transaction[] = [];

  for (let i = 0; i < activeEditedItems.length; i++) {
    const edited = activeEditedItems[i];
    const orig = existingBillRows[edited.originalIndex] || existingBillRows[0];
    const normalizedNum = normalizeLotteryNumber(edited.number, edited.type);

    if (!isValidLotteryNumber(normalizedNum, edited.type)) {
      return {
        success: false,
        error: `เลข "${edited.number}" ไม่ถูกต้องสำหรับประเภท ${edited.type}`,
        transactions,
      };
    }

    const amt = Math.max(0, Number(edited.amount) || 0);
    const isSameTypeAndNum = orig.type === edited.type && orig.number === normalizedNum;
    const rule = findConfigRule(edited.type, normalizedNum, configSettings);

    // If user changed to a number that is currently closed ('ปิดรับ'), reject the edit
    if (!isSameTypeAndNum && (rule.status === 'ปิดรับ' || rule.maxRisk <= 0)) {
      return {
        success: false,
        error: `ไม่สามารถเปลี่ยนเป็น ${edited.type} เลข [${normalizedNum}] ได้เนื่องจากอยู่ในสถานะปิดรับแทง`,
        transactions,
      };
    }

    const historicalRate = isSameTypeAndNum
      ? getTransactionPayoutRate(orig, configSettings)
      : rule.payoutRate;
    const nextStatus: RiskStatus = isSameTypeAndNum ? orig.status : rule.status;

    replacementBillRows.push({
      ...orig,
      id: orig.id || `TX_${billId}_${Date.now()}_${i + 1}`,
      updatedAt: nowStr,
      customerName: cleanCustomer,
      discountPercent: cleanDiscount,
      type: edited.type,
      number: normalizedNum,
      amount: amt,
      payoutRate: historicalRate,
      status: nextStatus,
    });
  }

  // Replace bill rows at the exact chronological position of the first row of billId
  const nextList: Transaction[] = [];
  let inserted = false;
  for (const tx of transactions) {
    if (tx.billId === billId) {
      if (!inserted) {
        nextList.push(...replacementBillRows);
        inserted = true;
      }
    } else {
      nextList.push(tx);
    }
  }

  const reconciled = reconcileTransactionsRisk(nextList, configSettings);
  return {
    success: true,
    transactions: reconciled,
  };
}

/**
 * Compute deterministic FNV-1a 32-bit hex checksum for Data Integrity & Backup verification
 */
export function computeDataChecksum(data: unknown): string {
  const json = JSON.stringify(data);
  let hash = 0x811c9dc5;
  for (let i = 0; i < json.length; i++) {
    hash ^= json.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return `CHK-${(hash >>> 0).toString(16).toUpperCase().padStart(8, '0')}`;
}

/**
 * Validate System Data Integrity across Configs, Transactions, Customers, and ArchivedDraws
 */
export function validateSystemDataIntegrity(payload: {
  configs: ConfigRule[];
  transactions: Transaction[];
  customers?: CustomerProfile[];
  archivedDraws?: ArchivedDraw[];
}): DataIntegrityReport {
  const issues: DataIntegrityIssue[] = [];
  const configs = Array.isArray(payload.configs) ? payload.configs : [];
  const transactions = Array.isArray(payload.transactions) ? payload.transactions : [];
  const customers = Array.isArray(payload.customers) ? payload.customers : [];
  const archivedDraws = Array.isArray(payload.archivedDraws) ? payload.archivedDraws : [];

  // 1. Check Config Rules
  const validTypes = new Set(['3ตัวตรง', '3ตัวโต๊ด', '2ตัวบน', '2ตัวล่าง', 'วิ่งบน', 'วิ่งล่าง']);
  configs.forEach((cfg, idx) => {
    if (!validTypes.has(cfg.type)) {
      issues.push({
        severity: 'error',
        code: 'INVALID_CONFIG_TYPE',
        message: `Config แถวที่ ${idx + 1} มีประเภทไม่ถูกต้อง (${cfg.type})`,
        entityId: `${cfg.type}:${cfg.number}`,
      });
    }
    if (cfg.number !== '*' && !isValidLotteryNumber(String(cfg.number), cfg.type)) {
      issues.push({
        severity: 'error',
        code: 'INVALID_CONFIG_NUMBER',
        message: `Config ${cfg.type} เลข "${cfg.number}" รูปแบบหลักไม่ถูกต้อง`,
        entityId: `${cfg.type}:${cfg.number}`,
      });
    }
    if (Number(cfg.payoutRate) < 0 || Number(cfg.maxRisk) < 0) {
      issues.push({
        severity: 'error',
        code: 'NEGATIVE_CONFIG_VALUE',
        message: `Config ${cfg.type} [${cfg.number}] มีอัตราจ่ายหรือเพดานติดลบ`,
        entityId: `${cfg.type}:${cfg.number}`,
      });
    }
  });

  // 2. Check Transactions
  transactions.forEach((tx, idx) => {
    const entityId = tx.id || `${tx.billId}#${idx + 1}`;
    if (!tx.billId) {
      issues.push({
        severity: 'error',
        code: 'MISSING_BILL_ID',
        message: `รายการที่ ${idx + 1} ไม่มีรหัสบิล (billId)`,
        entityId,
      });
    }
    if (!validTypes.has(tx.type)) {
      issues.push({
        severity: 'error',
        code: 'INVALID_TX_TYPE',
        message: `บิล ${tx.billId} มีประเภทหวยไม่ถูกต้อง (${tx.type})`,
        entityId,
      });
    }
    if (typeof tx.number !== 'string' || !isValidLotteryNumber(tx.number, tx.type)) {
      issues.push({
        severity: 'error',
        code: 'INVALID_TX_NUMBER',
        message: `บิล ${tx.billId} เลข "${tx.number}" (${tx.type}) ไม่เป็น String ที่ถูกต้องตามจำนวนหลัก`,
        entityId,
      });
    }
    if (tx.status !== 'ปิดรับ') {
      const amt = Number(tx.amount) || 0;
      const keep = Number(tx.keepAmount) || 0;
      const sent = Number(tx.sentAmount) || 0;
      if (amt <= 0) {
        issues.push({
          severity: 'error',
          code: 'NON_POSITIVE_AMOUNT',
          message: `บิล ${tx.billId} เลข ${tx.number} มียอดซื้อ <= 0`,
          entityId,
        });
      }
      if (Math.abs(keep + sent - amt) > 0.01) {
        issues.push({
          severity: 'error',
          code: 'RISK_SPLIT_MISMATCH',
          message: `บิล ${tx.billId} เลข ${tx.number} ยอดถือสู้ (${keep}) + ยอดตีออก (${sent}) ไม่เท่ากับยอดซื้อ (${amt})`,
          entityId,
        });
      }
    }
  });

  const checksum = computeDataChecksum({
    configsCount: configs.length,
    txCount: transactions.length,
    customersCount: customers.length,
    archivesCount: archivedDraws.length,
    transactions: transactions.map((t) => ({
      b: t.billId,
      tp: t.type,
      n: t.number,
      a: t.amount,
      k: t.keepAmount,
      s: t.sentAmount,
      r: t.payoutRate,
    })),
  });

  return {
    isValid: issues.filter((i) => i.severity === 'error').length === 0,
    checkedAt: getCurrentThaiTimestamp(),
    totalTransactions: transactions.length,
    totalConfigs: configs.length,
    totalCustomers: customers.length,
    totalArchivedDraws: archivedDraws.length,
    checksum,
    issues,
  };
}

/**
 * Create a complete, checksummed SystemBackupPayload for export
 */
export function createSystemBackupPayload(data: {
  configs: ConfigRule[];
  transactions: Transaction[];
  customers: CustomerProfile[];
  archivedDraws: ArchivedDraw[];
  paymentRecords: Record<string, BillPaymentRecord>;
  auditLogs: AuditLogEntry[];
}): SystemBackupPayload {
  const cleanData = {
    configs: data.configs || [],
    transactions: data.transactions || [],
    customers: data.customers || [],
    archivedDraws: data.archivedDraws || [],
    paymentRecords: data.paymentRecords || {},
    auditLogs: data.auditLogs || [],
  };
  const checksum = computeDataChecksum(cleanData);
  return {
    version: '4.0.0',
    exportedAt: getCurrentThaiTimestamp(),
    checksum,
    data: cleanData,
  };
}

/**
 * Verify a SystemBackupPayload before restoring
 */
export function verifySystemBackupPayload(payload: unknown): {
  isValid: boolean;
  error?: string;
  integrityReport?: DataIntegrityReport;
  parsed?: SystemBackupPayload;
} {
  if (!payload || typeof payload !== 'object') {
    return { isValid: false, error: 'ไฟล์สำรองข้อมูลไม่ใช่ JSON Object ที่ถูกต้อง' };
  }
  const candidate = payload as SystemBackupPayload;
  if (!candidate.data || !Array.isArray(candidate.data.configs) || !Array.isArray(candidate.data.transactions)) {
    return { isValid: false, error: 'โครงสร้างไฟล์สำรองข้อมูลไม่ครบถ้วน (ต้องมี data.configs และ data.transactions)' };
  }

  const expectedChecksum = computeDataChecksum({
    configs: candidate.data.configs || [],
    transactions: candidate.data.transactions || [],
    customers: candidate.data.customers || [],
    archivedDraws: candidate.data.archivedDraws || [],
    paymentRecords: candidate.data.paymentRecords || {},
    auditLogs: candidate.data.auditLogs || [],
  });

  if (candidate.checksum && candidate.checksum !== expectedChecksum) {
    return {
      isValid: false,
      error: `Checksum ของไฟล์สำรองไม่ตรงกัน (${candidate.checksum} !== ${expectedChecksum}) ข้อมูลอาจถูกแก้ไขหรือเสียหาย`,
    };
  }

  const integrityReport = validateSystemDataIntegrity({
    configs: candidate.data.configs,
    transactions: candidate.data.transactions,
    customers: candidate.data.customers,
    archivedDraws: candidate.data.archivedDraws,
  });

  if (!integrityReport.isValid) {
    return {
      isValid: false,
      error: `พบข้อผิดพลาดความสมบูรณ์ของข้อมูล (${integrityReport.issues[0]?.message || 'Data Integrity Error'})`,
      integrityReport,
    };
  }

  return {
    isValid: true,
    integrityReport,
    parsed: candidate,
  };
}


