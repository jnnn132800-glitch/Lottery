import { SoundSettings } from '../types/lottery';

export const DEFAULT_SOUND_SETTINGS: SoundSettings = {
  enabled: true,
  volume: 80,
  onBillSaved: true,
  onHalfPayAlert: true,
  onClosedAlert: true,
  onKeyPress: false,
};

let sharedAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioCtxClass =
    window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtxClass) return null;

  if (!sharedAudioCtx) {
    sharedAudioCtx = new AudioCtxClass();
  }
  if (sharedAudioCtx.state === 'suspended') {
    sharedAudioCtx.resume().catch(() => {
      // Ignore autoplay restrictions until user interaction
    });
  }
  return sharedAudioCtx;
}

/**
 * Helper to play a synthesized tone note with smooth envelope
 */
function playToneNote(
  ctx: AudioContext,
  freq: number,
  startTime: number,
  duration: number,
  maxGain: number,
  type: OscillatorType = 'sine'
) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, startTime);

  gain.gain.setValueAtTime(0.0001, startTime);
  gain.gain.linearRampToValueAtTime(Math.max(0.001, maxGain), startTime + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(startTime);
  osc.stop(startTime + duration + 0.02);
}

/**
 * 1. เสียงเตือนเมื่อบันทึกบิลสำเร็จ (POS Cash Register / Pleasant Ascending Chime)
 */
export function playBillSavedSound(settings: SoundSettings, forceTest = false): void {
  if (!forceTest && (!settings.enabled || !settings.onBillSaved)) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const vol = Math.max(0.05, Math.min(1, (settings.volume || 80) / 100)) * 0.35;
  const now = ctx.currentTime;

  // Ascending major triad chime: C5 -> E5 -> G5 -> C6
  playToneNote(ctx, 523.25, now, 0.11, vol, 'triangle');
  playToneNote(ctx, 659.25, now + 0.08, 0.11, vol, 'triangle');
  playToneNote(ctx, 783.99, now + 0.16, 0.13, vol, 'triangle');
  playToneNote(ctx, 1046.5, now + 0.25, 0.35, vol * 1.15, 'sine');
}

/**
 * 2. เสียงเตือนเมื่อคีย์เลขที่อยู่ในสถานะอั้นจ่าย (Dual Amber Warning Beep)
 */
export function playHalfPayWarningSound(settings: SoundSettings, forceTest = false): void {
  if (!forceTest && (!settings.enabled || !settings.onHalfPayAlert)) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const vol = Math.max(0.05, Math.min(1, (settings.volume || 80) / 100)) * 0.35;
  const now = ctx.currentTime;

  // Distinct two-tone attention alert: A5 -> F5 -> A5
  playToneNote(ctx, 880, now, 0.12, vol, 'triangle');
  playToneNote(ctx, 698.46, now + 0.14, 0.12, vol * 0.9, 'triangle');
  playToneNote(ctx, 880, now + 0.28, 0.22, vol * 1.1, 'triangle');
}

/**
 * 3. เสียงเตือนเมื่อคีย์เลขปิดรับ / เต็มเพดาน (Low Double Buzz Alert)
 */
export function playClosedErrorSound(settings: SoundSettings, forceTest = false): void {
  if (!forceTest && (!settings.enabled || !settings.onClosedAlert)) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const vol = Math.max(0.05, Math.min(1, (settings.volume || 80) / 100)) * 0.3;
  const now = ctx.currentTime;

  // Low error double buzz: Eb4 -> C4
  playToneNote(ctx, 311.13, now, 0.16, vol, 'sawtooth');
  playToneNote(ctx, 261.63, now + 0.18, 0.26, vol, 'sawtooth');
}

/**
 * 4. เสียงกดแป้นตัวเลข Numpad (Subtle Tactile Click)
 */
export function playKeyClickSound(settings: SoundSettings, forceTest = false): void {
  if (!forceTest && (!settings.enabled || !settings.onKeyPress)) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const vol = Math.max(0.03, Math.min(1, (settings.volume || 80) / 100)) * 0.15;
  const now = ctx.currentTime;

  playToneNote(ctx, 900, now, 0.03, vol, 'sine');
}
