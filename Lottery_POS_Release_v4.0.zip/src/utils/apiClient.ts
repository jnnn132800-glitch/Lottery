import {
  ConfigRule,
  Transaction,
  CustomerProfile,
  ArchivedDraw,
  BillPaymentRecord,
  AuditLogEntry,
  AuditActionType,
  OfflineQueueAction,
  DataIntegrityReport,
  SystemBackupPayload,
} from '../types/lottery';
import { EditableBillItem } from './lotteryLogic';

const OFFLINE_QUEUE_KEY = 'lottery_offline_queue';

export function getOfflineQueue(): OfflineQueueAction[] {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return [];
    const raw = window.localStorage.getItem(OFFLINE_QUEUE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveOfflineQueue(queue: OfflineQueueAction[]): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    window.localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
  } catch {
    // Ignore storage quota errors
  }
}

export function enqueueOfflineAction(action: Omit<OfflineQueueAction, 'id' | 'createdAt' | 'retryCount'>): OfflineQueueAction {
  const queue = getOfflineQueue();
  // Avoid duplicate idempotencyKey in queue
  const existing = queue.find((q) => q.idempotencyKey === action.idempotencyKey);
  if (existing) return existing;

  const entry: OfflineQueueAction = {
    ...action,
    id: `OQ_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    createdAt: new Date().toISOString(),
    retryCount: 0,
  };
  queue.push(entry);
  saveOfflineQueue(queue);
  return entry;
}

export interface ServerStateResponse {
  success: boolean;
  serverTime: string;
  gasConfigured: boolean;
  integrity: DataIntegrityReport;
  state: {
    configs: ConfigRule[];
    transactions: Transaction[];
    customers: CustomerProfile[];
    archivedDraws: ArchivedDraw[];
    paymentRecords: Record<string, BillPaymentRecord>;
    auditLogs: AuditLogEntry[];
    isMarketOpen: boolean;
    isPeriodLocked: boolean;
    currentDrawPeriod: string;
  };
}

export async function fetchServerState(): Promise<ServerStateResponse | null> {
  try {
    const res = await fetch('/api/state', {
      method: 'GET',
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) return null;
    const data = (await res.json()) as ServerStateResponse;
    return data.success ? data : null;
  } catch {
    return null;
  }
}

export async function flushOfflineQueue(): Promise<{
  flushedCount: number;
  remainingCount: number;
}> {
  const queue = getOfflineQueue();
  if (queue.length === 0) return { flushedCount: 0, remainingCount: 0 };

  const remaining: OfflineQueueAction[] = [];
  let flushedCount = 0;

  for (const item of queue) {
    try {
      const res = await fetch(item.endpoint, {
        method: item.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item.payload),
      });
      if (res.ok || res.status === 400) {
        // 200 OK or 400 validation error shouldn't block queue indefinitely
        flushedCount++;
      } else {
        remaining.push({ ...item, retryCount: item.retryCount + 1 });
      }
    } catch {
      remaining.push({ ...item, retryCount: item.retryCount + 1 });
    }
  }

  saveOfflineQueue(remaining);
  return { flushedCount, remainingCount: remaining.length };
}

export async function apiCreateBill(payload: {
  idempotencyKey: string;
  billId?: string;
  customerName: string;
  discountPercent?: number;
  drawPeriod?: string;
  items: Array<{ type: string; number: string; amount: number }>;
}): Promise<{
  confirmedByServer: boolean;
  queuedOffline: boolean;
  duplicate?: boolean;
  error?: string;
  billId?: string;
  createdTransactions?: Transaction[];
  transactions?: Transaction[];
  auditEntry?: AuditLogEntry;
}> {
  try {
    const res = await fetch('/api/bills', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return {
        confirmedByServer: false,
        queuedOffline: false,
        error: data.error || 'Server ปฏิเสธการบันทึกบิล',
      };
    }
    return {
      confirmedByServer: true,
      queuedOffline: false,
      duplicate: data.duplicate,
      billId: data.billId,
      createdTransactions: data.createdTransactions,
      transactions: data.transactions,
      auditEntry: data.auditEntry,
    };
  } catch {
    // Network unreachable -> enqueue into Offline Queue
    enqueueOfflineAction({
      idempotencyKey: payload.idempotencyKey,
      endpoint: '/api/bills',
      method: 'POST',
      payload,
    });
    return {
      confirmedByServer: false,
      queuedOffline: true,
    };
  }
}

export async function apiEditBill(payload: {
  billId: string;
  customerName: string;
  discountPercent: number;
  items: EditableBillItem[];
}): Promise<{
  confirmedByServer: boolean;
  error?: string;
  transactions?: Transaction[];
  auditEntry?: AuditLogEntry;
}> {
  try {
    const res = await fetch(`/api/bills/${encodeURIComponent(payload.billId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { confirmedByServer: false, error: data.error || 'ไม่สามารถแก้ไขบิลบน Server ได้' };
    }
    return {
      confirmedByServer: true,
      transactions: data.transactions,
      auditEntry: data.auditEntry,
    };
  } catch {
    return { confirmedByServer: false };
  }
}

export async function apiDeleteBill(billId: string): Promise<{
  confirmedByServer: boolean;
  error?: string;
  transactions?: Transaction[];
  auditEntry?: AuditLogEntry;
}> {
  try {
    const res = await fetch(`/api/bills/${encodeURIComponent(billId)}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { confirmedByServer: false, error: data.error || 'ไม่สามารถยกเลิกบิลบน Server ได้' };
    }
    return {
      confirmedByServer: true,
      transactions: data.transactions,
      auditEntry: data.auditEntry,
    };
  } catch {
    return { confirmedByServer: false };
  }
}

export async function apiUpdateConfigs(payload: {
  action: 'upsert' | 'delete' | 'reset';
  rule?: ConfigRule;
  type?: string;
  number?: string;
}): Promise<{
  confirmedByServer: boolean;
  error?: string;
  configs?: ConfigRule[];
  auditEntry?: AuditLogEntry;
}> {
  try {
    const res = await fetch('/api/configs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { confirmedByServer: false, error: data.error };
    }
    return {
      confirmedByServer: true,
      configs: data.configs,
      auditEntry: data.auditEntry,
    };
  } catch {
    return { confirmedByServer: false };
  }
}

export async function apiSyncMetadata(payload: {
  customers?: CustomerProfile[];
  archivedDraws?: ArchivedDraw[];
  paymentRecords?: Record<string, BillPaymentRecord>;
  transactions?: Transaction[];
  isMarketOpen?: boolean;
  isPeriodLocked?: boolean;
  currentDrawPeriod?: string;
  auditAction?: AuditActionType;
  auditSummary?: string;
  auditTargetId?: string;
}): Promise<boolean> {
  try {
    const res = await fetch('/api/sync-meta', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiExportBackup(): Promise<SystemBackupPayload | null> {
  try {
    const res = await fetch('/api/backup');
    if (!res.ok) return null;
    const data = await res.json();
    return data.backup || null;
  } catch {
    return null;
  }
}

export async function apiRestoreBackup(backup: SystemBackupPayload): Promise<{
  success: boolean;
  error?: string;
  preRestoreBackupFile?: string;
  integrityReport?: DataIntegrityReport;
  state?: ServerStateResponse['state'];
}> {
  try {
    const res = await fetch('/api/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ backup }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return {
        success: false,
        error: data.error || 'กู้คืนข้อมูลไม่สำเร็จ',
        integrityReport: data.integrityReport,
      };
    }
    return {
      success: true,
      preRestoreBackupFile: data.preRestoreBackupFile,
      integrityReport: data.integrityReport,
      state: data.state,
    };
  } catch {
    return {
      success: false,
      error: 'ไม่สามารถเชื่อมต่อ Server เพื่อกู้คืนข้อมูลได้',
    };
  }
}
