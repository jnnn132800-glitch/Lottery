import React, { useState, useRef } from 'react';
import {
  ConfigRule,
  RiskStatus,
  ArchivedDraw,
  SoundSettings,
  CustomerProfile,
  AuditLogEntry,
  DataIntegrityReport,
} from '../types/lottery';
import { normalizeLotteryNumber, isValidLotteryNumber, getCurrentThaiTimestamp } from '../utils/lotteryLogic';
import {
  playBillSavedSound,
  playHalfPayWarningSound,
  playClosedErrorSound,
  playKeyClickSound,
} from '../utils/soundEffects';
import {
  Settings,
  Plus,
  Trash2,
  Download,
  Upload,
  RotateCcw,
  AlertTriangle,
  ShieldCheck,
  Ban,
  Calendar,
  Archive,
  FolderClock,
  Check,
  Sparkles,
  History,
  FileSpreadsheet,
  Pencil,
  Volume2,
  VolumeX,
  BellRing,
  Play,
  Users,
  Lock,
  Database,
  FileCheck2,
  ScrollText,
} from 'lucide-react';

interface ConfigSettingsViewProps {
  configs: ConfigRule[];
  soundSettings: SoundSettings;
  onUpdateSoundSettings: (settings: SoundSettings) => void;
  currentDrawPeriod: string;
  onUpdateDrawPeriod: (period: string) => void;
  archivedDraws: ArchivedDraw[];
  currentTransactionsCount: number;
  onArchiveAndStartNewDraw: (nextDrawName: string) => void;
  onRestoreArchivedDraw: (archive: ArchivedDraw) => void;
  onDeleteArchivedDraw: (id: string) => void;
  onExportArchivedDrawCSV: (archive: ArchivedDraw) => void;
  onAddConfig: (rule: ConfigRule) => void;
  onDeleteConfig: (index: number) => void;
  onResetDefault: () => void;
  onExportCSV: () => void;
  customers?: CustomerProfile[];
  onSaveCustomer?: (customer: CustomerProfile) => void;
  onDeleteCustomer?: (id: string) => void;
  auditLogs?: AuditLogEntry[];
  integrityReport?: DataIntegrityReport;
  onExportFullBackup?: () => void;
  onRestoreFullBackup?: (rawJson: string) => void;
}

export const ConfigSettingsView: React.FC<ConfigSettingsViewProps> = ({
  configs,
  soundSettings,
  onUpdateSoundSettings,
  currentDrawPeriod,
  onUpdateDrawPeriod,
  archivedDraws,
  currentTransactionsCount,
  onArchiveAndStartNewDraw,
  onRestoreArchivedDraw,
  onDeleteArchivedDraw,
  onExportArchivedDrawCSV,
  onAddConfig,
  onDeleteConfig,
  onResetDefault,
  onExportCSV,
  customers = [],
  onSaveCustomer,
  onDeleteCustomer,
  auditLogs = [],
  integrityReport,
  onExportFullBackup,
  onRestoreFullBackup,
}) => {
  const backupFileInputRef = useRef<HTMLInputElement | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newType, setNewType] = useState('2ตัวบน');
  const [newNumber, setNewNumber] = useState('');
  const [newPayout, setNewPayout] = useState('45');
  const [newMaxRisk, setNewMaxRisk] = useState('2000');
  const [newStatus, setNewStatus] = useState<RiskStatus>('อั้นจ่าย');

  // Customer Management State
  const [showCustForm, setShowCustForm] = useState(false);
  const [custId, setCustId] = useState('');
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custDiscount, setCustDiscount] = useState('10');
  const [custCreditLimit, setCustCreditLimit] = useState('50000');
  const [custNote, setCustNote] = useState('');

  // Draw Period & Archive state
  const [drawInput, setDrawInput] = useState(currentDrawPeriod);
  const [nextDrawNameInput, setNextDrawNameInput] = useState('งวดวันที่ 1 ธ.ค. 2569');
  const [showArchiveConfirm, setShowArchiveConfirm] = useState(false);

  const handleSaveCustomerForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim() || !onSaveCustomer) return;
    onSaveCustomer({
      id: custId || `CUST_${Date.now()}`,
      name: custName.trim(),
      phone: custPhone.trim(),
      defaultDiscountPercent: Math.max(0, Math.min(50, Number(custDiscount) || 0)),
      creditLimit: Math.max(0, Number(custCreditLimit) || 0),
      note: custNote.trim(),
      createdAt: getCurrentThaiTimestamp(),
    });
    setCustId('');
    setCustName('');
    setCustPhone('');
    setCustDiscount('10');
    setCustCreditLimit('50000');
    setCustNote('');
    setShowCustForm(false);
  };

  const handleSaveDrawPeriod = (val?: string) => {
    const clean = (val ?? drawInput).trim();
    if (!clean) return;
    setDrawInput(clean);
    onUpdateDrawPeriod(clean);
  };

  const handleEditRule = (cfg: ConfigRule) => {
    setNewType(cfg.type);
    setNewNumber(cfg.number);
    setNewPayout(String(cfg.payoutRate));
    setNewMaxRisk(String(cfg.maxRisk));
    setNewStatus(cfg.status);
    setShowAddForm(true);
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const rawNum = newNumber.trim();
    if (!rawNum) {
      return;
    }

    const normalizedNum =
      rawNum === '*' ? '*' : normalizeLotteryNumber(rawNum, newType);
    if (normalizedNum !== '*' && !isValidLotteryNumber(normalizedNum, newType)) {
      return;
    }

    const effectivePayout =
      newStatus === 'ปิดรับ' ? 0 : Math.max(0, Number(newPayout) || 0);
    const effectiveMaxRisk =
      newStatus === 'ปิดรับ' ? 0 : Math.max(0, Number(newMaxRisk) || 0);

    onAddConfig({
      type: newType,
      number: normalizedNum,
      payoutRate: effectivePayout,
      maxRisk: effectiveMaxRisk,
      status: newStatus,
    });

    setNewNumber('');
    setShowAddForm(false);
  };

  const toggleSoundField = (field: keyof Omit<SoundSettings, 'volume'>) => {
    onUpdateSoundSettings({
      ...soundSettings,
      [field]: !soundSettings[field],
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* SECTION 0: NOTIFICATION SOUND SETTINGS */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950/25 to-slate-900 border border-indigo-500/35 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border ${
                soundSettings.enabled
                  ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-400'
                  : 'bg-slate-800 border-slate-700 text-slate-500'
              }`}
            >
              {soundSettings.enabled ? (
                <Volume2 className="w-5 h-5" />
              ) : (
                <VolumeX className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <span>การตั้งค่าเสียงแจ้งเตือน (Notification Sound)</span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                    soundSettings.enabled
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                  }`}
                >
                  {soundSettings.enabled ? 'เปิดเสียงอยู่' : 'ปิดเสียงทั้งหมด'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                ส่งเสียงแจ้งเตือนอัตโนมัติเมื่อบันทึกบิลสำเร็จ หรือเมื่อคีย์เลขที่อยู่ในสถานะอั้นจ่าย / ปิดรับ เพื่อป้องกันความผิดพลาดขณะคีย์โพยเร็วๆ
              </p>
            </div>
          </div>

          {/* Master Toggle Button */}
          <button
            type="button"
            onClick={() => toggleSoundField('enabled')}
            className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 cursor-pointer transition-all self-start sm:self-auto ${
              soundSettings.enabled
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
            }`}
          >
            {soundSettings.enabled ? (
              <>
                <Volume2 className="w-4 h-4" />
                <span>เปิดใช้งานเสียงแจ้งเตือน</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-rose-400" />
                <span>ปิดเสียงอยู่ (แตะเพื่อเปิด)</span>
              </>
            )}
          </button>
        </div>

        {/* Volume Slider */}
        <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <BellRing className="w-4 h-4 text-indigo-400 shrink-0" />
            <div>
              <span className="text-xs font-bold text-slate-200 block">
                ระดับความดังเสียงแจ้งเตือน (Master Volume)
              </span>
              <span className="text-[11px] text-slate-400">
                ปรับระดับความดังของเสียงเอฟเฟกต์ทั้งหมดในระบบ
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:w-72">
            <VolumeX className="w-4 h-4 text-slate-500 shrink-0" />
            <input
              type="range"
              min={10}
              max={100}
              step={5}
              disabled={!soundSettings.enabled}
              value={soundSettings.volume}
              onChange={(e) =>
                onUpdateSoundSettings({
                  ...soundSettings,
                  volume: Number(e.target.value),
                })
              }
              className="flex-1 accent-indigo-500 cursor-pointer disabled:opacity-40"
            />
            <span className="font-mono font-bold text-xs text-indigo-300 w-10 text-right">
              {soundSettings.volume}%
            </span>
          </div>
        </div>

        {/* Individual Sound Toggles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* 1. เสียงเมื่อบันทึกบิลสำเร็จ */}
          <div
            className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
              soundSettings.enabled && soundSettings.onBillSaved
                ? 'bg-slate-950/90 border-emerald-500/35'
                : 'bg-slate-950/40 border-slate-800/80 opacity-60'
            }`}
          >
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs sm:text-sm font-bold text-white">
                  เสียงเตือนเมื่อบันทึกบิลสำเร็จ
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                ส่งเสียงกระดิ่งแคชเชียร์ (Chime) ทันทีเมื่อกดยืนยันบันทึกบิลและออกใบเสร็จ
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => playBillSavedSound(soundSettings, true)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 text-[11px] font-semibold flex items-center gap-1 cursor-pointer active:scale-95"
                title="คลิกเพื่อฟังเสียงตัวอย่าง"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>ฟังเสียง</span>
              </button>

              <button
                type="button"
                disabled={!soundSettings.enabled}
                onClick={() => toggleSoundField('onBillSaved')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  soundSettings.onBillSaved
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {soundSettings.onBillSaved ? 'เปิด' : 'ปิด'}
              </button>
            </div>
          </div>

          {/* 2. เสียงเตือนเมื่อคีย์เลขอั้นจ่าย */}
          <div
            className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
              soundSettings.enabled && soundSettings.onHalfPayAlert
                ? 'bg-slate-950/90 border-amber-500/40'
                : 'bg-slate-950/40 border-slate-800/80 opacity-60'
            }`}
          >
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span className="text-xs sm:text-sm font-bold text-amber-300">
                  เสียงเตือนเมื่อคีย์เลขสถานะ "อั้นจ่าย"
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                ส่งเสียงสัญญาณเตือน 2 จังหวะทันทีที่คีย์เลขครบหลักแล้วพบว่าเป็นเลขอั้นจ่าย หรือเมื่อเลือกเลขอั้นลงตะกร้า
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => playHalfPayWarningSound(soundSettings, true)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-[11px] font-semibold flex items-center gap-1 cursor-pointer active:scale-95"
                title="คลิกเพื่อฟังเสียงตัวอย่าง"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>ฟังเสียง</span>
              </button>

              <button
                type="button"
                disabled={!soundSettings.enabled}
                onClick={() => toggleSoundField('onHalfPayAlert')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  soundSettings.onHalfPayAlert
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {soundSettings.onHalfPayAlert ? 'เปิด' : 'ปิด'}
              </button>
            </div>
          </div>

          {/* 3. เสียงเตือนเมื่อคีย์เลขปิดรับ / เต็มเพดาน */}
          <div
            className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
              soundSettings.enabled && soundSettings.onClosedAlert
                ? 'bg-slate-950/90 border-rose-500/35'
                : 'bg-slate-950/40 border-slate-800/80 opacity-60'
            }`}
          >
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <span className="text-xs sm:text-sm font-bold text-rose-300">
                  เสียงเตือนเมื่อคีย์เลขสถานะ "ปิดรับ / เต็มเพดาน"
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                ส่งเสียงทุ้มเตือน (Buzz) เมื่อคีย์เลขที่ปิดรับแทงหรือเต็มเพดานความเสี่ยงแล้ว
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => playClosedErrorSound(soundSettings, true)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 text-[11px] font-semibold flex items-center gap-1 cursor-pointer active:scale-95"
                title="คลิกเพื่อฟังเสียงตัวอย่าง"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>ฟังเสียง</span>
              </button>

              <button
                type="button"
                disabled={!soundSettings.enabled}
                onClick={() => toggleSoundField('onClosedAlert')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  soundSettings.onClosedAlert
                    ? 'bg-rose-500 text-white'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {soundSettings.onClosedAlert ? 'เปิด' : 'ปิด'}
              </button>
            </div>
          </div>

          {/* 4. เสียงกดแป้นตัวเลข Numpad */}
          <div
            className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
              soundSettings.enabled && soundSettings.onKeyPress
                ? 'bg-slate-950/90 border-sky-500/35'
                : 'bg-slate-950/40 border-slate-800/80 opacity-60'
            }`}
          >
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-sky-400" />
                <span className="text-xs sm:text-sm font-bold text-slate-200">
                  เสียงคลิกเมื่อกดแป้นตัวเลข (Numpad Click)
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                ส่งเสียงคลิกเบาๆ ทุกครั้งที่แตะปุ่มตัวเลข 0-9 บนหน้าเครื่องรับแทง
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => playKeyClickSound(soundSettings, true)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 text-[11px] font-semibold flex items-center gap-1 cursor-pointer active:scale-95"
                title="คลิกเพื่อฟังเสียงตัวอย่าง"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>ฟังเสียง</span>
              </button>

              <button
                type="button"
                disabled={!soundSettings.enabled}
                onClick={() => toggleSoundField('onKeyPress')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  soundSettings.onKeyPress
                    ? 'bg-sky-500 text-slate-950'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {soundSettings.onKeyPress ? 'เปิด' : 'ปิด'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 1: DRAW PERIOD MANAGEMENT & ARCHIVING */}
      <div className="bg-gradient-to-br from-slate-900 via-emerald-950/20 to-slate-900 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <span>ระบบจัดการงวดหวย & ปิดงวดเริ่มงวดใหม่ (Draw Management)</span>
              </h3>
              <p className="text-xs text-slate-400">
                ตั้งชื่องวดปัจจุบัน หรือกดปิดงวดเพื่อเก็บโพยทั้งหมดเข้าคลังประวัติและเริ่มรับโพยงวดใหม่ (B001) โดยไม่ต้องลบเรทจ่าย
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowArchiveConfirm(!showArchiveConfirm)}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer self-start sm:self-auto"
          >
            <Archive className="w-4 h-4" />
            <span>ปิดงวดปัจจุบัน & เริ่มงวดใหม่</span>
          </button>
        </div>

        {/* Active Draw Period Selector */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-6">
            <label className="text-xs text-slate-300 font-semibold block mb-1.5">
              งวดหวยที่กำลังเปิดรับโพยปัจจุบัน:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={drawInput}
                onChange={(e) => setDrawInput(e.target.value)}
                placeholder="เช่น งวดวันที่ 16 พ.ย. 2569"
                className="flex-1 bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs sm:text-sm text-emerald-300 font-semibold focus:outline-none"
              />
              <button
                type="button"
                onClick={() => handleSaveDrawPeriod()}
                className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1 cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" />
                <span>อัปเดตชื่องวด</span>
              </button>
            </div>
          </div>

          <div className="md:col-span-6">
            <span className="text-[11px] text-slate-400 block mb-1.5">
              ทางลัดเลือกชื่องวดด่วน:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                'งวดวันที่ 16 พ.ย. 2569',
                'งวดวันที่ 1 ธ.ค. 2569',
                'งวดวันที่ 16 ธ.ค. 2569',
                'หวยฮานอย วันนี้',
                'หวยลาวพัฒนา วันนี้',
              ].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleSaveDrawPeriod(preset)}
                  className={`px-2.5 py-1.5 rounded-lg border text-[11px] cursor-pointer transition-all ${
                    currentDrawPeriod === preset
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-bold'
                      : 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-slate-300'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Archive & Start New Draw Confirmation Panel */}
        {showArchiveConfirm && (
          <div className="p-4 rounded-2xl bg-slate-950/90 border border-amber-500/50 space-y-3 animate-in fade-in">
            <div className="flex items-start gap-2.5">
              <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <h4 className="font-bold text-amber-300 text-sm">
                  ยืนยันปิดงวด "{currentDrawPeriod}" และเริ่มงวดใหม่
                </h4>
                <p className="text-slate-300">
                  ระบบจะเก็บโพยปัจจุบันทั้งหมด (<strong>{currentTransactionsCount} รายการ</strong>) เข้าสู่คลังประวัติงวดย้อนหลัง แล้วล้างกระดานรับโพยให้เป็น 0 เพื่อเริ่มบิล <strong className="text-sky-400 font-mono">B001</strong> ในงวดใหม่ทันที (โดยไม่ลบการตั้งค่าเรทจ่าย)
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-2 pt-1">
              <div className="flex-1">
                <label className="text-[11px] text-slate-400 block mb-1">
                  ระบุชื่องวดใหม่ที่จะเริ่มรับโพยต่อทันที:
                </label>
                <input
                  type="text"
                  value={nextDrawNameInput}
                  onChange={(e) => setNextDrawNameInput(e.target.value)}
                  placeholder="เช่น งวดวันที่ 1 ธ.ค. 2569"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-semibold focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowArchiveConfirm(false)}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                >
                  ยกเลิก
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const nextName = nextDrawNameInput.trim() || 'งวดใหม่';
                    onArchiveAndStartNewDraw(nextName);
                    setDrawInput(nextName);
                    setShowArchiveConfirm(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
                >
                  <Archive className="w-4 h-4" />
                  <span>ยืนยันปิดงวด & เริ่มงวดใหม่ทันที</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Archived Draws History List */}
        {archivedDraws.length > 0 && (
          <div className="pt-3 border-t border-slate-800/80 space-y-2.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <History className="w-4 h-4 text-sky-400" />
                <span>คลังประวัติงวดหวยที่ปิดแล้ว ({archivedDraws.length} งวด)</span>
              </h4>
              <span className="text-[11px] text-slate-400">
                สามารถกดสลับดูข้อมูลย้อนหลัง หรือส่งออก CSV รายงวดได้ตลอดเวลา
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {archivedDraws.map((arch) => (
                <div
                  key={arch.id}
                  className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 flex flex-col justify-between gap-2.5 text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-emerald-400 text-sm">
                          {arch.drawPeriod}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-mono">
                          {arch.billsCount} บิล ({arch.transactionsCount} รายการ)
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[10px] font-bold flex items-center gap-1">
                          <Lock className="w-2.5 h-2.5" />
                          <span>ล็อกงวดแล้ว</span>
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 font-mono">
                        ปิดงวดเมื่อ: {arch.archivedAt} | สุทธิ: ฿{arch.totalNetSales.toLocaleString()}
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">ผลรางวัลที่บันทึก</span>
                      <span className="font-mono font-bold text-amber-400">
                        บน {arch.winningTop3 || '-'} | ล่าง {arch.winningBottom2 || '-'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5 p-2 rounded-lg bg-slate-900/90 border border-slate-800/80 text-center">
                    <div>
                      <span className="text-[10px] text-slate-400 block">ยอดหน้าโพย</span>
                      <span className="font-mono font-bold text-slate-200">
                        ฿{arch.totalGrossSales.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-emerald-400 block">ยอดถือเอง</span>
                      <span className="font-mono font-bold text-emerald-400">
                        ฿{arch.totalKeepAmount.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-rose-400 block">ยอดตีเกิน</span>
                      <span className="font-mono font-bold text-rose-400">
                        ฿{arch.totalSentAmount.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => onExportArchivedDrawCSV(arch)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[11px] flex items-center gap-1 cursor-pointer"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                      <span>ส่งออก CSV</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onRestoreArchivedDraw(arch)}
                      className="px-2.5 py-1.5 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 font-semibold text-[11px] flex items-center gap-1 cursor-pointer"
                    >
                      <FolderClock className="w-3.5 h-3.5" />
                      <span>เปิดดูงวดนี้ (โหมดล็อก)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onDeleteArchivedDraw(arch.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 cursor-pointer"
                      title="ลบประวัติงวดนี้"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* SECTION 1.5: CUSTOMER DIRECTORY & DEFAULT DISCOUNT (หมวด 5: Customer Management) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                ทะเบียนลูกค้า & ส่วนลดเริ่มต้น (Customer Management)
              </h3>
              <p className="text-[11px] text-slate-400">
                ตั้งค่าส่วนลดค่าโพย (%) และวงเงินเครดิตรายบุคคล เพื่อเลือกด่วนในหน้ารับโพย
              </p>
            </div>
          </div>

          {onSaveCustomer && (
            <button
              type="button"
              onClick={() => {
                setCustId('');
                setCustName('');
                setCustPhone('');
                setCustDiscount('10');
                setCustCreditLimit('50000');
                setCustNote('');
                setShowCustForm(!showCustForm);
              }}
              className="px-3 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>เพิ่มลูกค้า</span>
            </button>
          )}
        </div>

        {showCustForm && onSaveCustomer && (
          <form
            onSubmit={handleSaveCustomerForm}
            className="p-3.5 rounded-xl bg-slate-950 border border-sky-500/40 space-y-3 animate-in fade-in text-xs"
          >
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
              <div>
                <label className="text-slate-400 block mb-1">ชื่อลูกค้า / สายโพย *</label>
                <input
                  type="text"
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                  placeholder="เช่น นาย ก"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">เบอร์ติดต่อ</label>
                <input
                  type="text"
                  value={custPhone}
                  onChange={(e) => setCustPhone(e.target.value)}
                  placeholder="08x-xxx-xxxx"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono focus:outline-none"
                />
              </div>
              <div>
                <label className="text-indigo-300 font-semibold block mb-1">ส่วนลดเริ่มต้น (%)</label>
                <input
                  type="number"
                  min={0}
                  max={50}
                  value={custDiscount}
                  onChange={(e) => setCustDiscount(e.target.value)}
                  className="w-full bg-slate-900 border border-indigo-500/40 rounded-lg px-2.5 py-1.5 text-indigo-300 font-mono font-bold focus:outline-none"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">วงเงินเครดิต (บาท)</label>
                <input
                  type="number"
                  min={0}
                  value={custCreditLimit}
                  onChange={(e) => setCustCreditLimit(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-emerald-400 font-mono focus:outline-none"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowCustForm(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-sky-500 text-slate-950 font-bold cursor-pointer"
              >
                บันทึกลูกค้า
              </button>
            </div>
          </form>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {customers.map((c) => (
            <div
              key={c.id}
              className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div>
                <div className="font-bold text-slate-100 flex items-center gap-1.5">
                  <span>{c.name}</span>
                  <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono text-[10px]">
                    ลด {c.defaultDiscountPercent}%
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {c.phone || 'ไม่ระบุเบอร์'} • เครดิต ฿{(c.creditLimit || 0).toLocaleString()}
                </div>
              </div>
              <div className="flex items-center gap-1">
                {onSaveCustomer && (
                  <button
                    type="button"
                    onClick={() => {
                      setCustId(c.id);
                      setCustName(c.name);
                      setCustPhone(c.phone || '');
                      setCustDiscount(String(c.defaultDiscountPercent));
                      setCustCreditLimit(String(c.creditLimit || 0));
                      setCustNote(c.note || '');
                      setShowCustForm(true);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-slate-800 cursor-pointer"
                    title="แก้ไขข้อมูลลูกค้า"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                )}
                {onDeleteCustomer && (
                  <button
                    type="button"
                    onClick={() => onDeleteCustomer(c.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 cursor-pointer"
                    title="ลบรายชื่อลูกค้า"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 2: CONFIG_SETTINGS TABLE */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-base text-slate-100">
              ตั้งค่า Config_Settings (อัตราจ่าย / เพดานความเสี่ยง)
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onResetDefault}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer"
              title="รีเซ็ตเป็นค่าเริ่มต้นจากไฟล์ CSV"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>คืนค่าเดิม</span>
            </button>

            <button
              type="button"
              onClick={onExportCSV}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>ส่งออก CSV</span>
            </button>

            <button
              type="button"
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>เพิ่ม/แก้ไขกฎเลขอั้น</span>
            </button>
          </div>
        </div>

        {/* Add/Update Form Accordion */}
        {showAddForm && (
          <form
            onSubmit={handleAdd}
            className="bg-slate-800/90 border border-slate-700 rounded-2xl p-4 space-y-3 animate-in fade-in"
          >
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-emerald-400">
                เพิ่มหรืออัปเดตกฎอัตราจ่าย / เพดานความเสี่ยง (หากเลขซ้ำจะอัปเดตทับอัตโนมัติ)
              </h4>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">ประเภท</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 focus:outline-none"
                >
                  <option value="2ตัวบน">2ตัวบน</option>
                  <option value="2ตัวล่าง">2ตัวล่าง</option>
                  <option value="3ตัวตรง">3ตัวตรง</option>
                  <option value="3ตัวโต๊ด">3ตัวโต๊ด</option>
                  <option value="วิ่งบน">วิ่งบน</option>
                  <option value="วิ่งล่าง">วิ่งล่าง</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">เลข (* หรือระบุเลข)</label>
                <input
                  type="text"
                  value={newNumber}
                  onChange={(e) => setNewNumber(e.target.value)}
                  placeholder="เช่น 83, 999, *"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">อัตราจ่าย (บาท)</label>
                <input
                  type="number"
                  step="any"
                  value={newPayout}
                  onChange={(e) => setNewPayout(e.target.value)}
                  placeholder="เช่น 45, 90"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">เพดานรับ (MaxRisk)</label>
                <input
                  type="number"
                  value={newMaxRisk}
                  onChange={(e) => setNewMaxRisk(e.target.value)}
                  placeholder="เช่น 2000, 0"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">สถานะ</label>
                <select
                  value={newStatus}
                  onChange={(e) => {
                    const val = e.target.value as RiskStatus;
                    setNewStatus(val);
                    if (val === 'ปิดรับ') {
                      setNewMaxRisk('0');
                      setNewPayout('0');
                    }
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 focus:outline-none"
                >
                  <option value="อั้นจ่าย">อั้นจ่าย</option>
                  <option value="ปิดรับ">ปิดรับ</option>
                  <option value="ปกติ">ปกติ</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded-lg text-xs text-slate-300 cursor-pointer"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs cursor-pointer"
              >
                บันทึกกฎ
              </button>
            </div>
          </form>
        )}

        {/* Table */}
        <div className="bg-slate-800/80 rounded-2xl border border-slate-700/60 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-900/80 text-slate-400 font-semibold border-b border-slate-700/80 uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4 text-center">Number</th>
                  <th className="py-3 px-4 text-right">PayoutRate</th>
                  <th className="py-3 px-4 text-right">MaxRisk</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">จัดการ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40">
                {configs.map((cfg, idx) => {
                  const isWildcard = cfg.number === '*';
                  return (
                    <tr key={idx} className="hover:bg-slate-750/50 transition-colors">
                      <td className="py-3 px-4 text-slate-200 font-medium">{cfg.type}</td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-amber-400 text-sm">
                        {isWildcard ? (
                          <span className="text-slate-300 bg-slate-700/60 px-2 py-0.5 rounded text-xs">
                            * (ค่าเริ่มต้นหมวดนี้)
                          </span>
                        ) : (
                          cfg.number
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-200">
                        {cfg.payoutRate} บ.
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-300">
                        ฿{cfg.maxRisk.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            cfg.status === 'ปกติ'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : cfg.status === 'อั้นจ่าย'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {cfg.status === 'ปกติ' && <ShieldCheck className="w-3 h-3" />}
                          {cfg.status === 'อั้นจ่าย' && <AlertTriangle className="w-3 h-3" />}
                          {cfg.status === 'ปิดรับ' && <Ban className="w-3 h-3" />}
                          <span>{cfg.status}</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleEditRule(cfg)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-slate-700/50 cursor-pointer"
                            title="แก้ไขเรทจ่าย/เพดานของรายการนี้"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          {!isWildcard && (
                            <button
                              type="button"
                              onClick={() => onDeleteConfig(idx)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-700/50 cursor-pointer"
                              title="ลบกฎข้อนี้"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* SECTION 3: DATABASE BACKUP, RESTORE & DATA INTEGRITY (หมวด 9 & 10: Database, Security & Data Integrity) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                สำรองและกู้คืนฐานข้อมูล & ตรวจสอบความสมบูรณ์ (Backup, Restore & Integrity)
              </h3>
              <p className="text-[11px] text-slate-400">
                สำรองข้อมูลทั้งระบบเป็นไฟล์ JSON พร้อมรหัส Checksum ป้องกันข้อมูลสูญหายหรือถูกแก้ไข
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onExportFullBackup && (
              <button
                type="button"
                onClick={onExportFullBackup}
                className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>สำรองฐานข้อมูล (Backup JSON)</span>
              </button>
            )}

            {onRestoreFullBackup && (
              <>
                <input
                  ref={backupFileInputRef}
                  type="file"
                  accept=".json,application/json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = () => {
                      if (typeof reader.result === 'string') {
                        onRestoreFullBackup(reader.result);
                      }
                      if (backupFileInputRef.current) {
                        backupFileInputRef.current.value = '';
                      }
                    };
                    reader.readAsText(file);
                  }}
                />
                <button
                  type="button"
                  onClick={() => backupFileInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 font-semibold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>กู้คืนจากไฟล์สำรอง (Restore JSON)</span>
                </button>
              </>
            )}

            <a
              href="/Lottery_POS_Release_v4.0.zip"
              download="Lottery_POS_Release_v4.0.zip"
              className="px-3.5 py-2 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              title="ดาวน์โหลด Source Code + คู่มือติดตั้ง + คู่มือสำรองข้อมูล ฉบับสมบูรณ์ (ZIP)"
            >
              <Archive className="w-3.5 h-3.5 text-sky-400" />
              <span>ดาวน์โหลด Source Code (ZIP v4.0)</span>
            </a>
          </div>
        </div>

        {integrityReport && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
            <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 block">สถานะความสมบูรณ์ข้อมูล</span>
                <span
                  className={`font-bold flex items-center gap-1 mt-0.5 ${
                    integrityReport.isValid ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  <FileCheck2 className="w-3.5 h-3.5" />
                  <span>{integrityReport.isValid ? 'สมบูรณ์ 100% (Valid)' : 'พบจุดผิดปกติ'}</span>
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">รหัสตรวจสอบ (Checksum)</span>
              <span className="font-mono font-bold text-sky-400 mt-0.5 block">
                {integrityReport.checksum}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">รายการเดิมพัน / กฎความเสี่ยง</span>
              <span className="font-mono font-bold text-slate-200 mt-0.5 block">
                {integrityReport.totalTransactions} รายการ / {integrityReport.totalConfigs} กฎ
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">ทะเบียนลูกค้า / งวดที่ปิดแล้ว</span>
              <span className="font-mono font-bold text-slate-200 mt-0.5 block">
                {integrityReport.totalCustomers} ราย / {integrityReport.totalArchivedDraws} งวด
              </span>
            </div>
          </div>
        )}
      </div>

      {/* SECTION 4: SYSTEM AUDIT LOG (หมวด 10: Security & Audit Trail) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <ScrollText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                ประวัติการทำรายการและตรวจสอบระบบ (System Audit Log)
              </h3>
              <p className="text-[11px] text-slate-400">
                บันทึกทุกการสร้างบิล แก้ไขบิล ยกเลิกบิล ตั้งค่าเรทจ่าย ปิดงวด และกู้คืนข้อมูล พร้อม Idempotency Key
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-mono text-xs">
            {auditLogs.length} รายการล่าสุด
          </span>
        </div>

        <div className="max-h-64 overflow-y-auto divide-y divide-slate-800/80 rounded-xl border border-slate-800 bg-slate-950/70">
          {auditLogs.length === 0 ? (
            <div className="p-4 text-center text-xs text-slate-500">
              ยังไม่มีประวัติการทำรายการในระบบ
            </div>
          ) : (
            auditLogs.slice(0, 50).map((log) => (
              <div
                key={log.id}
                className="p-2.5 sm:px-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs hover:bg-slate-900/60"
              >
                <div className="flex items-start sm:items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 font-mono text-[10px] font-bold shrink-0">
                    {log.action}
                  </span>
                  <span className="text-slate-200">{log.summary}</span>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono shrink-0">
                  {log.idempotencyKey && (
                    <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                      {log.idempotencyKey}
                    </span>
                  )}
                  <span>{log.timestamp}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
