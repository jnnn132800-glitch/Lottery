import React from 'react';
import { AlertTriangle, Check, X } from 'lucide-react';
import { RiskEvaluationResult } from '../utils/lotteryLogic';

interface HalfPayConfirmModalProps {
  isOpen: boolean;
  evaluation: RiskEvaluationResult | null;
  type: string;
  number: string;
  amount: number;
  onConfirm: () => void;
  onCancel: () => void;
}

export const HalfPayConfirmModal: React.FC<HalfPayConfirmModalProps> = ({
  isOpen,
  evaluation,
  type,
  number,
  amount,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen || !evaluation) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div className="bg-slate-900 border-2 border-amber-500/80 rounded-2xl max-w-sm w-full p-5 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center gap-3 text-amber-400 mb-3">
          <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40">
            <AlertTriangle className="w-7 h-7 text-amber-400" />
          </div>
          <div>
            <h3 className="font-bold text-lg leading-tight">แจ้งเตือน: เลขอั้นจ่าย</h3>
            <span className="text-xs text-amber-300/80">ต้องยืนยันอัตราจ่ายก่อนรับเดิมพัน</span>
          </div>
        </div>

        <div className="bg-slate-800/80 rounded-xl p-3 border border-slate-700/60 space-y-2 mb-4 text-sm">
          <div className="flex justify-between items-center pb-2 border-b border-slate-700/50">
            <span className="text-slate-400">ประเภท / เลข:</span>
            <span className="font-bold text-base text-amber-400 font-mono">
              {type} : {number}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-400">ยอดแทง:</span>
            <span className="font-bold font-mono text-slate-200">฿{amount.toLocaleString()}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-400">อัตราจ่ายพิเศษที่รับ:</span>
            <span className="font-bold font-mono text-emerald-400 text-base">
              {evaluation.payoutRate} บาท
            </span>
          </div>

          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400">ถือเอง (Keep):</span>
            <span className="font-mono text-emerald-400">฿{evaluation.keepAmount.toLocaleString()}</span>
          </div>

          {evaluation.sentAmount > 0 && (
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">ตีเกินส่งต่อ (Sent):</span>
              <span className="font-mono text-rose-400 font-semibold">฿{evaluation.sentAmount.toLocaleString()}</span>
            </div>
          )}

          <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-700/40">
            <span className="text-slate-400">เพดานความเสี่ยง (MaxRisk):</span>
            <span className="font-mono text-slate-300">฿{evaluation.maxRiskLimit.toLocaleString()}</span>
          </div>
        </div>

        <p className="text-xs text-slate-300 mb-5 leading-relaxed bg-amber-950/30 p-2.5 rounded-lg border border-amber-800/40">
          ⚠️ หมายเหตุ: เลขนี้จ่ายตามอัตราพิเศษ <strong className="text-amber-300">{evaluation.payoutRate} บาท</strong> (แทนอัตราปกติ) ลูกค้ารับทราบเงื่อนไขนี้แล้วใช่หรือไม่?
        </p>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="py-2.5 px-3 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span>ยกเลิก</span>
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-sm flex items-center justify-center gap-1.5 transition-all shadow-md shadow-amber-500/20 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>ยืนยันรับตามเรท</span>
          </button>
        </div>
      </div>
    </div>
  );
};
