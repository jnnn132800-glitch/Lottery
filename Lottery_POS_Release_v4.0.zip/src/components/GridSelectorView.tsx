import React, { useState, useMemo } from 'react';
import {
  ConfigRule,
  Transaction,
  BasketItem,
} from '../types/lottery';
import { evaluateNumberRisk } from '../utils/lotteryLogic';
import {
  Grid3X3,
  Check,
  RotateCcw,
  Sparkles,
  Layers,
  Coins,
  Ban,
  CheckCheck,
  Trash2,
  AlertTriangle,
  ArrowUpCircle,
  ArrowDownCircle,
  Info,
} from 'lucide-react';

export type GridBetType = '2ตัวบน' | '2ตัวล่าง' | '2ตัวบน+ล่าง';

export type CellAlertLevel = 'normal' | 'nearFull' | 'halfPay' | 'full' | 'closed';

export interface ChannelRiskDetail {
  type: '2ตัวบน' | '2ตัวล่าง';
  shortType: 'บน' | 'ล่าง';
  level: CellAlertLevel;
  statusText: string;
  shortBadge: string; // เช่น 'บน:อั้น', 'บน:เต็ม', 'บน:ปิด', 'บน:ใกล้'
  payoutRate: number;
  currentUsed: number;
  maxLimit: number;
  usagePercent: number;
  canAccept: boolean;
}

export interface NumberDualRisk {
  number: string;
  top: ChannelRiskDetail;
  bottom: ChannelRiskDetail;
}

interface GridSelectorViewProps {
  configs: ConfigRule[];
  transactions: Transaction[];
  basket: BasketItem[];
  onAddBatchToBasket: (
    items: BasketItem[],
    summary: {
      selectedCount: number;
      halfPayCount: number;
      closedCount: number;
      betType: GridBetType;
      totalAmount: number;
    }
  ) => void;
  onOpenBasket: () => void;
  onNumberRiskSound?: (alertType: 'halfPay' | 'closed') => void;
}

// Generate 00 to 99 in 10x10 order
const ALL_100_NUMBERS: string[] = Array.from({ length: 100 }, (_, i) =>
  i.toString().padStart(2, '0')
);

// Preset amounts
const PRESET_AMOUNTS = [10, 20, 50, 100, 200, 500, 1000];

function analyzeChannelRisk(
  type: '2ตัวบน' | '2ตัวล่าง',
  num: string,
  amount: number,
  configs: ConfigRule[],
  transactions: Transaction[],
  basket: BasketItem[]
): ChannelRiskDetail {
  const shortType = type === '2ตัวบน' ? 'บน' : 'ล่าง';
  const ev = evaluateNumberRisk(type, num, amount || 1, configs, transactions, basket);
  const used = ev.currentAccumulated;
  const max = ev.maxRiskLimit;
  const usagePct = max > 0 ? Math.min(100, Math.round((used / max) * 100)) : 100;

  if (ev.status === 'ปิดรับ' || !ev.canAccept || max <= 0) {
    return {
      type,
      shortType,
      level: 'closed',
      statusText: 'ปิดรับแทง',
      shortBadge: `${shortType}:ปิด`,
      payoutRate: 0,
      currentUsed: used,
      maxLimit: max,
      usagePercent: 100,
      canAccept: false,
    };
  }

  // Check if already at or over max risk limit (เต็มเพดาน / ตีเกิน)
  const isAtOrOverLimit = used >= max;
  const isNearLimit = !isAtOrOverLimit && max > 0 && used / max >= 0.75;

  if (ev.status === 'อั้นจ่าย') {
    return {
      type,
      shortType,
      level: isAtOrOverLimit ? 'full' : 'halfPay',
      statusText: isAtOrOverLimit
        ? `อั้นจ่าย (${ev.payoutRate}บ.) + เต็มเพดาน (ตีเกิน)`
        : `อั้นจ่าย (จ่าย ${ev.payoutRate}บ.)`,
      shortBadge: isAtOrOverLimit ? `${shortType}:อั้น/เต็ม` : `${shortType}:อั้น`,
      payoutRate: ev.payoutRate,
      currentUsed: used,
      maxLimit: max,
      usagePercent: usagePct,
      canAccept: true,
    };
  }

  if (isAtOrOverLimit) {
    return {
      type,
      shortType,
      level: 'full',
      statusText: `เต็มเพดานถือสู้ (${used.toLocaleString()}/${max.toLocaleString()}บ. • ตีเกินส่งต่อ)`,
      shortBadge: `${shortType}:เต็ม`,
      payoutRate: ev.payoutRate,
      currentUsed: used,
      maxLimit: max,
      usagePercent: 100,
      canAccept: true,
    };
  }

  if (isNearLimit) {
    return {
      type,
      shortType,
      level: 'nearFull',
      statusText: `ใกล้เต็มเพดาน (${used.toLocaleString()}/${max.toLocaleString()}บ. • ${usagePct}%)`,
      shortBadge: `${shortType}:ใกล้เต็ม`,
      payoutRate: ev.payoutRate,
      currentUsed: used,
      maxLimit: max,
      usagePercent: usagePct,
      canAccept: true,
    };
  }

  return {
    type,
    shortType,
    level: 'normal',
    statusText: `ปกติ (จ่าย ${ev.payoutRate}บ.)`,
    shortBadge: `${shortType}:ปกติ`,
    payoutRate: ev.payoutRate,
    currentUsed: used,
    maxLimit: max,
    usagePercent: usagePct,
    canAccept: true,
  };
}

export const GridSelectorView: React.FC<GridSelectorViewProps> = ({
  configs,
  transactions,
  basket,
  onAddBatchToBasket,
  onOpenBasket,
  onNumberRiskSound,
}) => {
  const [selectedType, setSelectedType] = useState<GridBetType>('2ตัวบน');
  const [selectedNumbers, setSelectedNumbers] = useState<Set<string>>(new Set());
  const [amountStr, setAmountStr] = useState<string>('10');
  const [validationError, setValidationError] = useState<string | null>(null);
  const [showAllChannelsOnGrid, setShowAllChannelsOnGrid] = useState<boolean>(true);
  const [gridColsMode, setGridColsMode] = useState<'10' | '5'>('10');

  const amount = Math.max(0, Number(amountStr) || 0);

  // Toggle single number
  const toggleNumber = (num: string) => {
    setValidationError(null);
    const isAdding = !selectedNumbers.has(num);
    if (isAdding && onNumberRiskSound) {
      const checkTop = selectedType === '2ตัวบน' || selectedType === '2ตัวบน+ล่าง';
      const checkBottom = selectedType === '2ตัวล่าง' || selectedType === '2ตัวบน+ล่าง';
      const evTop = checkTop
        ? evaluateNumberRisk('2ตัวบน', num, amount || 1, configs, transactions, basket)
        : null;
      const evBot = checkBottom
        ? evaluateNumberRisk('2ตัวล่าง', num, amount || 1, configs, transactions, basket)
        : null;

      if (
        (evTop && (evTop.status === 'ปิดรับ' || !evTop.canAccept)) ||
        (evBot && (evBot.status === 'ปิดรับ' || !evBot.canAccept))
      ) {
        onNumberRiskSound('closed');
      } else if (
        (evTop && evTop.status === 'อั้นจ่าย') ||
        (evBot && evBot.status === 'อั้นจ่าย')
      ) {
        onNumberRiskSound('halfPay');
      }
    }
    setSelectedNumbers((prev) => {
      const next = new Set(prev);
      if (next.has(num)) {
        next.delete(num);
      } else {
        next.add(num);
      }
      return next;
    });
  };

  // Quick selection helpers
  const handleSelectAll = () => {
    setSelectedNumbers(new Set(ALL_100_NUMBERS));
    setValidationError(null);
  };

  const handleClearSelected = () => {
    setSelectedNumbers(new Set());
    setValidationError(null);
  };

  const handleSelectDoubles = () => {
    const doubles = ALL_100_NUMBERS.filter((n) => n[0] === n[1]);
    setSelectedNumbers(new Set(doubles));
    setValidationError(null);
  };

  const handleSelectEvens = () => {
    const evens = ALL_100_NUMBERS.filter((n) => Number(n) % 2 === 0);
    setSelectedNumbers(new Set(evens));
    setValidationError(null);
  };

  const handleSelectOdds = () => {
    const odds = ALL_100_NUMBERS.filter((n) => Number(n) % 2 === 1);
    setSelectedNumbers(new Set(odds));
    setValidationError(null);
  };

  const handleSelectSiblings = () => {
    const siblings = ALL_100_NUMBERS.filter((n) => {
      const d1 = Number(n[0]);
      const d2 = Number(n[1]);
      const diff = Math.abs(d1 - d2);
      return diff === 1 || (d1 === 0 && d2 === 9) || (d1 === 9 && d2 === 0);
    });
    setSelectedNumbers(new Set(siblings));
    setValidationError(null);
  };

  const handleResetAll = () => {
    setSelectedNumbers(new Set());
    setAmountStr('');
    setValidationError(null);
  };

  // Dual-channel risk map for all 100 numbers (แยกชัดเจนระหว่าง 2ตัวบน และ 2ตัวล่าง)
  const dualRiskMap = useMemo(() => {
    const map = new Map<string, NumberDualRisk>();
    ALL_100_NUMBERS.forEach((num) => {
      const top = analyzeChannelRisk('2ตัวบน', num, amount, configs, transactions, basket);
      const bottom = analyzeChannelRisk('2ตัวล่าง', num, amount, configs, transactions, basket);
      map.set(num, { number: num, top, bottom });
    });
    return map;
  }, [configs, transactions, basket, amount]);

  // Watchlist of numbers that have non-normal status on Top vs Bottom
  const topAlertNumbers = useMemo(() => {
    const list: NumberDualRisk[] = [];
    dualRiskMap.forEach((val) => {
      if (val.top.level !== 'normal') list.push(val);
    });
    return list;
  }, [dualRiskMap]);

  const bottomAlertNumbers = useMemo(() => {
    const list: NumberDualRisk[] = [];
    dualRiskMap.forEach((val) => {
      if (val.bottom.level !== 'normal') list.push(val);
    });
    return list;
  }, [dualRiskMap]);

  // Calculations
  const selectedCount = selectedNumbers.size;
  const multiplier = selectedType === '2ตัวบน+ล่าง' ? 2 : 1;
  const totalItemsCount = selectedCount * multiplier;
  const totalCost = totalItemsCount * amount;

  // Confirm and submit to basket
  const handleConfirm = () => {
    if (selectedCount === 0) {
      setValidationError('กรุณาจิ้มเลือกตัวเลขอย่างน้อย 1 หมายเลขจากตาราง 00-99');
      return;
    }
    if (amount <= 0) {
      setValidationError('กรุณาระบุจำนวนเงินเดิมพัน (บาท)');
      return;
    }

    const typesToGenerate: ('2ตัวบน' | '2ตัวล่าง')[] =
      selectedType === '2ตัวบน+ล่าง' ? ['2ตัวบน', '2ตัวล่าง'] : [selectedType as '2ตัวบน' | '2ตัวล่าง'];

    const newItems: BasketItem[] = [];
    let halfPayCount = 0;
    let closedCount = 0;

    const sortedNums = Array.from(selectedNumbers).sort();

    sortedNums.forEach((num) => {
      typesToGenerate.forEach((t) => {
        const ev = evaluateNumberRisk(t, num, amount, configs, transactions, [
          ...basket,
          ...newItems,
        ]);

        if (ev.status === 'ปิดรับ' || !ev.canAccept) {
          closedCount++;
          return;
        }

        if (ev.status === 'อั้นจ่าย') {
          halfPayCount++;
        }

        newItems.push({
          id: `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          type: t,
          number: num,
          amount,
          payoutRate: ev.payoutRate,
          status: ev.status,
          sentAmount: ev.sentAmount,
          keepAmount: ev.keepAmount,
          note: selectedType === '2ตัวบน+ล่าง' ? 'ชุดบน+ล่าง' : undefined,
        });
      });
    });

    onAddBatchToBasket(newItems, {
      selectedCount,
      halfPayCount,
      closedCount,
      betType: selectedType,
      totalAmount: newItems.reduce((s, it) => s + it.amount, 0),
    });

    setSelectedNumbers(new Set());
    setValidationError(null);
  };

  // Helper to style badge based on level
  const getBadgeStyle = (level: CellAlertLevel) => {
    switch (level) {
      case 'closed':
        return 'bg-rose-600 text-white border-rose-400';
      case 'full':
        return 'bg-orange-600 text-white border-orange-400';
      case 'halfPay':
        return 'bg-amber-400 text-slate-950 border-amber-300';
      case 'nearFull':
        return 'bg-sky-500 text-slate-950 border-sky-300';
      default:
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-emerald-500 flex items-center justify-center text-slate-950 font-black shadow-md shadow-indigo-500/20">
              <Grid3X3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>แผงจิ้มเลขด่วน 00-99</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-mono font-medium">
                  10×10 Grid
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                แสดงป้ายกำกับแยกชัดเจนว่าเลขไหนติดสถานะของ <strong className="text-amber-300">บน</strong> หรือ <strong className="text-sky-300">ล่าง</strong> (อั้นจ่าย / ใกล้เต็ม / เต็มเพดาน / ปิดรับ)
              </p>
            </div>
          </div>

          {/* Quick Counter */}
          <div className="flex items-center gap-2 text-xs">
            <div className="px-3 py-1.5 rounded-xl bg-slate-850 border border-slate-700/80 flex items-center gap-1.5 font-mono">
              <span className="text-slate-400">เลือกแล้ว:</span>
              <span className="font-bold text-emerald-400 text-sm">
                {selectedCount}
              </span>
              <span className="text-slate-400">ตัว</span>
            </div>
            {basket.length > 0 && (
              <button
                type="button"
                onClick={onOpenBasket}
                className="px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25 font-medium flex items-center gap-1 cursor-pointer transition-all"
              >
                <span>ดูตะกร้า ({basket.length})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Control Panel: Bet Type & Amount */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg space-y-4">
        {/* Row 1: Bet Type Selection */}
        <div>
          <label className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>1. เลือกประเภทการแทง</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['2ตัวบน', '2ตัวล่าง', '2ตัวบน+ล่าง'] as GridBetType[]).map((type) => {
              const isSelected = selectedType === type;
              return (
                <button
                  key={type}
                  type="button"
                  onClick={() => setSelectedType(type)}
                  className={`py-2.5 px-2 rounded-xl text-xs sm:text-sm font-bold flex flex-col items-center justify-center gap-0.5 border transition-all cursor-pointer active:scale-95 ${
                    isSelected
                      ? 'bg-gradient-to-b from-indigo-500 to-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-500/30 ring-2 ring-indigo-400/30'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-750 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-1">
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                    <span>{type}</span>
                  </div>
                  <span
                    className={`text-[10px] font-normal ${
                      isSelected ? 'text-indigo-100' : 'text-slate-400'
                    }`}
                  >
                    {type === '2ตัวบน+ล่าง' ? 'แทง 2 เด้ง (บน+ล่าง)' : 'จ่าย 90 บ.'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Row 2: Amount Input & Quick Chips */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>2. ระบุจำนวนเงินต่อเลข (บาท)</span>
            </label>
            <span className="text-[11px] text-slate-400">
              {selectedType === '2ตัวบน+ล่าง'
                ? '(จะคูณ 2 รายการสำหรับบนและล่าง)'
                : ''}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono font-bold text-sm">
                ฿
              </span>
              <input
                type="number"
                min="1"
                step="1"
                value={amountStr}
                onChange={(e) => {
                  setAmountStr(e.target.value);
                  setValidationError(null);
                }}
                placeholder="ระบุราคา เช่น 20"
                className="w-full pl-8 pr-3 py-2.5 bg-slate-950 border border-slate-700 focus:border-amber-400 focus:ring-1 focus:ring-amber-400 rounded-xl text-amber-400 font-mono font-bold text-base outline-none transition-all placeholder:text-slate-600"
              />
            </div>
            {amountStr && (
              <button
                type="button"
                onClick={() => setAmountStr('')}
                className="p-2.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
                title="ลบจำนวนเงิน"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Amount Chips */}
          <div className="flex flex-wrap items-center gap-1.5 mt-2">
            <span className="text-[11px] text-slate-400 shrink-0">ราคายอดนิยม:</span>
            {PRESET_AMOUNTS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => {
                  setAmountStr(p.toString());
                  setValidationError(null);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold border transition-all cursor-pointer active:scale-95 ${
                  amountStr === p.toString()
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                ฿{p}
              </button>
            ))}
          </div>
        </div>

        {/* Row 3: Quick Filter Helper Buttons */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-400" />
              <span>3. ปุ่มลัดเลือกกลุ่มเลขด่วน</span>
            </span>
            <span className="text-[11px] text-slate-400">แตะเพื่อเลือกทีละชุด</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={handleSelectDoubles}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-teal-300 text-xs font-medium cursor-pointer transition-all active:scale-95 flex items-center gap-1"
            >
              <span>เลขเบิ้ล (10 ตัว)</span>
            </button>
            <button
              type="button"
              onClick={handleSelectSiblings}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-sky-300 text-xs font-medium cursor-pointer transition-all active:scale-95 flex items-center gap-1"
            >
              <span>เลขพี่น้อง (20 ตัว)</span>
            </button>
            <button
              type="button"
              onClick={handleSelectEvens}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-medium cursor-pointer transition-all active:scale-95"
            >
              <span>เลขคู่ (50 ตัว)</span>
            </button>
            <button
              type="button"
              onClick={handleSelectOdds}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-medium cursor-pointer transition-all active:scale-95"
            >
              <span>เลขคี่ (50 ตัว)</span>
            </button>
            <button
              type="button"
              onClick={handleSelectAll}
              className="px-2.5 py-1.5 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-700/60 text-indigo-300 text-xs font-medium cursor-pointer transition-all active:scale-95 flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>เลือกทั้งหมด 100 ตัว</span>
            </button>
            {selectedCount > 0 && (
              <button
                type="button"
                onClick={handleClearSelected}
                className="px-2.5 py-1.5 rounded-xl bg-rose-950/30 hover:bg-rose-900/50 border border-rose-800/40 text-rose-300 text-xs font-medium cursor-pointer transition-all active:scale-95 flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>ยกเลิกที่เลือก</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* NEW: Explicit Top (บน) vs Bottom (ล่าง) Watchlist Summary Box */}
      {(topAlertNumbers.length > 0 || bottomAlertNumbers.length > 0) && (
        <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-3.5 shadow-lg space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>สรุปเลขแจ้งเตือนแยกประเภท (บน / ล่าง) ในงวดปัจจุบัน:</span>
            </div>

            {/* Toggle whether grid cells show both บน & ล่าง badges simultaneously or only selectedType */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-[11px]">
              <button
                type="button"
                onClick={() => setShowAllChannelsOnGrid(true)}
                className={`px-2.5 py-1 rounded-lg font-semibold cursor-pointer transition-all ${
                  showAllChannelsOnGrid
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                แสดงป้ายทั้ง บน+ล่าง
              </button>
              <button
                type="button"
                onClick={() => setShowAllChannelsOnGrid(false)}
                className={`px-2.5 py-1 rounded-lg font-semibold cursor-pointer transition-all ${
                  !showAllChannelsOnGrid
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                เฉพาะประเภทที่เลือก ({selectedType})
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs">
            {/* 2 ตัวบน Box */}
            <div className="p-2.5 rounded-xl bg-slate-950/90 border border-amber-500/30 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-300 flex items-center gap-1.5">
                  <ArrowUpCircle className="w-4 h-4 text-amber-400" />
                  <span>แจ้งเตือน 2 ตัวบน (สัญลักษณ์ "บน")</span>
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300">
                  {topAlertNumbers.length} เลข
                </span>
              </div>

              {topAlertNumbers.length === 0 ? (
                <div className="text-[11px] text-slate-500">ไม่มีเลขอั้นหรือเต็มเพดานในหมวด 2 ตัวบน</div>
              ) : (
                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  {topAlertNumbers.map((item) => (
                    <button
                      key={`top_${item.number}`}
                      type="button"
                      onClick={() => toggleNumber(item.number)}
                      className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/80 flex items-center gap-1.5 cursor-pointer transition-all"
                      title={item.top.statusText}
                    >
                      <span className="font-mono font-extrabold text-sm text-white">
                        {item.number}
                      </span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-bold border ${getBadgeStyle(
                          item.top.level
                        )}`}
                      >
                        {item.top.shortBadge}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        ({item.top.currentUsed.toLocaleString()}/{item.top.maxLimit.toLocaleString()})
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 2 ตัวล่าง Box */}
            <div className="p-2.5 rounded-xl bg-slate-950/90 border border-sky-500/30 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sky-300 flex items-center gap-1.5">
                  <ArrowDownCircle className="w-4 h-4 text-sky-400" />
                  <span>แจ้งเตือน 2 ตัวล่าง (สัญลักษณ์ "ล่าง")</span>
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-300">
                  {bottomAlertNumbers.length} เลข
                </span>
              </div>

              {bottomAlertNumbers.length === 0 ? (
                <div className="text-[11px] text-slate-500">ไม่มีเลขอั้นหรือเต็มเพดานในหมวด 2 ตัวล่าง</div>
              ) : (
                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  {bottomAlertNumbers.map((item) => (
                    <button
                      key={`bot_${item.number}`}
                      type="button"
                      onClick={() => toggleNumber(item.number)}
                      className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/80 flex items-center gap-1.5 cursor-pointer transition-all"
                      title={item.bottom.statusText}
                    >
                      <span className="font-mono font-extrabold text-sm text-white">
                        {item.number}
                      </span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-bold border ${getBadgeStyle(
                          item.bottom.level
                        )}`}
                      >
                        {item.bottom.shortBadge}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        ({item.bottom.currentUsed.toLocaleString()}/{item.bottom.maxLimit.toLocaleString()})
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Validation Alert */}
      {validationError && (
        <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200 text-xs flex items-center gap-2 animate-in fade-in">
          <Ban className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{validationError}</span>
        </div>
      )}

      {/* 10x10 Number Grid Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 sm:p-3.5 shadow-xl">
        {/* Grid Legend Header + 10x10 vs 5x20 Mobile Density Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5 pb-2 border-b border-slate-800 text-xs">
          <div className="flex items-center gap-1.5">
            <Grid3X3 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-bold text-slate-200 text-[11px] sm:text-xs">
              ตาราง 00–99 (ป้าย บน/ล่าง)
            </span>
          </div>

          {/* Toggle 10-cols (full 10x10 on S22 360px) vs 5-cols (larger touch buttons) */}
          <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[10px]">
            <button
              type="button"
              onClick={() => setGridColsMode('10')}
              className={`px-2 py-1 rounded-md font-bold cursor-pointer transition-all ${
                gridColsMode === '10'
                  ? 'bg-indigo-500 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              10×10 เต็มแผง
            </button>
            <button
              type="button"
              onClick={() => setGridColsMode('5')}
              className={`px-2 py-1 rounded-md font-bold cursor-pointer transition-all ${
                gridColsMode === '5'
                  ? 'bg-indigo-500 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              5×20 ปุ่มใหญ่
            </button>
          </div>
        </div>

        {/* Clear Symbol & Color Legend */}
        <div className="flex flex-wrap items-center gap-1.5 mb-2.5 text-[9px] sm:text-[10px] text-slate-300">
          <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-bold">
            บน:อั้น / ล่าง:อั้น = จ่ายครึ่ง
          </span>
          <span className="px-1.5 py-0.5 rounded bg-sky-500 text-slate-950 font-bold">
            บน:ใกล้ / ล่าง:ใกล้ = ≥75%
          </span>
          <span className="px-1.5 py-0.5 rounded bg-orange-600 text-white font-bold">
            บน:เต็ม / ล่าง:เต็ม = ตีเกิน
          </span>
          <span className="px-1.5 py-0.5 rounded bg-rose-600 text-white font-bold">
            บน:ปิด / ล่าง:ปิด = ปิดรับ
          </span>
        </div>

        {/* The 10x10 Grid optimized for 360px Samsung S22 5G */}
        <div
          className={`grid ${
            gridColsMode === '10' ? 'grid-cols-10 gap-1' : 'grid-cols-5 gap-1.5'
          } select-none touch-manipulation`}
        >
          {ALL_100_NUMBERS.map((num) => {
            const isSelected = selectedNumbers.has(num);
            const dual = dualRiskMap.get(num)!;

            // Decide which channel alerts to display on the cell
            const showTopAlert =
              dual.top.level !== 'normal' &&
              (showAllChannelsOnGrid ||
                selectedType === '2ตัวบน' ||
                selectedType === '2ตัวบน+ล่าง');

            const showBottomAlert =
              dual.bottom.level !== 'normal' &&
              (showAllChannelsOnGrid ||
                selectedType === '2ตัวล่าง' ||
                selectedType === '2ตัวบน+ล่าง');

            // Determine cell border/background highlight for active betType
            const activeLevels: CellAlertLevel[] = [];
            if (showTopAlert) activeLevels.push(dual.top.level);
            if (showBottomAlert) activeLevels.push(dual.bottom.level);

            const hasClosed = activeLevels.includes('closed');
            const hasFull = activeLevels.includes('full');
            const hasHalfPay = activeLevels.includes('halfPay');
            const hasNearFull = activeLevels.includes('nearFull');

            const tooltipLines = [
              `หมายเลข ${num}`,
              `• 2ตัวบน: ${dual.top.statusText} (สะสม ${dual.top.currentUsed.toLocaleString()}/${dual.top.maxLimit.toLocaleString()} บ.)`,
              `• 2ตัวล่าง: ${dual.bottom.statusText} (สะสม ${dual.bottom.currentUsed.toLocaleString()}/${dual.bottom.maxLimit.toLocaleString()} บ.)`,
            ].join('\n');

            const isCompact10 = gridColsMode === '10';

            return (
              <button
                key={num}
                type="button"
                onClick={() => toggleNumber(num)}
                title={tooltipLines}
                className={`relative ${
                  isCompact10
                    ? 'min-h-[42px] sm:min-h-[52px] py-0.5 px-0.5 rounded-lg'
                    : 'min-h-[52px] py-1 px-1 rounded-xl'
                } font-mono font-bold flex flex-col items-center justify-between transition-transform duration-75 cursor-pointer active:scale-95 ${
                  isSelected
                    ? 'bg-gradient-to-b from-emerald-500 to-teal-600 text-slate-950 shadow-md shadow-emerald-500/30 ring-1 ring-emerald-300 font-extrabold z-10'
                    : hasClosed
                    ? 'bg-rose-950/45 border border-rose-500/75 text-rose-200 hover:bg-rose-900/50'
                    : hasFull
                    ? 'bg-orange-950/45 border border-orange-500/75 text-orange-200 hover:bg-orange-900/50'
                    : hasHalfPay
                    ? 'bg-amber-950/40 border border-amber-500/75 text-amber-200 hover:bg-amber-900/50'
                    : hasNearFull
                    ? 'bg-sky-950/40 border border-sky-500/65 text-sky-200 hover:bg-sky-900/50'
                    : 'bg-slate-800/90 hover:bg-slate-750 border border-slate-700/70 text-slate-200'
                }`}
              >
                {/* Top Row: Number */}
                <span
                  className={`${
                    isCompact10 ? 'text-[11px] sm:text-sm' : 'text-sm sm:text-base'
                  } tracking-tight leading-none mt-0.5 ${
                    isSelected ? 'text-slate-950 font-black' : ''
                  }`}
                >
                  {num}
                </span>

                {/* Bottom Row: Explicit Type & Status Badges ("บน:..." / "ล่าง:...") */}
                <div className="w-full flex flex-col items-center justify-end gap-0.5 mt-0.5">
                  {showTopAlert && (
                    <span
                      className={`w-full text-center px-0.5 rounded ${
                        isCompact10 ? 'text-[7px] sm:text-[9px]' : 'text-[9px]'
                      } leading-tight font-sans font-extrabold truncate border ${getBadgeStyle(
                        dual.top.level
                      )}`}
                    >
                      {dual.top.shortBadge}
                    </span>
                  )}

                  {showBottomAlert && (
                    <span
                      className={`w-full text-center px-0.5 rounded ${
                        isCompact10 ? 'text-[7px] sm:text-[9px]' : 'text-[9px]'
                      } leading-tight font-sans font-extrabold truncate border ${getBadgeStyle(
                        dual.bottom.level
                      )}`}
                    >
                      {dual.bottom.shortBadge}
                    </span>
                  )}

                  {!showTopAlert && !showBottomAlert && (
                    <span
                      className={`${
                        isCompact10 ? 'text-[7px] sm:text-[9px]' : 'text-[9px]'
                      } font-sans font-normal ${
                        isSelected ? 'text-slate-900 font-semibold' : 'text-slate-500'
                      }`}
                    >
                      {isSelected ? 'เลือก' : 'ปกติ'}
                    </span>
                  )}
                </div>

                {/* Checked badge when selected */}
                {isSelected && (
                  <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-slate-950 text-emerald-400 flex items-center justify-center text-[9px] shadow-xs border border-emerald-400">
                    ✓
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center gap-1.5 text-[10px] sm:text-[11px] text-slate-400">
          <Info className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          <span>
            ป้าย <strong className="text-amber-300">บน:...</strong> = 2 ตัวบน | <strong className="text-sky-300">ล่าง:...</strong> = 2 ตัวล่าง (สลับโหมด 10×10 หรือ 5×20 ด้านบนได้ตามถนัด)
          </span>
        </div>
      </div>

      {/* Sticky Action Bar at Bottom of Grid Tab */}
      <div className="sticky bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-3 py-2.5 z-30 rounded-2xl shadow-2xl">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-1 text-[10px] text-slate-400">
              <span className="font-semibold text-slate-300">{selectedType}</span>
              <span>•</span>
              <span className="font-mono text-emerald-400 font-bold">
                {selectedCount} เลข
              </span>
              {selectedType === '2ตัวบน+ล่าง' && (
                <span className="text-[9px] text-indigo-300">
                  ({totalItemsCount} รายการ)
                </span>
              )}
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-[11px] text-slate-400">รวม:</span>
              <span className="text-sm sm:text-base font-bold font-mono text-amber-400">
                ฿{totalCost.toLocaleString()}
              </span>
              <span className="text-[9px] text-slate-500 font-mono">
                (@฿{amount || 0})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handleResetAll}
              disabled={selectedCount === 0 && !amountStr}
              className="py-2 px-2.5 rounded-xl border border-rose-500/30 bg-rose-950/20 hover:bg-rose-950/40 active:scale-95 text-rose-400 font-semibold text-xs flex items-center gap-1 disabled:opacity-40 cursor-pointer transition-transform duration-75"
              title="ล้างตัวเลขและราคาที่เลือกทั้งหมด"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>ล้าง</span>
            </button>

            <button
              type="button"
              onClick={handleConfirm}
              disabled={selectedCount === 0 || amount <= 0}
              className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center gap-1 transition-transform duration-75 shadow-md active:scale-95 cursor-pointer ${
                selectedCount > 0 && amount > 0
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-emerald-500/25 ring-1 ring-emerald-300/40'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/60'
              }`}
            >
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>ยืนยัน ({totalItemsCount})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
