import React, { useState, useEffect } from 'react';
import {
  Clock,
  Lock,
  Unlock,
  Settings2,
  Timer,
} from 'lucide-react';

export interface CutoffConfig {
  enabled: boolean;
  cutoffTime: string; // HH:mm e.g., "15:30"
  manualForceClosed: boolean;
}

interface CutoffTimerBannerProps {
  cutoffConfig: CutoffConfig;
  onUpdateCutoffConfig: (newConfig: CutoffConfig) => void;
  isMarketClosed: boolean;
}

export const CutoffTimerBanner: React.FC<CutoffTimerBannerProps> = ({
  cutoffConfig,
  onUpdateCutoffConfig,
  isMarketClosed,
}) => {
  const [now, setNow] = useState<Date>(new Date());
  const [isEditing, setIsEditing] = useState(false);
  const [tempTime, setTempTime] = useState(cutoffConfig.cutoffTime);

  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Calculate remaining time until cutoffTime today
  const getRemainingInfo = () => {
    if (cutoffConfig.manualForceClosed) {
      return {
        expired: true,
        text: 'ล็อกปิดรับโพยด่วน',
        urgent: true,
      };
    }

    if (!cutoffConfig.enabled) {
      return {
        expired: false,
        text: 'เปิดรับโพยปกติ',
        urgent: false,
      };
    }

    const [hh, mm] = cutoffConfig.cutoffTime.split(':').map(Number);
    const target = new Date(now);
    target.setHours(hh || 15, mm || 30, 0, 0);

    const diffMs = target.getTime() - now.getTime();
    if (diffMs <= 0) {
      return {
        expired: true,
        text: `หมดเวลา (${cutoffConfig.cutoffTime} น.)`,
        urgent: true,
      };
    }

    const totalSec = Math.floor(diffMs / 1000);
    const hours = Math.floor(totalSec / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;

    const pad = (n: number) => String(n).padStart(2, '0');
    const urgent = totalSec < 1800; // Less than 30 mins

    return {
      expired: false,
      text: `${pad(hours)}:${pad(minutes)}:${pad(seconds)} (ปิด ${cutoffConfig.cutoffTime})`,
      urgent,
    };
  };

  const info = getRemainingInfo();

  const handleSaveTime = () => {
    onUpdateCutoffConfig({
      ...cutoffConfig,
      cutoffTime: tempTime || '15:30',
      enabled: true,
      manualForceClosed: false,
    });
    setIsEditing(false);
  };

  return (
    <div
      className={`rounded-xl border px-2.5 py-1.5 mb-2 transition-all ${
        isMarketClosed
          ? 'bg-rose-950/75 border-rose-500/60 text-rose-100'
          : info.urgent
          ? 'bg-amber-950/65 border-amber-500/50 text-amber-100'
          : 'bg-slate-900/95 border-slate-800 text-slate-200'
      }`}
    >
      <div className="flex items-center justify-between gap-1.5">
        {/* Left Status & Countdown */}
        <div className="flex items-center gap-1.5 min-w-0">
          <div
            className={`p-1 rounded-lg shrink-0 flex items-center justify-center ${
              isMarketClosed
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                : info.urgent
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            }`}
          >
            {isMarketClosed ? (
              <Lock className="w-3.5 h-3.5" />
            ) : (
              <Timer className="w-3.5 h-3.5" />
            )}
          </div>

          <div className="flex items-center gap-1.5 min-w-0">
            <span
              className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase shrink-0 ${
                isMarketClosed
                  ? 'bg-rose-500 text-white'
                  : 'bg-emerald-500 text-slate-950'
              }`}
            >
              {isMarketClosed ? 'CLOSED' : 'OPEN'}
            </span>
            <span className="text-[11px] font-mono font-bold tracking-tight truncate">
              {info.text}
            </span>
          </div>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-1 shrink-0">
          {isMarketClosed ? (
            <button
              type="button"
              onClick={() =>
                onUpdateCutoffConfig({
                  ...cutoffConfig,
                  manualForceClosed: false,
                  enabled: false,
                })
              }
              className="px-2 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-[10px] flex items-center gap-1 cursor-pointer transition-transform duration-75"
              title="ปลดล็อกเพื่อเปิดรับโพยต่อ"
            >
              <Unlock className="w-3 h-3" />
              <span>เปิดรับ</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() =>
                onUpdateCutoffConfig({
                  ...cutoffConfig,
                  manualForceClosed: true,
                })
              }
              className="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 active:scale-95 text-rose-300 border border-rose-500/40 font-semibold text-[10px] flex items-center gap-1 cursor-pointer transition-transform duration-75"
              title="กดเพื่อล็อกปิดรับโพยทันที"
            >
              <Lock className="w-3 h-3" />
              <span>ปิดด่วน</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              setTempTime(cutoffConfig.cutoffTime);
              setIsEditing(!isEditing);
            }}
            className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer"
            title="ตั้งเวลาปิดรับโพยอัตโนมัติ"
          >
            <Settings2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Expandable Time Settings */}
      {isEditing && (
        <div className="mt-2 pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-1.5 text-[11px] animate-in fade-in">
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-300">เวลาปิด:</span>
            <input
              type="time"
              value={tempTime}
              onChange={(e) => setTempTime(e.target.value)}
              className="px-1.5 py-0.5 rounded bg-slate-950 border border-slate-700 text-amber-400 font-mono font-bold text-xs"
            />
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => {
                onUpdateCutoffConfig({
                  ...cutoffConfig,
                  enabled: !cutoffConfig.enabled,
                  manualForceClosed: false,
                });
                setIsEditing(false);
              }}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer text-[10px]"
            >
              {cutoffConfig.enabled ? 'ปิดนับเวลา' : 'เปิดนับเวลา'}
            </button>
            <button
              type="button"
              onClick={handleSaveTime}
              className="px-2.5 py-1 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold cursor-pointer text-[10px]"
            >
              บันทึก
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
