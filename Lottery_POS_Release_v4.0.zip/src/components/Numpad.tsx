import React from 'react';
import { Delete, X } from 'lucide-react';

interface NumpadProps {
  onKeyPress: (key: string) => void;
  onClear: () => void;
  onDelete: () => void;
}

export const Numpad: React.FC<NumpadProps> = ({ onKeyPress, onClear, onDelete }) => {
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

  return (
    <div className="grid grid-cols-3 gap-1.5 w-full touch-manipulation">
      {keys.map((num) => (
        <button
          key={num}
          type="button"
          onClick={() => onKeyPress(num)}
          className="h-11 sm:h-12 bg-slate-800/95 hover:bg-slate-700 active:scale-[0.96] active:bg-emerald-500/20 active:border-emerald-500/50 text-slate-100 font-bold text-xl rounded-xl border border-slate-700/70 transition-transform duration-75 shadow-xs flex items-center justify-center font-mono tabular-nums cursor-pointer select-none"
        >
          {num}
        </button>
      ))}

      {/* Clear Key */}
      <button
        type="button"
        onClick={onClear}
        className="h-11 sm:h-12 bg-rose-950/45 hover:bg-rose-900/60 active:scale-[0.96] text-rose-400 font-bold rounded-xl border border-rose-800/50 transition-transform duration-75 shadow-xs flex items-center justify-center cursor-pointer select-none"
        title="ล้างทั้งหมด (Clear)"
      >
        <span className="flex items-center gap-1 text-xs font-sans">
          <X className="w-4 h-4" />
          <span>ล้าง</span>
        </span>
      </button>

      {/* Zero Key */}
      <button
        type="button"
        onClick={() => onKeyPress('0')}
        className="h-11 sm:h-12 bg-slate-800/95 hover:bg-slate-700 active:scale-[0.96] active:bg-emerald-500/20 active:border-emerald-500/50 text-slate-100 font-bold text-xl rounded-xl border border-slate-700/70 transition-transform duration-75 shadow-xs flex items-center justify-center font-mono tabular-nums cursor-pointer select-none"
      >
        0
      </button>

      {/* Backspace Key */}
      <button
        type="button"
        onClick={onDelete}
        className="h-11 sm:h-12 bg-amber-950/45 hover:bg-amber-900/60 active:scale-[0.96] text-amber-400 font-bold rounded-xl border border-amber-800/50 transition-transform duration-75 shadow-xs flex items-center justify-center cursor-pointer select-none"
        title="ลบทีละตัว (Backspace)"
      >
        <Delete className="w-5 h-5" />
      </button>
    </div>
  );
};
