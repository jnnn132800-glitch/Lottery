import React, { useState, useMemo } from 'react';
import { Transaction } from '../types/lottery';
import { EditableBillItem } from '../utils/lotteryLogic';
import {
  Search,
  Download,
  Calendar,
  User,
  RotateCcw,
  Receipt,
  Eye,
  Trash2,
  ChevronDown,
  ChevronUp,
  LayoutList,
  Layers,
  ArrowUpDown,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Repeat,
  Percent,
  Pencil,
  Lock,
  Check,
  X,
} from 'lucide-react';

interface TransactionsTableProps {
  transactions: Transaction[];
  isPeriodLocked?: boolean;
  onExportCSV: () => void;
  onViewReceipt?: (billId: string) => void;
  onDeleteBill?: (billId: string) => void;
  onEditBill?: (
    billId: string,
    updatedMeta: { customerName: string; discountPercent: number },
    updatedItems: EditableBillItem[]
  ) => void;
  onRebetBill?: (billId: string) => void;
}

export const TransactionsTable: React.FC<TransactionsTableProps> = ({
  transactions,
  isPeriodLocked = false,
  onExportCSV,
  onViewReceipt,
  onDeleteBill,
  onEditBill,
  onRebetBill,
}) => {
  // Edit Bill Modal State
  const [editingBillId, setEditingBillId] = useState<string | null>(null);
  const [editCustomerName, setEditCustomerName] = useState<string>('');
  const [editDiscountPct, setEditDiscountPct] = useState<number>(0);
  const [editItems, setEditItems] = useState<EditableBillItem[]>([]);

  const handleOpenEditModal = (billId: string) => {
    const billRows = transactions.filter((t) => t.billId === billId);
    if (!billRows.length) return;
    setEditingBillId(billId);
    setEditCustomerName(billRows[0].customerName || 'ลูกค้าทั่วไป');
    setEditDiscountPct(billRows[0].discountPercent || 0);
    setEditItems(
      billRows.map((r, idx) => ({
        originalIndex: idx,
        type: r.type,
        number: r.number,
        amount: r.amount,
        deleted: false,
      }))
    );
  };

  const handleSaveEditModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBillId || !onEditBill) return;
    onEditBill(
      editingBillId,
      { customerName: editCustomerName, discountPercent: editDiscountPct },
      editItems
    );
    setEditingBillId(null);
  };
  // Filters State
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('all');
  const [selectedDate, setSelectedDate] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [sortBy, setSortBy] = useState<'latest' | 'oldest' | 'amountDesc' | 'amountAsc'>('latest');

  // View Mode: 'bills' (Grouped by Bill) or 'items' (Individual transaction rows)
  const [viewMode, setViewMode] = useState<'bills' | 'items'>('bills');
  const [expandedBills, setExpandedBills] = useState<Record<string, boolean>>({});

  // Unique list of customers from transactions
  const uniqueCustomers = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach((tx) => {
      if (tx.customerName && tx.customerName.trim()) {
        set.add(tx.customerName.trim());
      }
    });
    return Array.from(set).sort();
  }, [transactions]);

  // Unique list of dates (YYYY-MM-DD)
  const uniqueDates = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach((tx) => {
      if (tx.timestamp) {
        const d = tx.timestamp.split(' ')[0];
        if (d) set.add(d);
      }
    });
    return Array.from(set).sort().reverse();
  }, [transactions]);

  // Today string in YYYY-MM-DD
  const todayStr = useMemo(() => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }, []);

  // Filter logic
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !q ||
        tx.billId.toLowerCase().includes(q) ||
        tx.customerName.toLowerCase().includes(q) ||
        tx.number.includes(q);

      const matchesCustomer =
        selectedCustomer === 'all' ||
        tx.customerName.trim() === selectedCustomer.trim();

      const matchesDate =
        !selectedDate ||
        (tx.timestamp && tx.timestamp.startsWith(selectedDate));

      const matchesType = filterType === 'all' || tx.type === filterType;
      const matchesStatus = filterStatus === 'all' || tx.status === filterStatus;

      return matchesSearch && matchesCustomer && matchesDate && matchesType && matchesStatus;
    });
  }, [transactions, searchTerm, selectedCustomer, selectedDate, filterType, filterStatus]);

  // Sorted items
  const sortedTransactions = useMemo(() => {
    const list = [...filteredTransactions];
    if (sortBy === 'latest') {
      return list.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
    }
    if (sortBy === 'oldest') {
      return list.sort((a, b) => a.timestamp.localeCompare(b.timestamp));
    }
    if (sortBy === 'amountDesc') {
      return list.sort((a, b) => b.amount - a.amount);
    }
    if (sortBy === 'amountAsc') {
      return list.sort((a, b) => a.amount - b.amount);
    }
    return list;
  }, [filteredTransactions, sortBy]);

  // Grouped by Bill ID for 'bills' view
  const groupedBills = useMemo(() => {
    const map = new Map<
      string,
      {
        billId: string;
        customerName: string;
        timestamp: string;
        drawPeriod?: string;
        discountPercent: number;
        items: Transaction[];
        totalAmount: number;
        discountAmount: number;
        netAmount: number;
        keepAmount: number;
        sentAmount: number;
        hasHalfPay: boolean;
        hasClosed: boolean;
      }
    >();

    sortedTransactions.forEach((tx) => {
      const discPct = tx.discountPercent || 0;
      const b = map.get(tx.billId) || {
        billId: tx.billId,
        customerName: tx.customerName || 'ลูกค้าทั่วไป',
        timestamp: tx.timestamp,
        drawPeriod: tx.drawPeriod,
        discountPercent: discPct,
        items: [],
        totalAmount: 0,
        discountAmount: 0,
        netAmount: 0,
        keepAmount: 0,
        sentAmount: 0,
        hasHalfPay: false,
        hasClosed: false,
      };

      const isClosed = tx.status === 'ปิดรับ';
      const activeAmt = isClosed ? 0 : tx.amount;
      const activeKeep = isClosed ? 0 : tx.keepAmount;
      const activeSent = isClosed ? 0 : tx.sentAmount;

      b.items.push(tx);
      b.totalAmount += activeAmt;
      b.discountAmount = Math.round((b.totalAmount * b.discountPercent) / 100);
      b.netAmount = b.totalAmount - b.discountAmount;
      b.keepAmount += activeKeep;
      b.sentAmount += activeSent;
      if (tx.status === 'อั้นจ่าย') b.hasHalfPay = true;
      if (isClosed) b.hasClosed = true;

      map.set(tx.billId, b);
    });

    return Array.from(map.values());
  }, [sortedTransactions]);

  // KPI calculations on filtered items (exclude 'ปิดรับ' from active sales/keep/sent totals)
  const totalAmount = filteredTransactions.reduce(
    (s, tx) => s + (tx.status === 'ปิดรับ' ? 0 : tx.amount),
    0
  );
  const totalNetAfterDiscount = groupedBills.reduce((s, b) => s + b.netAmount, 0);
  const totalDiscountGiven = totalAmount - totalNetAfterDiscount;
  const totalKeep = filteredTransactions.reduce(
    (s, tx) => s + (tx.status === 'ปิดรับ' ? 0 : tx.keepAmount),
    0
  );
  const totalSent = filteredTransactions.reduce(
    (s, tx) => s + (tx.status === 'ปิดรับ' ? 0 : tx.sentAmount),
    0
  );
  const totalBillsCount = groupedBills.length;

  const toggleBillExpand = (billId: string) => {
    setExpandedBills((prev) => ({
      ...prev,
      [billId]: !prev[billId],
    }));
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCustomer('all');
    setSelectedDate('');
    setFilterType('all');
    setFilterStatus('all');
    setSortBy('latest');
  };

  const isAnyFilterActive =
    searchTerm !== '' ||
    selectedCustomer !== 'all' ||
    selectedDate !== '' ||
    filterType !== 'all' ||
    filterStatus !== 'all';

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
        <div className="bg-slate-800/80 p-3 sm:p-4 rounded-2xl border border-slate-700/60 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 text-[11px] sm:text-xs mb-1">
            <span>จำนวนบิลที่ค้นพบ</span>
            <Receipt className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <span className="text-xl sm:text-2xl font-bold font-mono text-slate-100">
            {totalBillsCount}{' '}
            <span className="text-xs font-normal text-slate-400">
              บิล ({filteredTransactions.length} รายการ)
            </span>
          </span>
        </div>

        <div className="bg-slate-800/80 p-3 sm:p-4 rounded-2xl border border-slate-700/60 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 text-[11px] sm:text-xs mb-1">
            <span>ยอดหน้าโพย / สุทธิหักส่วนลด</span>
            <Layers className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <span className="text-xl sm:text-2xl font-bold font-mono text-amber-400">
            ฿{totalNetAfterDiscount.toLocaleString()}
          </span>
          {totalDiscountGiven > 0 && (
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">
              หน้าโพย ฿{totalAmount.toLocaleString()} (ลด -฿{totalDiscountGiven.toLocaleString()})
            </div>
          )}
        </div>

        <div className="bg-emerald-950/40 p-3 sm:p-4 rounded-2xl border border-emerald-800/50 shadow-xs">
          <div className="flex items-center justify-between text-emerald-400 text-[11px] sm:text-xs mb-1">
            <span>ยอดถือเอง (Keep)</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <span className="text-xl sm:text-2xl font-bold font-mono text-emerald-400">
            ฿{totalKeep.toLocaleString()}
          </span>
        </div>

        <div className="bg-rose-950/40 p-3 sm:p-4 rounded-2xl border border-rose-800/50 shadow-xs">
          <div className="flex items-center justify-between text-rose-400 text-[11px] sm:text-xs mb-1">
            <span>ยอดตีเกินส่งต่อ (Sent)</span>
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <span className="text-xl sm:text-2xl font-bold font-mono text-rose-400">
            ฿{totalSent.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Filter and Search Control Panel */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-3 sm:p-4 space-y-3 shadow-md">
        {/* Row 1: Search Input & View Switcher */}
        <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center justify-between">
          {/* Main Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ค้นหาบิล, ชื่อลูกค้า หรือตัวเลขที่แทง..."
              className="w-full pl-9 pr-8 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>

          {/* View Mode Toggle: Grouped by Bill vs Itemized Rows */}
          <div className="flex items-center gap-1.5 self-end sm:self-auto">
            <div className="bg-slate-950 p-1 rounded-xl border border-slate-700/80 flex items-center gap-1 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('bills')}
                className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-medium transition-all cursor-pointer ${
                  viewMode === 'bills'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="จัดกลุ่มตามบิล (บิลย่อ)"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>มุมมองบิล ({totalBillsCount})</span>
              </button>

              <button
                type="button"
                onClick={() => setViewMode('items')}
                className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-medium transition-all cursor-pointer ${
                  viewMode === 'items'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="แสดงแยกทุกรายการ"
              >
                <LayoutList className="w-3.5 h-3.5" />
                <span>ทุกรายการ ({filteredTransactions.length})</span>
              </button>
            </div>

            {/* Export CSV button */}
            <button
              type="button"
              onClick={onExportCSV}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs sm:text-sm font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer whitespace-nowrap shadow-xs"
              title="ส่งออก Transactions.csv"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">ส่งออก CSV</span>
            </button>
          </div>
        </div>

        {/* Row 2: Customer Filter, Date Filter, Type & Status Filters */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
          <div className="col-span-1">
            <label className="text-[11px] text-slate-400 block mb-1 flex items-center gap-1">
              <User className="w-3 h-3 text-sky-400" />
              <span>ชื่อลูกค้า</span>
            </label>
            <select
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none focus:border-sky-500"
            >
              <option value="all">ลูกค้าทั้งหมด ({uniqueCustomers.length})</option>
              {uniqueCustomers.map((cust) => (
                <option key={cust} value={cust}>
                  {cust}
                </option>
              ))}
            </select>
          </div>

          <div className="col-span-1">
            <label className="text-[11px] text-slate-400 block mb-1 flex items-center gap-1">
              <Calendar className="w-3 h-3 text-amber-400" />
              <span>วันที่บันทึก</span>
            </label>
            <div className="relative">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none focus:border-amber-500 font-mono text-xs"
              />
              {selectedDate && (
                <button
                  type="button"
                  onClick={() => setSelectedDate('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  title="ล้างวันที่"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          <div className="col-span-1">
            <label className="text-[11px] text-slate-400 block mb-1">ประเภทหวย</label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none"
            >
              <option value="all">ทุกประเภท</option>
              <option value="2ตัวบน">2ตัวบน</option>
              <option value="2ตัวล่าง">2ตัวล่าง</option>
              <option value="3ตัวตรง">3ตัวตรง</option>
              <option value="3ตัวโต๊ด">3ตัวโต๊ด</option>
              <option value="วิ่งบน">วิ่งบน</option>
              <option value="วิ่งล่าง">วิ่งล่าง</option>
            </select>
          </div>

          <div className="col-span-1">
            <label className="text-[11px] text-slate-400 block mb-1">สถานะบิล</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none"
            >
              <option value="all">ทุกสถานะ</option>
              <option value="ปกติ">ปกติ (จ่ายเต็ม)</option>
              <option value="อั้นจ่าย">อั้นจ่าย (จ่ายครึ่ง)</option>
              <option value="ปิดรับ">ปิดรับ</option>
            </select>
          </div>

          <div className="col-span-2 sm:col-span-1">
            <label className="text-[11px] text-slate-400 block mb-1 flex items-center gap-1">
              <ArrowUpDown className="w-3 h-3 text-emerald-400" />
              <span>เรียงลำดับ</span>
            </label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none"
            >
              <option value="latest">เวลาล่าสุดก่อน</option>
              <option value="oldest">เวลาเก่าสุดก่อน</option>
              <option value="amountDesc">ยอดเงิน มาก ➔ น้อย</option>
              <option value="amountAsc">ยอดเงิน น้อย ➔ มาก</option>
            </select>
          </div>
        </div>

        {/* Row 3: Active Filters & Quick Date Shortcuts */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/80 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-slate-400 text-[11px]">ทางลัดวันที่:</span>
            <button
              type="button"
              onClick={() => setSelectedDate(todayStr)}
              className={`px-2.5 py-1 rounded-lg border text-[11px] cursor-pointer transition-colors ${
                selectedDate === todayStr
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                  : 'bg-slate-950 hover:bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              วันนี้ ({todayStr})
            </button>

            {uniqueDates
              .filter((d) => d !== todayStr)
              .slice(0, 3)
              .map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setSelectedDate(d)}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] cursor-pointer transition-colors ${
                    selectedDate === d
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                      : 'bg-slate-950 hover:bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  {d}
                </button>
              ))}

            {selectedDate && (
              <button
                type="button"
                onClick={() => setSelectedDate('')}
                className="px-2 py-0.5 rounded text-[11px] text-slate-400 hover:text-white"
              >
                ดูทุกวัน
              </button>
            )}
          </div>

          {isAnyFilterActive && (
            <button
              type="button"
              onClick={handleResetFilters}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3 h-3 text-rose-400" />
              <span>ล้างตัวกรองทั้งหมด</span>
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: BILLS GROUPED VIEW */}
      {viewMode === 'bills' && (
        <div className="space-y-3">
          {groupedBills.length === 0 ? (
            <div className="bg-slate-800/80 rounded-2xl border border-slate-700/60 p-12 text-center text-slate-400">
              <Receipt className="w-12 h-12 mx-auto stroke-1 mb-2 opacity-50" />
              <p className="font-semibold text-slate-300">ไม่พบบิลที่ตรงกับเงื่อนไขการค้นหา</p>
              <p className="text-xs text-slate-500 mt-1">ลองเปลี่ยนชื่อลูกค้า วันที่ หรือคำค้นหา</p>
            </div>
          ) : (
            groupedBills.map((bill) => {
              const isExpanded = !!expandedBills[bill.billId];

              return (
                <div
                  key={bill.billId}
                  className="bg-slate-900/90 rounded-2xl border border-slate-800 hover:border-slate-700 overflow-hidden shadow-sm transition-all"
                >
                  {/* Bill Card Header */}
                  <div className="p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    {/* Left: Bill ID, Customer, Timestamp */}
                    <div className="flex items-start sm:items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-400">
                        <Receipt className="w-5 h-5" />
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono font-bold text-base text-sky-400">
                            {bill.billId}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1">
                            <User className="w-3 h-3 text-slate-400" />
                            <span>{bill.customerName}</span>
                          </span>

                          {bill.discountPercent > 0 && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 flex items-center gap-0.5">
                              <Percent className="w-2.5 h-2.5" />
                              <span>ส่วนลด {bill.discountPercent}%</span>
                            </span>
                          )}

                          {bill.hasHalfPay && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
                              มีเลขอั้นจ่าย
                            </span>
                          )}

                          {bill.hasClosed && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
                              มีเลขปิดรับ
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2.5 text-[11px] text-slate-400 mt-1 flex-wrap">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-slate-500" />
                            <span className="font-mono">{bill.timestamp}</span>
                          </span>
                          <span>•</span>
                          <span>{bill.items.length} รายการ</span>
                          {bill.drawPeriod && (
                            <>
                              <span>•</span>
                              <span className="text-emerald-400 font-medium">{bill.drawPeriod}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right: Amounts & Actions */}
                    <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                      <div className="text-left sm:text-right">
                        <div className="text-[11px] text-slate-400">
                          {bill.discountPercent > 0
                            ? `สุทธิหักส่วนลด ${bill.discountPercent}%`
                            : 'ยอดรวมบิล'}
                        </div>
                        <div className="text-lg sm:text-xl font-bold font-mono text-amber-400">
                          ฿{bill.netAmount.toLocaleString()}
                        </div>
                        {bill.discountPercent > 0 && (
                          <div className="text-[10px] text-indigo-300 font-mono">
                            หน้าโพย ฿{bill.totalAmount.toLocaleString()} (-฿{bill.discountAmount.toLocaleString()})
                          </div>
                        )}
                        <div className="text-[10px] text-slate-400">
                          ถือ: <span className="text-emerald-400 font-mono">฿{bill.keepAmount.toLocaleString()}</span>
                          {bill.sentAmount > 0 && (
                            <>
                              {' '}
                              | ส่ง: <span className="text-rose-400 font-mono">฿{bill.sentAmount.toLocaleString()}</span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5">
                        {onRebetBill && (
                          <button
                            type="button"
                            onClick={() => onRebetBill(bill.billId)}
                            className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-400 active:scale-95 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                            title="ดึงเลขและราคาจากบิลนี้เข้าตะกร้าเพื่อแทงซ้ำทันที"
                          >
                            <Repeat className="w-3.5 h-3.5" />
                            <span>แทงซ้ำ</span>
                          </button>
                        )}

                        {onViewReceipt && (
                          <button
                            type="button"
                            onClick={() => onViewReceipt(bill.billId)}
                            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                            title="ดูสลิป / บันทึกรูป PNG / พิมพ์บิลนี้"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>ดูสลิป</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => toggleBillExpand(bill.billId)}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 text-xs flex items-center gap-1 cursor-pointer"
                          title="ดูรายการย่อยในบิล"
                        >
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </button>

                        {onEditBill && (
                          <button
                            type="button"
                            disabled={isPeriodLocked}
                            onClick={() => handleOpenEditModal(bill.billId)}
                            className={`p-1.5 rounded-xl border text-xs flex items-center gap-1 transition-colors ${
                              isPeriodLocked
                                ? 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
                                : 'bg-slate-800 hover:bg-amber-500/20 border-slate-700 hover:border-amber-500/40 text-amber-400 cursor-pointer'
                            }`}
                            title={
                              isPeriodLocked
                                ? 'งวดนี้ถูกล็อกแล้ว ห้ามแก้ไขโดยไม่ได้รับอนุญาต'
                                : 'แก้ไขบิลนี้ (ชื่อลูกค้า, ส่วนลด, ตัวเลข, จำนวนเงิน)'
                            }
                          >
                            {isPeriodLocked ? (
                              <Lock className="w-3.5 h-3.5" />
                            ) : (
                              <Pencil className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}

                        {onDeleteBill && (
                          <button
                            type="button"
                            disabled={isPeriodLocked}
                            onClick={() => onDeleteBill(bill.billId)}
                            className={`p-1.5 rounded-xl transition-colors ${
                              isPeriodLocked
                                ? 'text-slate-700 cursor-not-allowed'
                                : 'text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 cursor-pointer'
                            }`}
                            title={
                              isPeriodLocked
                                ? 'งวดนี้ถูกล็อกแล้ว ห้ามลบบิลโดยไม่ได้รับอนุญาต'
                                : 'ยกเลิก/ลบบิลนี้'
                            }
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Item List Inside This Bill */}
                  {isExpanded && (
                    <div className="border-t border-slate-800/80 bg-slate-950/60 p-3 sm:p-4 animate-in fade-in">
                      <div className="text-xs font-semibold text-slate-400 mb-2">
                        รายการแทงในบิล {bill.billId} ({bill.items.length} รายการ):
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {bill.items.map((item, idx) => (
                          <div
                            key={idx}
                            className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs"
                          >
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-semibold text-slate-300">{item.type}</span>
                                <span className="font-mono font-bold text-amber-400 text-sm">
                                  {item.number}
                                </span>
                                {typeof item.payoutRate === 'number' && item.payoutRate > 0 && (
                                  <span className="text-[10px] font-mono text-sky-300 bg-sky-500/10 px-1.5 py-0.2 rounded border border-sky-500/20">
                                    เรท {item.payoutRate}
                                  </span>
                                )}
                              </div>
                              <div className="text-[10px] text-slate-400 mt-0.5">
                                ถือ: <span className="text-emerald-400 font-mono">฿{item.keepAmount}</span>
                                {item.sentAmount > 0 && (
                                  <span className="text-rose-400 font-mono ml-1">
                                    ส่ง ฿{item.sentAmount}
                                  </span>
                                )}
                              </div>
                            </div>

                            <div className="text-right">
                              <div className="font-mono font-bold text-slate-100">
                                ฿{item.amount.toLocaleString()}
                              </div>
                              <span
                                className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-bold ${
                                  item.status === 'ปกติ'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : item.status === 'อั้นจ่าย'
                                    ? 'bg-amber-500/10 text-amber-400'
                                    : 'bg-rose-500/10 text-rose-400'
                                }`}
                              >
                                {item.status}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* VIEW 2: ITEMIZED TABLE VIEW */}
      {viewMode === 'items' && (
        <div className="bg-slate-800/80 rounded-2xl border border-slate-700/60 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-700/80 uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-3">Timestamp</th>
                  <th className="py-3 px-3">Bill_ID</th>
                  <th className="py-3 px-3">Customer</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3 text-center">Number</th>
                  <th className="py-3 px-3 text-right">Amount</th>
                  <th className="py-3 px-3 text-center">Discount</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-3 text-right">Sent_Amount</th>
                  <th className="py-3 px-3 text-right">Keep_Amount</th>
                  {onViewReceipt && <th className="py-3 px-3 text-center">สลิป</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40">
                {sortedTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="py-10 text-center text-slate-400">
                      ไม่พบรายการเดิมพันที่ตรงกับตัวกรอง
                    </td>
                  </tr>
                ) : (
                  sortedTransactions.map((tx, idx) => (
                    <tr key={idx} className="hover:bg-slate-750/50 transition-colors">
                      <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px] whitespace-nowrap">
                        {tx.timestamp}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-sky-400">
                        {tx.billId}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-200 truncate max-w-[120px]">
                        {tx.customerName || '-'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-300 font-medium">
                        {tx.type}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono font-bold text-amber-400 text-sm">
                        {tx.number}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-100">
                        ฿{tx.amount.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono text-indigo-300 text-xs">
                        {tx.discountPercent ? `${tx.discountPercent}%` : '-'}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            tx.status === 'ปกติ'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : tx.status === 'อั้นจ่าย'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {tx.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-rose-400 font-medium">
                        {tx.sentAmount > 0 ? `฿${tx.sentAmount.toLocaleString()}` : '-'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-400 font-medium">
                        ฿{tx.keepAmount.toLocaleString()}
                      </td>
                      {onViewReceipt && (
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => onViewReceipt(tx.billId)}
                            className="p-1 rounded text-slate-400 hover:text-emerald-400 hover:bg-slate-700/50 cursor-pointer"
                            title="ดูสลิปบิลนี้"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* EDIT BILL MODAL */}
      {editingBillId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl max-w-md w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-2">
                <Pencil className="w-4 h-4 text-amber-400" />
                <div>
                  <h3 className="font-bold text-sm text-white">
                    แก้ไขข้อมูลบิล {editingBillId}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    เมื่อบันทึก ระบบจะคำนวณเกลี่ยยอด Keep / Sent ใหม่ตามลำดับเวลาอัตโนมัติ
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingBillId(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditModal} className="flex-1 overflow-y-auto p-4 space-y-4">
              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-8">
                  <label className="text-[11px] text-slate-400 block mb-1">ชื่อลูกค้า</label>
                  <input
                    type="text"
                    value={editCustomerName}
                    onChange={(e) => setEditCustomerName(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
                <div className="col-span-4">
                  <label className="text-[11px] text-indigo-300 block mb-1">ส่วนลด (%)</label>
                  <input
                    type="number"
                    min={0}
                    max={50}
                    value={editDiscountPct}
                    onChange={(e) =>
                      setEditDiscountPct(Math.max(0, Math.min(50, Number(e.target.value) || 0)))
                    }
                    className="w-full px-2.5 py-1.5 bg-slate-800 border border-indigo-500/40 rounded-lg text-xs font-mono font-bold text-indigo-300 text-center focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>รายการในบิล ({editItems.filter((i) => !i.deleted).length} รายการ)</span>
                  <span className="text-[10px] text-slate-400">ปรับเลขหรือจำนวนเงินได้</span>
                </div>

                {editItems.map((it, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-xl border transition-all ${
                      it.deleted
                        ? 'bg-rose-950/20 border-rose-500/30 opacity-50'
                        : 'bg-slate-800/80 border-slate-700'
                    }`}
                  >
                    <div className="grid grid-cols-12 gap-1.5 items-center">
                      <div className="col-span-4">
                        <select
                          disabled={it.deleted}
                          value={it.type}
                          onChange={(e) => {
                            const nextType = e.target.value;
                            setEditItems((prev) =>
                              prev.map((row, rIdx) =>
                                rIdx === idx ? { ...row, type: nextType } : row
                              )
                            );
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-[11px] text-slate-200 focus:outline-none"
                        >
                          <option value="2ตัวบน">2ตัวบน</option>
                          <option value="2ตัวล่าง">2ตัวล่าง</option>
                          <option value="3ตัวตรง">3ตัวตรง</option>
                          <option value="3ตัวโต๊ด">3ตัวโต๊ด</option>
                          <option value="วิ่งบน">วิ่งบน</option>
                          <option value="วิ่งล่าง">วิ่งล่าง</option>
                        </select>
                      </div>

                      <div className="col-span-3">
                        <input
                          type="text"
                          disabled={it.deleted}
                          value={it.number}
                          maxLength={it.type.startsWith('3') ? 3 : it.type.startsWith('2') ? 2 : 1}
                          onChange={(e) => {
                            const val = e.target.value.replace(/\D/g, '');
                            setEditItems((prev) =>
                              prev.map((row, rIdx) =>
                                rIdx === idx ? { ...row, number: val } : row
                              )
                            );
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs font-mono font-bold text-amber-400 text-center focus:outline-none"
                          placeholder="เลข"
                        />
                      </div>

                      <div className="col-span-4">
                        <input
                          type="number"
                          min={1}
                          disabled={it.deleted}
                          value={it.amount}
                          onChange={(e) => {
                            const val = Math.max(0, Number(e.target.value) || 0);
                            setEditItems((prev) =>
                              prev.map((row, rIdx) =>
                                rIdx === idx ? { ...row, amount: val } : row
                              )
                            );
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs font-mono font-bold text-emerald-400 text-right focus:outline-none"
                          placeholder="บาท"
                        />
                      </div>

                      <div className="col-span-1 flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            setEditItems((prev) =>
                              prev.map((row, rIdx) =>
                                rIdx === idx ? { ...row, deleted: !row.deleted } : row
                              )
                            );
                          }}
                          className={`p-1 rounded-lg cursor-pointer ${
                            it.deleted
                              ? 'text-emerald-400 hover:bg-emerald-500/20'
                              : 'text-slate-400 hover:text-rose-400 hover:bg-rose-500/20'
                          }`}
                          title={it.deleted ? 'กู้คืนแถวนี้' : 'ลบแถวนี้'}
                        >
                          {it.deleted ? (
                            <RotateCcw className="w-3.5 h-3.5" />
                          ) : (
                            <Trash2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingBillId(null)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>บันทึกการแก้ไขบิล</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
