import React, { useState } from 'react';
import { Copy, Check, FileCode, ExternalLink, HelpCircle, Download } from 'lucide-react';

interface GoogleAppsScriptExportProps {
  codeGsSource: string;
  indexHtmlSource: string;
}

export const GoogleAppsScriptExport: React.FC<GoogleAppsScriptExportProps> = ({
  codeGsSource,
  indexHtmlSource,
}) => {
  const [activeTab, setActiveTab] = useState<'codegs' | 'indexhtml' | 'guide'>('codegs');
  const [copiedCodeGs, setCopiedCodeGs] = useState(false);
  const [copiedIndexHtml, setCopiedIndexHtml] = useState(false);

  const handleCopyCodeGs = () => {
    navigator.clipboard.writeText(codeGsSource);
    setCopiedCodeGs(true);
    setTimeout(() => setCopiedCodeGs(false), 2000);
  };

  const handleCopyIndexHtml = () => {
    navigator.clipboard.writeText(indexHtmlSource);
    setCopiedIndexHtml(true);
    setTimeout(() => setCopiedIndexHtml(false), 2000);
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-800/40 rounded-2xl p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                <FileCode className="w-5 h-5" />
              </span>
              <h3 className="font-bold text-lg text-slate-100">
                Source Code สำหรับ Google Apps Script (พร้อมติดตั้ง)
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              โค้ดถูกปรับโครงสร้างคอลัมน์ให้ตรงกับไฟล์ <code className="text-emerald-400">Config_Settings</code>,{' '}
              <code className="text-emerald-400">Transactions</code>, และ{' '}
              <code className="text-emerald-400">Summary_Risk</code> พอดีเป๊ะ 100% นำไปวางแล้วใช้งานได้ทันที
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'guide'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              }`}
            >
              <HelpCircle className="w-4 h-4" />
              <span>วิธีติดตั้ง 6 ขั้นตอน</span>
            </button>
          </div>
        </div>

        {/* Tab switchers */}
        <div className="flex gap-2 mt-4 pt-3 border-t border-slate-800">
          <button
            onClick={() => setActiveTab('codegs')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'codegs'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20 font-bold'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            <span className="font-mono">Code.gs</span>
            <span className="text-[10px] bg-slate-900/50 px-1.5 py-0.5 rounded text-slate-300">Backend Logic</span>
          </button>

          <button
            onClick={() => setActiveTab('indexhtml')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'indexhtml'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20 font-bold'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            <span className="font-mono">Index.html</span>
            <span className="text-[10px] bg-slate-900/50 px-1.5 py-0.5 rounded text-slate-300">Mobile POS UI</span>
          </button>
        </div>
      </div>

      {/* Guide Tab */}
      {activeTab === 'guide' && (
        <div className="bg-slate-800/80 rounded-2xl border border-slate-700/60 p-5 space-y-4 text-sm">
          <h4 className="font-bold text-base text-emerald-400 flex items-center gap-2">
            <span>คู่มือการติดตั้ง Google Apps Script เชื่อมต่อ Google Sheets ใน 3 นาที</span>
          </h4>

          <ol className="space-y-3 list-decimal list-inside text-slate-300 leading-relaxed">
            <li className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/50">
              <strong className="text-slate-100">สร้างไฟล์ Google Sheets:</strong>
              <div className="text-xs text-slate-400 mt-1 pl-5">
                สร้างสเปรดชีตใหม่ โดยให้มี 3 แผ่นงาน (Sheet Tabs) ดังนี้:
                <ul className="list-disc list-inside mt-1 space-y-0.5 font-mono text-emerald-300">
                  <li>Config_Settings</li>
                  <li>Transactions</li>
                  <li>Summary_Risk</li>
                </ul>
                (หากยังไม่มีแผ่นงาน ตัวสคริปต์ Code.gs มีระบบ Auto-initialize สร้างให้เองอัตโนมัติเมื่อรันครั้งแรก)
              </div>
            </li>

            <li className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/50">
              <strong className="text-slate-100">เปิด Apps Script:</strong>
              <div className="text-xs text-slate-400 mt-1 pl-5">
                ที่เมนูด้านบนของ Google Sheets คลิกที่ <span className="text-sky-300 font-semibold">ส่วนขยาย (Extensions)</span> &gt; <span className="text-sky-300 font-semibold">Apps Script</span>
              </div>
            </li>

            <li className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/50">
              <strong className="text-slate-100">วางโค้ด Code.gs:</strong>
              <div className="text-xs text-slate-400 mt-1 pl-5">
                ลบโค้ดเดิมในแท็บ <code className="text-amber-400">Code.gs</code> ออกทั้งหมด แล้วกดปุ่ม <strong>"คัดลอก Code.gs"</strong> ด้านบนมาวาง จากนั้นกดปุ่ม <span className="text-slate-200">บันทึก (Ctrl + S)</span>
              </div>
            </li>

            <li className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/50">
              <strong className="text-slate-100">สร้างไฟล์ Index.html:</strong>
              <div className="text-xs text-slate-400 mt-1 pl-5">
                กดเครื่องหมาย <span className="text-emerald-400 font-bold">+ (เพิ่มไฟล์)</span> ข้างๆ เมนูไฟล์ เลือก <strong>HTML</strong> แล้วตั้งชื่อว่า <code className="text-amber-400">Index</code> จากนั้นนำโค้ดจากแท็บ <strong>"Index.html"</strong> มาวางทั้งหมด แล้วกดบันทึก
              </div>
            </li>

            <li className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/50">
              <strong className="text-slate-100">การทำให้ใช้งานได้ (Deploy as Web App):</strong>
              <div className="text-xs text-slate-400 mt-1 pl-5">
                คลิกปุ่มสีน้ำเงินมุมบนขวา <span className="text-sky-400 font-bold">การทำให้ใช้งานได้ (Deploy)</span> &gt; <span className="text-slate-200 font-semibold">การทำให้ใช้งานได้รายการใหม่ (New deployment)</span>:
                <ul className="list-disc list-inside mt-1 space-y-1 text-slate-300">
                  <li>คลิกไอคอนฟันเฟือง เลือก <strong>เว็บแอป (Web App)</strong></li>
                  <li>ตั้งค่า <strong>ดำเนินการในฐานะ (Execute as):</strong> ฉัน (อีเมลของคุณ)</li>
                  <li>ตั้งค่า <strong>ผู้ที่มีสิทธิ์เข้าถึง (Who has access):</strong> <span className="text-amber-400 font-bold">ทุกคน (Anyone)</span></li>
                </ul>
              </div>
            </li>

            <li className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/50">
              <strong className="text-slate-100">เปิดใช้งานบนมือถือ:</strong>
              <div className="text-xs text-slate-400 mt-1 pl-5">
                คัดลอก <strong>Web app URL</strong> ที่ได้ ไปเปิดใน Safari / Chrome บนมือถือ แล้วกด <span className="text-emerald-300 font-semibold">"เพิ่มไปยังหน้าจอโฮม (Add to Home Screen)"</span> จะได้ Web App ไอคอนเสมือนแอพแท้เต็มหน้าจอ ใช้งานได้สะดวกรวดเร็ว!
              </div>
            </li>
          </ol>
        </div>
      )}

      {/* Code.gs Tab */}
      {activeTab === 'codegs' && (
        <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
          <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 font-mono text-xs text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
              <span>Code.gs (Backend: doGet, getSettings, saveTransactions, updateSummaryRiskSheet)</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleDownload('Code.gs', codeGsSource)}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                title="ดาวน์โหลดไฟล์ Code.gs"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">ดาวน์โหลด</span>
              </button>
              <button
                type="button"
                onClick={handleCopyCodeGs}
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 shadow-sm cursor-pointer transition-all active:scale-95"
              >
                {copiedCodeGs ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCodeGs ? 'คัดลอกแล้ว!' : 'คัดลอก Code.gs'}</span>
              </button>
            </div>
          </div>
          <pre className="p-4 text-xs font-mono text-emerald-300/90 overflow-x-auto max-h-[500px] leading-relaxed selection:bg-emerald-800 selection:text-white">
            {codeGsSource}
          </pre>
        </div>
      )}

      {/* Index.html Tab */}
      {activeTab === 'indexhtml' && (
        <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
          <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 font-mono text-xs text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400"></span>
              <span>Index.html (Frontend Mobile POS UI with Bootstrap 5 + Smart Numpad)</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleDownload('Index.html', indexHtmlSource)}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                title="ดาวน์โหลดไฟล์ Index.html"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">ดาวน์โหลด</span>
              </button>
              <button
                type="button"
                onClick={handleCopyIndexHtml}
                className="px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 shadow-sm cursor-pointer transition-all active:scale-95"
              >
                {copiedIndexHtml ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedIndexHtml ? 'คัดลอกแล้ว!' : 'คัดลอก Index.html'}</span>
              </button>
            </div>
          </div>
          <pre className="p-4 text-xs font-mono text-sky-200/90 overflow-x-auto max-h-[500px] leading-relaxed selection:bg-sky-800 selection:text-white">
            {indexHtmlSource}
          </pre>
        </div>
      )}
    </div>
  );
};
