import React, { useState } from 'react';
import {
  CheckCircle2,
  Printer,
  X,
  ImageDown,
  Copy,
  Check,
  Percent,
  Calendar,
  FileText,
} from 'lucide-react';
import { Transaction } from '../types/lottery';

interface SlipReceiptModalProps {
  isOpen: boolean;
  billId: string;
  customerName: string;
  timestamp: string;
  drawPeriod?: string;
  discountPercent?: number;
  items: Transaction[];
  onClose: () => void;
}

type PaperFormat = 'standard' | '58mm' | '80mm';

export const SlipReceiptModal: React.FC<SlipReceiptModalProps> = ({
  isOpen,
  billId,
  customerName,
  timestamp,
  drawPeriod,
  discountPercent,
  items,
  onClose,
}) => {
  const [paperFormat, setPaperFormat] = useState<PaperFormat>('standard');
  const [copiedText, setCopiedText] = useState(false);
  const [isGeneratingImg, setIsGeneratingImg] = useState(false);

  if (!isOpen || !items.length) return null;

  const effectiveDrawPeriod =
    drawPeriod || items[0]?.drawPeriod || 'งวดวันที่ 16 พ.ย. 2569';
  const effectiveDiscountPct =
    discountPercent !== undefined
      ? discountPercent
      : items[0]?.discountPercent || 0;

  const totalGrossAmount = items.reduce(
    (s, it) => s + (it.status === 'ปิดรับ' ? 0 : it.amount),
    0
  );
  const discountAmount = Math.round((totalGrossAmount * effectiveDiscountPct) / 100);
  const netPayableAmount = totalGrossAmount - discountAmount;

  const totalKeep = items.reduce(
    (s, it) => s + (it.status === 'ปิดรับ' ? 0 : it.keepAmount),
    0
  );
  const totalSent = items.reduce(
    (s, it) => s + (it.status === 'ปิดรับ' ? 0 : it.sentAmount),
    0
  );

  const handlePrint = () => {
    window.print();
  };

  // Copy formatted text receipt for LINE chat
  const handleCopyLineSlip = () => {
    const lines = [
      `🧾 ใบเสร็จรับโพย (LOTTERY POS)`,
      `📅 ${effectiveDrawPeriod}`,
      `🔖 เลขที่บิล: ${billId}`,
      `👤 ลูกค้า: ${customerName || 'ลูกค้าทั่วไป'}`,
      `🕒 เวลา: ${timestamp}`,
      `------------------------`,
    ];

    items.forEach((it, idx) => {
      const rateTag = typeof it.payoutRate === 'number' && it.payoutRate > 0 ? ` (เรท ${it.payoutRate})` : '';
      const statusTag =
        it.status === 'อั้นจ่าย'
          ? ` (อั้นจ่าย${rateTag})`
          : it.status === 'ปิดรับ'
          ? ' (ปิดรับ - ไม่คิดยอด)'
          : rateTag;
      lines.push(
        `${idx + 1}. ${it.type} [${it.number}] = ฿${(it.status === 'ปิดรับ' ? 0 : it.amount).toLocaleString()}${statusTag}`
      );
    });

    lines.push(`------------------------`);
    lines.push(`🔢 รวม ${items.length} รายการ: ฿${totalGrossAmount.toLocaleString()}`);
    if (effectiveDiscountPct > 0) {
      lines.push(
        `🏷️ ส่วนลดค่าโพย (${effectiveDiscountPct}%): -฿${discountAmount.toLocaleString()}`
      );
      lines.push(`💰 ยอดชำระสุทธิ: ฿${netPayableAmount.toLocaleString()} บาท`);
    } else {
      lines.push(`💰 ยอดชำระทั้งสิ้น: ฿${totalGrossAmount.toLocaleString()} บาท`);
    }
    lines.push(`✅ บันทึกเข้าระบบเรียบร้อย ขอบคุณที่ใช้บริการ`);

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Render high-resolution PNG slip using HTML5 Canvas
  const handleSaveAsPng = () => {
    setIsGeneratingImg(true);
    try {
      const scale = 2; // Retina 2x resolution
      const width = paperFormat === '58mm' ? 320 : 380;
      const rowHeight = 28;
      const baseHeight = 290 + (effectiveDiscountPct > 0 ? 48 : 0);
      const height = baseHeight + items.length * rowHeight;

      const canvas = document.createElement('canvas');
      canvas.width = width * scale;
      canvas.height = height * scale;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.scale(scale, scale);

      // Paper background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);

      // Top decorative emerald bar
      ctx.fillStyle = '#10b981';
      ctx.fillRect(0, 0, width, 8);

      let y = 32;

      // Title
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 18px Prompt, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('LOTTERY POS RECEIPT', width / 2, y);

      y += 18;
      ctx.fillStyle = '#475569';
      ctx.font = '12px Prompt, sans-serif';
      ctx.fillText(`ใบเสร็จรับเดิมพัน • ${effectiveDrawPeriod}`, width / 2, y);

      y += 14;
      // Dashed divider
      ctx.strokeStyle = '#cbd5e1';
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      ctx.moveTo(16, y);
      ctx.lineTo(width - 16, y);
      ctx.stroke();

      y += 20;
      // Bill & Customer info
      ctx.textAlign = 'left';
      ctx.fillStyle = '#334155';
      ctx.font = 'bold 12px Prompt, monospace';
      ctx.fillText(`บิล: ${billId}`, 18, y);

      ctx.textAlign = 'right';
      ctx.fillText(`ลูกค้า: ${customerName || 'ลูกค้าทั่วไป'}`, width - 18, y);

      y += 18;
      ctx.textAlign = 'left';
      ctx.fillStyle = '#64748b';
      ctx.font = '11px Prompt, monospace';
      ctx.fillText(`เวลา: ${timestamp}`, 18, y);

      y += 12;
      ctx.beginPath();
      ctx.moveTo(16, y);
      ctx.lineTo(width - 16, y);
      ctx.stroke();

      // Table Header
      y += 18;
      ctx.fillStyle = '#334155';
      ctx.font = 'bold 11px Prompt, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('#', 18, y);
      ctx.fillText('ประเภท', 42, y);
      ctx.textAlign = 'center';
      ctx.fillText('ตัวเลข', width * 0.58, y);
      ctx.textAlign = 'right';
      ctx.fillText('จำนวนเงิน', width - 18, y);

      y += 8;
      ctx.setLineDash([]);
      ctx.strokeStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.moveTo(16, y);
      ctx.lineTo(width - 16, y);
      ctx.stroke();

      // Items rows
      items.forEach((it, idx) => {
        y += rowHeight;
        // Alternate row tint
        if (idx % 2 === 1) {
          ctx.fillStyle = '#f8fafc';
          ctx.fillRect(16, y - 18, width - 32, rowHeight - 2);
        }

        ctx.fillStyle = '#94a3b8';
        ctx.font = '11px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`${idx + 1}`, 18, y);

        ctx.fillStyle = '#1e293b';
        ctx.font = '600 12px Prompt, sans-serif';
        const rateSuffix = typeof it.payoutRate === 'number' && it.payoutRate > 0 ? ` (@${it.payoutRate})` : '';
        const statusSuffix =
          it.status === 'อั้นจ่าย'
            ? ` (อั้น${rateSuffix})`
            : it.status === 'ปิดรับ'
            ? ' (ปิดรับ)'
            : rateSuffix;
        ctx.fillText(`${it.type}${statusSuffix}`, 42, y);

        ctx.fillStyle = '#0f172a';
        ctx.font = 'bold 14px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(it.number, width * 0.58, y);

        ctx.fillStyle = '#0f172a';
        ctx.font = 'bold 12px monospace';
        ctx.textAlign = 'right';
        const displayAmt = it.status === 'ปิดรับ' ? 0 : it.amount;
        ctx.fillText(`฿${displayAmt.toLocaleString()}`, width - 18, y);
      });

      y += 14;
      ctx.strokeStyle = '#cbd5e1';
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      ctx.moveTo(16, y);
      ctx.lineTo(width - 16, y);
      ctx.stroke();

      // Totals section
      y += 22;
      ctx.fillStyle = '#475569';
      ctx.font = '12px Prompt, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`รวมทั้งหมด (${items.length} รายการ):`, 18, y);
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 13px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`฿${totalGrossAmount.toLocaleString()}`, width - 18, y);

      if (effectiveDiscountPct > 0) {
        y += 20;
        ctx.fillStyle = '#d97706';
        ctx.font = '600 12px Prompt, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`ส่วนลดค่าโพย (${effectiveDiscountPct}%):`, 18, y);
        ctx.textAlign = 'right';
        ctx.fillText(`-฿${discountAmount.toLocaleString()}`, width - 18, y);
      }

      y += 24;
      // Highlight box for Net Payable
      ctx.fillStyle = '#ecfdf5';
      ctx.fillRect(16, y - 17, width - 32, 28);
      ctx.fillStyle = '#047857';
      ctx.font = 'bold 13px Prompt, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('ยอดชำระสุทธิ (Net Total):', 22, y + 1);
      ctx.font = 'bold 16px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`฿${netPayableAmount.toLocaleString()}`, width - 22, y + 2);

      y += 30;
      ctx.fillStyle = '#64748b';
      ctx.font = '10px Prompt, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('*** ขอบคุณที่ใช้บริการ กรุณาเก็บสลิปไว้เป็นหลักฐาน ***', width / 2, y);

      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      const safeCust = (customerName || 'ลูกค้าทั่วไป').replace(/[^a-zA-Z0-9ก-๙_-]/g, '_');
      link.download = `Slip_${billId}_${safeCust}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } finally {
      setIsGeneratingImg(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs">
      {/* Print-only stylesheet for 58mm / 80mm thermal printers */}
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #lottery-slip-printable,
          #lottery-slip-printable * {
            visibility: visible !important;
          }
          #lottery-slip-printable {
            position: fixed !important;
            left: 0 !important;
            top: 0 !important;
            width: ${paperFormat === '58mm' ? '58mm' : paperFormat === '80mm' ? '80mm' : '100%'} !important;
            max-width: ${paperFormat === '58mm' ? '58mm' : paperFormat === '80mm' ? '80mm' : '380px'} !important;
            margin: 0 !important;
            padding: 8px !important;
            box-shadow: none !important;
            border-radius: 0 !important;
            background: #ffffff !important;
            color: #000000 !important;
          }
        }
      `}</style>

      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-4 sm:p-5 shadow-2xl text-slate-100 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base">สลิปใบเสร็จรับเดิมพัน</h3>
              <p className="text-[11px] text-slate-400">
                บันทึกรูปภาพ PNG ส่ง LINE หรือพิมพ์ออกเครื่องสลิปความร้อนได้ทันที
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Thermal Paper Width Selector — Fitted for 360px Samsung S22 5G */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-1.5 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs">
          <span className="text-[11px] text-slate-400 pl-1.5 flex items-center gap-1 shrink-0">
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            <span>ขนาดสลิป:</span>
          </span>
          <div className="flex items-center gap-1">
            {(
              [
                { id: 'standard', label: 'มือถือ' },
                { id: '58mm', label: 'สลิป 58mm' },
                { id: '80mm', label: 'สลิป 80mm' },
              ] as { id: PaperFormat; label: string }[]
            ).map((fmt) => (
              <button
                key={fmt.id}
                type="button"
                onClick={() => setPaperFormat(fmt.id)}
                className={`px-2 py-1 rounded-lg text-[10px] sm:text-[11px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  paperFormat === fmt.id
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {fmt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Printable Receipt Paper Preview */}
        <div className="my-3 overflow-y-auto flex justify-center bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
          <div
            id="lottery-slip-printable"
            className={`bg-white text-slate-900 rounded-xl p-4 font-mono text-xs shadow-md space-y-2.5 transition-all ${
              paperFormat === '58mm'
                ? 'w-[240px] text-[11px]'
                : paperFormat === '80mm'
                ? 'w-[310px] text-xs'
                : 'w-full'
            }`}
          >
            <div className="text-center pb-2 border-b-2 border-dashed border-slate-300">
              <h4 className="font-bold text-base font-sans tracking-tight text-slate-950">
                LOTTERY POS RECEIPT
              </h4>
              <div className="inline-flex items-center gap-1 px-2 py-0.5 mt-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-sans font-semibold">
                <Calendar className="w-3 h-3 text-emerald-600" />
                <span>{effectiveDrawPeriod}</span>
              </div>
              <div className="mt-1.5 flex justify-between text-[11px] text-slate-600">
                <span>
                  บิล: <strong className="text-black">{billId}</strong>
                </span>
                <span>
                  ลูกค้า:{' '}
                  <strong className="text-black">
                    {customerName || 'ลูกค้าทั่วไป'}
                  </strong>
                </span>
              </div>
              <div className="text-[10px] text-slate-500 text-left mt-0.5">
                เวลา: {timestamp}
              </div>
            </div>

            {/* Table Header */}
            <div className="grid grid-cols-12 font-bold text-[11px] border-b border-slate-200 pb-1 text-slate-700">
              <span className="col-span-1">#</span>
              <span className="col-span-4">ประเภท</span>
              <span className="col-span-3 text-center">เลข</span>
              <span className="col-span-4 text-right">ยอดแทง</span>
            </div>

            {/* Rows */}
            <div className="space-y-1.5 py-1">
              {items.map((it, idx) => (
                <div
                  key={idx}
                  className="grid grid-cols-12 items-center text-[11px]"
                >
                  <span className="col-span-1 text-slate-400">{idx + 1}</span>
                  <span className="col-span-4 font-sans font-medium text-slate-800 truncate">
                    {it.type}
                  </span>
                  <span className="col-span-3 text-center font-bold text-slate-900 text-sm">
                    {it.number}
                  </span>
                  <div className="col-span-4 text-right">
                    <span className="font-bold">
                      ฿{(it.status === 'ปิดรับ' ? 0 : it.amount).toLocaleString()}
                    </span>
                    {typeof it.payoutRate === 'number' && it.payoutRate > 0 && it.status !== 'ปิดรับ' && (
                      <span className="block text-[9px] text-slate-500 font-sans">
                        เรทจ่าย ×{it.payoutRate}
                      </span>
                    )}
                    {it.status === 'อั้นจ่าย' && (
                      <span className="block text-[9px] text-amber-600 font-sans font-semibold">
                        อั้นจ่าย
                      </span>
                    )}
                    {it.status === 'ปิดรับ' && (
                      <span className="block text-[9px] text-rose-600 font-sans font-semibold">
                        ปิดรับ (ไม่คิดยอด)
                      </span>
                    )}
                    {it.sentAmount > 0 && (
                      <span className="block text-[9px] text-rose-600 font-sans">
                        ส่งต่อ ฿{it.sentAmount.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Totals & Discount Breakdown */}
            <div className="pt-2 border-t-2 border-dashed border-slate-300 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-600">
                  ยอดรวม ({items.length} รายการ):
                </span>
                <span className="font-bold text-slate-900">
                  ฿{totalGrossAmount.toLocaleString()}
                </span>
              </div>

              {effectiveDiscountPct > 0 && (
                <div className="flex justify-between text-[11px] text-amber-700 font-semibold">
                  <span className="flex items-center gap-1">
                    <Percent className="w-3 h-3" />
                    <span>ส่วนลดค่าโพย ({effectiveDiscountPct}%):</span>
                  </span>
                  <span>-฿{discountAmount.toLocaleString()}</span>
                </div>
              )}

              <div className="flex justify-between items-center bg-emerald-50 border border-emerald-200 rounded-lg px-2 py-1.5 mt-1">
                <span className="font-sans font-bold text-xs text-emerald-900">
                  ยอดชำระสุทธิ:
                </span>
                <span className="font-bold text-sm sm:text-base text-emerald-700">
                  ฿{netPayableAmount.toLocaleString()}
                </span>
              </div>

              <div className="pt-1 flex justify-between text-[10px] text-slate-500">
                <span>ถือเอง: ฿{totalKeep.toLocaleString()}</span>
                {totalSent > 0 && (
                  <span className="text-rose-600">
                    ตีเกินส่งต่อ: ฿{totalSent.toLocaleString()}
                  </span>
                )}
              </div>
            </div>

            <div className="text-center pt-2 border-t border-slate-200 text-[10px] text-slate-400 font-sans">
              *** ขอบคุณที่ใช้บริการ / เก็บไว้เป็นหลักฐาน ***
            </div>
          </div>
        </div>

        {/* Action Buttons Grid */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleSaveAsPng}
              disabled={isGeneratingImg}
              className="py-2.5 px-3 rounded-xl bg-sky-500 hover:bg-sky-400 active:scale-95 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-sky-500/20 cursor-pointer"
            >
              <ImageDown className="w-4 h-4" />
              <span>
                {isGeneratingImg ? 'กำลังสร้างรูป...' : 'บันทึกรูปสลิป (PNG)'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleCopyLineSlip}
              className="py-2.5 px-3 rounded-xl bg-indigo-500 hover:bg-indigo-400 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-indigo-500/20 cursor-pointer"
            >
              {copiedText ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>คัดลอกส่ง LINE แล้ว!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>คัดลอกข้อความส่ง LINE</span>
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>พิมพ์สลิป ({paperFormat === 'standard' ? 'A4/มือถือ' : paperFormat})</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-emerald-500/20 cursor-pointer"
            >
              <span>เสร็จสิ้น / รับบิลใหม่</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
