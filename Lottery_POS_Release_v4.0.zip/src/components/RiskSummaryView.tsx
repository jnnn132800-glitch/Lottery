import React, { useState, useMemo } from 'react';
import { SummaryRisk, Transaction, ConfigRule } from '../types/lottery';
import {
  calculateProfitSummaryMetrics,
  calculateUnifiedAccountingSummary,
  findConfigRule,
  getPermutations,
} from '../utils/lotteryLogic';
import {
  TrendingUp,
  Download,
  AlertOctagon,
  Coins,
  Sparkles,
  Calculator,
  ArrowUpRight,
  ArrowDownRight,
  Send,
  Copy,
  Check,
  FileText,
  Wallet,
  Scale,
  Layers,
  Flame,
  ShieldCheck,
} from 'lucide-react';

interface RiskSummaryViewProps {
  summaryRisks: SummaryRisk[];
  transactions: Transaction[];
  configs: ConfigRule[];
  onExportCSV: () => void;
}

type PayoutCalculationBasis = 'combinedMax' | 'sumAll' | 'expected';

export const RiskSummaryView: React.FC<RiskSummaryViewProps> = ({
  summaryRisks,
  transactions,
  configs,
  onExportCSV,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'overLimit' | 'lossRisk'>('all');
  const [payoutBasis, setPayoutBasis] = useState<PayoutCalculationBasis>('combinedMax');
  const [simType, setSimType] = useState<string>('2ตัวบน');
  const [simNumber, setSimNumber] = useState<string>('38');
  const [copiedForwardText, setCopiedForwardText] = useState(false);

  // Calculate profit and risk metrics
  const metrics = calculateProfitSummaryMetrics(transactions, summaryRisks);

  // Selected Payout Basis values for the Estimated Profit Equation Panel
  const activeEquation = useMemo(() => {
    if (payoutBasis === 'sumAll') {
      return {
        title: 'หักผลรวมภาระจ่ายรางวัลทุกเลขรวมกัน (Sum of All Payouts)',
        subtitle:
          'คำนวณจากยอดคงเหลือถือเองรวม (Keep Amount) หักด้วยผลรวม (Keep × อัตราจ่าย) ของทุกหมายเลขในกระดานรวมกัน',
        payoutSum: metrics.totalAllPayoutExposure,
        estimatedProfit: metrics.estimatedProfitVsAllExposure,
      };
    }
    if (payoutBasis === 'expected') {
      return {
        title: 'หักค่าคาดหมายการจ่ายรางวัลตามสถิติ (Expected Payout EV)',
        subtitle:
          'คำนวณจากยอดคงเหลือถือเองรวม (Keep Amount) หักด้วยค่าเฉลี่ยถ่วงน้ำหนักการจ่ายรางวัลตามความน่าจะเป็นของแต่ละหมวด',
        payoutSum: Math.round(metrics.totalEstimatedPayoutExpected),
        estimatedProfit: Math.round(metrics.expectedProfitAverage),
      };
    }
    return {
      title: 'หักผลรวมจ่ายรางวัลสูงสุดของแต่ละหมวด (Worst-Case per Draw)',
      subtitle:
        'คำนวณจากยอดคงเหลือถือเองรวม (Keep Amount) หักด้วยผลรวมการจ่ายรางวัลกรณีเลขที่จ่ายหนักที่สุดของแต่ละหมวดออกพร้อมกันในงวดนี้',
      payoutSum: metrics.combinedMaxCategoryPayout,
      estimatedProfit: metrics.estimatedProfitVsCombinedMax,
    };
  }, [payoutBasis, metrics]);

  // Upstream Forwarding Items (รายการตีเกินที่ต้องส่งต่อเจ้ามือใหญ่)
  const forwardingItems = useMemo(() => {
    return summaryRisks.filter((r) => r.sentAmount > 0 || r.overLimitAmount > 0);
  }, [summaryRisks]);

  const forwardingText = useMemo(() => {
    if (forwardingItems.length === 0) return '';
    const grouped: Record<string, SummaryRisk[]> = {};
    forwardingItems.forEach((item) => {
      if (!grouped[item.type]) grouped[item.type] = [];
      grouped[item.type].push(item);
    });

    const lines: string[] = [
      `📤 === ใบสรุปโพยตีเกิน (ส่งต่อเจ้ามือใหญ่) ===`,
    ];
    let grandTotal = 0;

    Object.keys(grouped).forEach((type) => {
      lines.push(`\n📌 [${type}]`);
      grouped[type].forEach((it) => {
        const amt = it.sentAmount > 0 ? it.sentAmount : it.overLimitAmount;
        grandTotal += amt;
        lines.push(`${it.number} = ${amt.toLocaleString()} บ.`);
      });
    });

    lines.push(`\n============================`);
    lines.push(`💰 รวมยอดส่งต่อทั้งสิ้น: ฿${grandTotal.toLocaleString()} บาท`);
    lines.push(`📋 จำนวนรายการส่งต่อ: ${forwardingItems.length} หาง`);
    return lines.join('\n');
  }, [forwardingItems]);

  const handleCopyForwardingText = () => {
    if (!forwardingText) return;
    navigator.clipboard.writeText(forwardingText);
    setCopiedForwardText(true);
    setTimeout(() => setCopiedForwardText(false), 2500);
  };

  const handleExportForwardingCSV = () => {
    if (!forwardingItems.length) return;
    const headers = ['Type', 'Number', 'Forward_Amount', 'Total_Received', 'Keep_Amount'];
    const rows = forwardingItems.map((it) => [
      it.type,
      `'${it.number}`,
      it.sentAmount > 0 ? it.sentAmount : it.overLimitAmount,
      it.totalAmount,
      it.keepAmount,
    ]);
    const csvContent =
      '\uFEFF' +
      headers.join(',') +
      '\n' +
      rows.map((r) => r.map((v) => `"${v}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Forwarding_Upstream_Sheet.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Filter list
  const filteredList = summaryRisks.filter((item) => {
    if (filterMode === 'overLimit') return item.overLimitAmount > 0;
    if (filterMode === 'lossRisk') return item.estimatedProfitIfDrawn < 0;
    return true;
  });

  // Table footer sums for filteredList
  const filteredTotals = useMemo(() => {
    const sumTotalAmount = filteredList.reduce((s, it) => s + it.totalAmount, 0);
    const sumKeepAmount = filteredList.reduce((s, it) => s + it.keepAmount, 0);
    const sumSentAmount = filteredList.reduce((s, it) => s + it.sentAmount, 0);
    const sumPotentialPayout = filteredList.reduce((s, it) => s + it.potentialPayout, 0);
    const netKeepMinusSumPayout = sumKeepAmount - sumPotentialPayout;
    return {
      sumTotalAmount,
      sumKeepAmount,
      sumSentAmount,
      sumPotentialPayout,
      netKeepMinusSumPayout,
    };
  }, [filteredList]);

  // Unified Accounting Summary & Top 5 High-Exposure Leaderboard (หมวด 11: Dashboard & Reporting)
  const unifiedAccounting = useMemo(
    () => calculateUnifiedAccountingSummary(transactions),
    [transactions]
  );

  const topExposureItems = useMemo(() => {
    return [...summaryRisks]
      .filter((r) => r.status !== 'ปิดรับ' || r.keepAmount > 0)
      .sort((a, b) => b.potentialPayout - a.potentialPayout || b.totalAmount - a.totalAmount)
      .slice(0, 5);
  }, [summaryRisks]);

  // What-If Simulation calculation (Supports Historical Payout Rate & 3ตัวโต๊ด Permutations)
  const simRule = findConfigRule(simType, simNumber, configs);
  const simPerms = useMemo(() => {
    if (simType === '3ตัวโต๊ด' && simNumber.length === 3) {
      return new Set(getPermutations(simNumber));
    }
    return new Set([simNumber]);
  }, [simType, simNumber]);

  const matchedItems = useMemo(
    () =>
      summaryRisks.filter(
        (r) => r.type === simType && simPerms.has(r.number) && (r.status !== 'ปิดรับ' || r.keepAmount > 0)
      ),
    [summaryRisks, simType, simPerms]
  );

  const simCategoryRevenue = transactions
    .filter((t) => t.type === simType && t.status !== 'ปิดรับ')
    .reduce((s, t) => s + (Number(t.keepAmount) || 0), 0);
  const simHoldAmount = matchedItems.reduce((s, r) => s + r.keepAmount, 0);
  const simPayoutRate = matchedItems.length > 0 ? matchedItems[0].payoutRate : simRule.payoutRate;
  const simTotalPayout =
    matchedItems.length > 0
      ? matchedItems.reduce((s, r) => s + r.potentialPayout, 0)
      : simHoldAmount * simPayoutRate;
  const simNetProfitCategory = simCategoryRevenue - simTotalPayout;
  const simNetProfitWholeDraw = metrics.totalKeepHeld - simTotalPayout;

  return (
    <div className="space-y-5 pb-12">
      {/* 1. ESTIMATED PROFIT & DRAW FINANCIAL STATUS OVERVIEW (ส่วนแสดงผลประมาณการกำไรและภาพรวมสถานะการเงินประจำงวด) */}
      <div className="bg-gradient-to-br from-slate-900 via-emerald-950/25 to-slate-900 border border-emerald-500/40 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3.5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/20 shrink-0">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-base sm:text-lg text-white">
                  ประมาณการกำไร & ภาพรวมสถานะการเงินประจำงวด (Estimated Profit)
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold">
                  Keep Amount − Payout
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {activeEquation.subtitle}
              </p>
            </div>
          </div>

          {/* Payout Basis Mode Switcher */}
          <div className="flex flex-wrap items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs self-start lg:self-auto">
            <button
              type="button"
              onClick={() => setPayoutBasis('combinedMax')}
              className={`px-2.5 py-1.5 rounded-lg font-semibold cursor-pointer transition-all ${
                payoutBasis === 'combinedMax'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              หักจ่ายสูงสุดรายหมวด
            </button>
            <button
              type="button"
              onClick={() => setPayoutBasis('sumAll')}
              className={`px-2.5 py-1.5 rounded-lg font-semibold cursor-pointer transition-all ${
                payoutBasis === 'sumAll'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              หักผลรวมจ่ายทุกเลข
            </button>
            <button
              type="button"
              onClick={() => setPayoutBasis('expected')}
              className={`px-2.5 py-1.5 rounded-lg font-semibold cursor-pointer transition-all ${
                payoutBasis === 'expected'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              หักค่าคาดหมาย (EV)
            </button>
          </div>
        </div>

        {/* Visual Formula Equation Bar: Keep Amount - Total Payout = Estimated Profit */}
        <div className="grid grid-cols-1 md:grid-cols-11 gap-3 items-center">
          {/* Box 1: Keep Amount */}
          <div className="md:col-span-3 bg-slate-950/90 border border-sky-500/40 rounded-2xl p-3.5">
            <div className="flex items-center justify-between text-xs text-sky-300 mb-1">
              <span className="font-semibold">1. ยอดคงเหลือถือเอง (Keep Amount)</span>
              <Coins className="w-4 h-4 text-sky-400" />
            </div>
            <div className="text-2xl font-extrabold font-mono text-white">
              ฿{metrics.totalKeepHeld.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              จากยอดรับรวม ฿{metrics.totalGrossSales.toLocaleString()} (ตีเกินส่งต่อ ฿{metrics.totalSentOut.toLocaleString()})
            </div>
          </div>

          {/* Minus Symbol */}
          <div className="md:col-span-1 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-lg font-black text-slate-300">
              −
            </div>
          </div>

          {/* Box 2: Total Payout according to configured rates */}
          <div className="md:col-span-3 bg-slate-950/90 border border-rose-500/40 rounded-2xl p-3.5">
            <div className="flex items-center justify-between text-xs text-rose-300 mb-1">
              <span className="font-semibold">2. ผลรวมการจ่ายรางวัลตามเรท</span>
              <Scale className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-2xl font-extrabold font-mono text-rose-400">
              ฿{activeEquation.payoutSum.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-1 truncate">
              {activeEquation.title}
            </div>
          </div>

          {/* Equals Symbol */}
          <div className="md:col-span-1 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-lg font-black text-emerald-400">
              =
            </div>
          </div>

          {/* Box 3: Estimated Profit Result */}
          <div
            className={`md:col-span-3 rounded-2xl p-3.5 border-2 ${
              activeEquation.estimatedProfit >= 0
                ? 'bg-emerald-950/50 border-emerald-500/60'
                : 'bg-rose-950/50 border-rose-500/60'
            }`}
          >
            <div className="flex items-center justify-between text-xs font-bold mb-1">
              <span
                className={
                  activeEquation.estimatedProfit >= 0 ? 'text-emerald-300' : 'text-rose-300'
                }
              >
                3. ประมาณการกำไร (Estimated Profit)
              </span>
              <TrendingUp
                className={`w-4 h-4 ${
                  activeEquation.estimatedProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              />
            </div>
            <div
              className={`text-2xl font-extrabold font-mono ${
                activeEquation.estimatedProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {activeEquation.estimatedProfit >= 0 ? '+' : ''}฿
              {activeEquation.estimatedProfit.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-300 mt-1">
              {activeEquation.estimatedProfit >= 0
                ? 'สถานะการเงินเป็นบวก (กำไรสุทธิ)'
                : 'ภาระความเสี่ยงจ่ายรางวัลสูงกว่ายอดถือเอง'}
            </div>
          </div>
        </div>

        {/* Category-by-Category Estimated Profit Breakdown Table */}
        {metrics.categoryBreakdowns.length > 0 && (
          <div className="pt-2">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>ตารางวิเคราะห์ประมาณการกำไรแยกตามประเภทหวย (Category Profit Breakdown)</span>
              </h4>
              <span className="text-[11px] text-slate-400">
                เปรียบเทียบยอดคงเหลือถือเอง (Keep) หักด้วยยอดจ่ายรางวัลตามเรทของแต่ละหมวด
              </span>
            </div>

            <div className="bg-slate-950/90 rounded-xl border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[11px]">
                    <tr>
                      <th className="py-2.5 px-3">ประเภทหวย</th>
                      <th className="py-2.5 px-3 text-center">จำนวนเลข</th>
                      <th className="py-2.5 px-3 text-right text-sky-300">
                        ยอดถือเอง (Keep Amount)
                      </th>
                      <th className="py-2.5 px-3 text-right text-amber-300">
                        จ่ายสูงสุดในหมวด (เลขที่หนักสุด)
                      </th>
                      <th className="py-2.5 px-3 text-right text-emerald-300">
                        ประมาณการกำไร (หักเลขหนักสุด)
                      </th>
                      <th className="py-2.5 px-3 text-right text-rose-300">
                        ผลรวมภาระจ่ายทุกเลขในหมวด
                      </th>
                      <th className="py-2.5 px-3 text-right">
                        ประมาณการกำไร (หักรวมทุกเลข)
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {metrics.categoryBreakdowns.map((cat) => (
                      <tr key={cat.type} className="hover:bg-slate-900/60">
                        <td className="py-2.5 px-3 font-bold text-slate-200">{cat.type}</td>
                        <td className="py-2.5 px-3 text-center font-mono text-slate-400">
                          {cat.numbersCount} เลข
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-sky-400">
                          ฿{cat.keepAmount.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-amber-300">
                          ฿{cat.maxPayoutInCategory.toLocaleString()}{' '}
                          <span className="text-[10px] text-slate-400">
                            (เลข {cat.maxPayoutNumber} ×{cat.maxPayoutRate})
                          </span>
                        </td>
                        <td
                          className={`py-2.5 px-3 text-right font-mono font-bold ${
                            cat.estimatedProfitVsMaxPayout >= 0
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {cat.estimatedProfitVsMaxPayout >= 0 ? '+' : ''}฿
                          {cat.estimatedProfitVsMaxPayout.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-rose-400">
                          ฿{cat.sumAllPayoutsInCategory.toLocaleString()}
                        </td>
                        <td
                          className={`py-2.5 px-3 text-right font-mono font-bold ${
                            cat.estimatedProfitVsSumAll >= 0
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {cat.estimatedProfitVsSumAll >= 0 ? '+' : ''}฿
                          {cat.estimatedProfitVsSumAll.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-slate-900/95 border-t-2 border-slate-700 font-bold text-xs">
                    <tr>
                      <td className="py-2.5 px-3 text-white">รวมทั้งงวดทุกประเภท</td>
                      <td className="py-2.5 px-3 text-center font-mono text-slate-300">
                        {summaryRisks.length} รายการ
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-sky-400 text-sm">
                        ฿{metrics.totalKeepHeld.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-amber-400 text-sm">
                        -฿{metrics.combinedMaxCategoryPayout.toLocaleString()}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-mono text-sm ${
                          metrics.estimatedProfitVsCombinedMax >= 0
                            ? 'text-emerald-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {metrics.estimatedProfitVsCombinedMax >= 0 ? '+' : ''}฿
                        {metrics.estimatedProfitVsCombinedMax.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-rose-400 text-sm">
                        -฿{metrics.totalAllPayoutExposure.toLocaleString()}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-mono text-sm ${
                          metrics.estimatedProfitVsAllExposure >= 0
                            ? 'text-emerald-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {metrics.estimatedProfitVsAllExposure >= 0 ? '+' : ''}฿
                        {metrics.estimatedProfitVsAllExposure.toLocaleString()}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 2. 4 KPI Cards: Revenue, Expected Profit, Worst-Case Risk, Max Profit */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/60 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs text-slate-400 block mb-1">ยอดรับถือเองทั้งหมด (Keep Amount)</span>
            <div className="text-2xl font-bold font-mono text-slate-100">
              ฿{metrics.totalKeepHeld.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              ยอดรับรวมทั้งหมด: ฿{metrics.totalGrossSales.toLocaleString()}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-700/50 text-sky-400">
            <Coins className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-emerald-950/40 p-4 rounded-2xl border border-emerald-800/50 flex items-center justify-between shadow-sm">
          <div>
            <div className="flex items-center gap-1.5 mb-1">
              <span className="text-xs text-emerald-300 font-medium">ประมาณการกำไรคาดหมาย (EV)</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                สถิติ
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-emerald-400 flex items-baseline gap-1">
              <span>
                {metrics.expectedProfitAverage >= 0 ? '+' : ''}฿
                {Math.round(metrics.expectedProfitAverage).toLocaleString()}
              </span>
            </div>
            <span className="text-[11px] text-emerald-300/80 mt-1 block">
              อัตรากำไรคาดหมาย: ~{metrics.expectedProfitRate.toFixed(1)}% หลังหักจ่าย
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-rose-950/40 p-4 rounded-2xl border border-rose-800/50 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs text-rose-300 block mb-1">
              กรณีเลขจ่ายสูงสุดออก ({metrics.worstCaseType} : {metrics.worstCaseNumber})
            </span>
            <div className="text-2xl font-bold font-mono text-rose-400">
              -฿{metrics.worstCasePayout.toLocaleString()}
            </div>
            <span className="text-[11px] text-rose-300/80 mt-1 block">
              กำไรสุทธิทั้งงวด (Keep − จ่าย):{' '}
              <strong
                className={
                  metrics.worstCaseNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }
              >
                {metrics.worstCaseNetProfit >= 0 ? '+' : ''}฿
                {metrics.worstCaseNetProfit.toLocaleString()}
              </strong>
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-rose-500/20 text-rose-400">
            <AlertOctagon className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-amber-950/40 p-4 rounded-2xl border border-amber-800/50 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs text-amber-300 block mb-1">ยอดตีเกินส่งต่อ (ลดความเสี่ยง)</span>
            <div className="text-2xl font-bold font-mono text-amber-400">
              ฿{metrics.totalSentOut.toLocaleString()}
            </div>
            <span className="text-[11px] text-amber-300/80 mt-1 block">
              กำไรสูงสุดกรณีไม่ถูกรางวัล: ฿{metrics.bestCaseProfit.toLocaleString()}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* 2.5 TOP 5 HIGH-EXPOSURE NUMBERS & UNIFIED RECONCILIATION BAR (หมวด 11: Dashboard & Reporting) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Top 5 High-Exposure Numbers Leaderboard */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <h4 className="font-bold text-xs sm:text-sm text-white">
                5 อันดับเลขภาระจ่ายรางวัลสูงสุด (Top Risk Exposure)
              </h4>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">
              เรียงตามยอดจ่ายหากถูกรางวัล
            </span>
          </div>

          {topExposureItems.length === 0 ? (
            <div className="py-4 text-center text-xs text-slate-500">
              ยังไม่มีรายการเดิมพันในงวดนี้
            </div>
          ) : (
            <div className="space-y-2">
              {topExposureItems.map((item, idx) => {
                const limitPct =
                  item.maxRiskLimit > 0
                    ? Math.min(100, Math.round((item.keepAmount / item.maxRiskLimit) * 100))
                    : 100;
                return (
                  <div
                    key={`${item.type}_${item.number}`}
                    className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/90 flex flex-col gap-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 font-mono text-[10px] font-bold flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <span className="text-slate-300 font-semibold">{item.type}</span>
                        <span className="font-mono font-extrabold text-sm text-amber-400">
                          {item.number}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 font-mono">
                          เรท ×{item.payoutRate}
                        </span>
                      </div>
                      <div className="text-right font-mono">
                        <span className="text-rose-400 font-bold">
                          จ่าย ฿{item.potentialPayout.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            limitPct >= 100
                              ? 'bg-rose-500'
                              : limitPct >= 75
                              ? 'bg-amber-500'
                              : 'bg-emerald-500'
                          }`}
                          style={{ width: `${limitPct}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 shrink-0">
                        ถือ ฿{item.keepAmount.toLocaleString()} / เพดาน ฿{item.maxRiskLimit.toLocaleString()} ({limitPct}%)
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Unified POS ↔ Risk ↔ Accounting Reconciliation Card */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h4 className="font-bold text-xs sm:text-sm text-white">
                  ความสัมพันธ์ยอด POS ↔ ความเสี่ยง ↔ บัญชี
                </h4>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                ตรงกัน 100%
              </span>
            </div>

            <div className="space-y-2 mt-3 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span className="text-slate-400">จำนวนบิล / รายการที่รับจริง:</span>
                <span className="font-mono font-bold text-slate-200">
                  {unifiedAccounting.billsCount} บิล ({unifiedAccounting.activeTransactionsCount} รายการ)
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span className="text-slate-400">ยอดหน้าโพยรวม (Gross Sales):</span>
                <span className="font-mono font-bold text-slate-100">
                  ฿{unifiedAccounting.totalGrossSales.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span className="text-indigo-300">หักส่วนลดค่าโพยรวม (Discount):</span>
                <span className="font-mono font-bold text-indigo-400">
                  -฿{unifiedAccounting.totalDiscountGiven.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span className="text-emerald-300 font-semibold">ยอดรับสุทธิหลังหักส่วนลด (Net Sales):</span>
                <span className="font-mono font-bold text-emerald-400">
                  ฿{unifiedAccounting.totalNetSales.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-sky-300">ถือสู้เอง (Keep) + ตีออก (Sent):</span>
                <span className="font-mono font-bold text-sky-400">
                  ฿{unifiedAccounting.totalKeepAmount.toLocaleString()} + ฿{unifiedAccounting.totalSentAmount.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-[11px] text-emerald-300 flex items-center justify-between">
            <span>ตรวจสอบดุลบัญชี (Keep + Sent = Gross):</span>
            <span className="font-mono font-bold">
              ฿{(unifiedAccounting.totalKeepAmount + unifiedAccounting.totalSentAmount).toLocaleString()} = ฿{unifiedAccounting.totalGrossSales.toLocaleString()} ✓
            </span>
          </div>
        </div>
      </div>

      {/* 3. Upstream Risk Forwarding Sheet */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950/20 to-slate-900 border border-amber-500/40 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm sm:text-base text-slate-100 flex items-center gap-2">
                <span>ใบสรุปโพยตีเกินเพื่อส่งต่อเจ้ามือใหญ่ (Upstream Forwarding Sheet)</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                  {forwardingItems.length} รายการ
                </span>
              </h4>
              <p className="text-xs text-slate-400">
                รวมยอดเลขที่รับเกินเพดานความเสี่ยง (Max Risk) พร้อมกดคัดลอกข้อความส่งเข้า LINE เจ้ามือใหญ่ได้ในคลิกเดียว
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportForwardingCSV}
              disabled={forwardingItems.length === 0}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-sky-400" />
              <span>Export ใบส่งต่อ CSV</span>
            </button>

            <button
              type="button"
              onClick={handleCopyForwardingText}
              disabled={forwardingItems.length === 0}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 disabled:opacity-40 cursor-pointer transition-all"
            >
              {copiedForwardText ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>คัดลอกโพยส่ง LINE แล้ว!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>คัดลอกโพยส่งต่อ (LINE)</span>
                </>
              )}
            </button>
          </div>
        </div>

        {forwardingItems.length === 0 ? (
          <div className="py-6 text-center text-slate-400 text-xs">
            ยังไม่มีรายการที่ยอดเกินเพดานความเสี่ยง (ยอดทั้งหมดยังอยู่ในเกณฑ์ถือสู้เองได้)
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mt-3 items-start">
            <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {forwardingItems.map((it, idx) => {
                const fwdAmt = it.sentAmount > 0 ? it.sentAmount : it.overLimitAmount;
                return (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-950/90 border border-amber-500/30 flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-slate-300">{it.type}</span>
                        <span className="font-mono font-extrabold text-base text-amber-400">
                          {it.number}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        รับรวม ฿{it.totalAmount.toLocaleString()} (ถือเอง ฿{it.keepAmount.toLocaleString()})
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-rose-300 block">ยอดส่งต่อ</span>
                      <span className="font-mono font-bold text-sm text-rose-400">
                        ฿{fwdAmt.toLocaleString()}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="md:col-span-5 bg-slate-950 rounded-xl p-3 border border-slate-800">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                <span>ตัวอย่างข้อความพร้อมส่ง LINE:</span>
                <span className="text-amber-400 font-mono">
                  รวม ฿{metrics.totalSentOut.toLocaleString()}
                </span>
              </div>
              <pre className="text-xs font-mono text-emerald-300 whitespace-pre-wrap bg-slate-900/90 p-2.5 rounded-lg border border-slate-800 max-h-40 overflow-y-auto">
                {forwardingText}
              </pre>
            </div>
          </div>
        )}
      </div>

      {/* 4. Interactive What-If Winning Simulator */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm sm:text-base text-slate-100 flex items-center gap-2">
                <span>จำลองคำนวณกำไร/ขาดทุนสุทธิรายเลข (Profit Simulator)</span>
              </h4>
              <p className="text-xs text-slate-400">
                เลือกหรือพิมพ์เลขจำลอง เพื่อดูยอดคงเหลือถือเอง (Keep Amount) หักการจ่ายเงินรางวัลตามเรท
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 hidden sm:inline">ทดสอบเลขในบิล:</span>
            <div className="flex gap-1 overflow-x-auto">
              {summaryRisks.slice(0, 4).map((r) => (
                <button
                  key={`${r.type}_${r.number}`}
                  type="button"
                  onClick={() => {
                    setSimType(r.type);
                    setSimNumber(r.number);
                  }}
                  className={`px-2 py-1 rounded-lg font-mono text-xs cursor-pointer transition-colors ${
                    simType === r.type && simNumber === r.number
                      ? 'bg-sky-500 text-slate-950 font-bold'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                  }`}
                >
                  {r.number} ({r.type})
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mt-4 items-center">
          <div className="md:col-span-5 grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">ประเภทหวย</label>
              <select
                value={simType}
                onChange={(e) => setSimType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-sky-500"
              >
                <option value="2ตัวบน">2ตัวบน</option>
                <option value="2ตัวล่าง">2ตัวล่าง</option>
                <option value="3ตัวตรง">3ตัวตรง</option>
                <option value="3ตัวโต๊ด">3ตัวโต๊ด</option>
                <option value="วิ่งบน">วิ่งบน</option>
                <option value="วิ่งล่าง">วิ่งล่าง</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">สมมติเลขที่ออกรางวัล</label>
              <input
                type="text"
                value={simNumber}
                onChange={(e) => setSimNumber(e.target.value.trim())}
                placeholder="เช่น 38, 83"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-amber-400 font-mono font-bold text-sm sm:text-base focus:outline-none focus:border-sky-500"
              />
            </div>
          </div>

          <div className="md:col-span-7 bg-slate-950/80 rounded-xl p-3 border border-slate-800 flex flex-col justify-between">
            <div className="grid grid-cols-3 gap-2 text-center text-xs pb-2 border-b border-slate-800/80">
              <div>
                <span className="text-[10px] text-slate-400 block">ยอดถือรวมทั้งงวด</span>
                <span className="font-mono font-bold text-sky-400">
                  ฿{metrics.totalKeepHeld.toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">
                  ถือเลข {simNumber || '-'} (เรท x{simPayoutRate})
                </span>
                <span className="font-mono font-bold text-amber-400">
                  ฿{simHoldAmount.toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-rose-400 block">หัก จ่ายรางวัลตามเรท</span>
                <span className="font-mono font-bold text-rose-400">
                  -฿{simTotalPayout.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs text-slate-300">
                <span>ประมาณการกำไรรวมทั้งงวด (Total Keep − จ่ายรางวัล):</span>
                <div className="text-[11px] text-slate-500">
                  (เฉพาะหมวด {simType}: {simNetProfitCategory >= 0 ? '+' : ''}฿{simNetProfitCategory.toLocaleString()})
                </div>
              </div>

              <div className="text-right">
                <span
                  className={`text-lg sm:text-xl font-bold font-mono flex items-center gap-1 justify-end ${
                    simNetProfitWholeDraw >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {simNetProfitWholeDraw >= 0 ? (
                    <ArrowUpRight className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <ArrowDownRight className="w-5 h-5 text-rose-400" />
                  )}
                  <span>
                    {simNetProfitWholeDraw >= 0 ? '+' : ''}฿{simNetProfitWholeDraw.toLocaleString()}
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Filter and Control Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 bg-slate-800/80 p-1 rounded-xl border border-slate-700 text-xs">
          <button
            type="button"
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
              filterMode === 'all'
                ? 'bg-slate-700 text-white font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ทั้งหมด ({summaryRisks.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('lossRisk')}
            className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
              filterMode === 'lossRisk'
                ? 'bg-rose-900/60 text-rose-300 font-bold border border-rose-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            เฉพาะเลขที่เสี่ยงจ่ายสูง/ติดลบ ({summaryRisks.filter((r) => r.estimatedProfitIfDrawn < 0).length})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('overLimit')}
            className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
              filterMode === 'overLimit'
                ? 'bg-amber-900/60 text-amber-300 font-bold border border-amber-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            เฉพาะเลขตีเกิน ({summaryRisks.filter((r) => r.overLimitAmount > 0).length})
          </button>
        </div>

        <button
          type="button"
          onClick={onExportCSV}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-medium text-slate-200 flex items-center gap-1.5 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span>ส่งออก Summary_Risk.csv</span>
        </button>
      </div>

      {/* 6. Summary Risk & Profit Table */}
      <div className="bg-slate-800/80 rounded-2xl border border-slate-700/60 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-700/80 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3 text-center">Number</th>
                <th className="py-3 px-3 text-right">ยอดแทงรวม</th>
                <th className="py-3 px-3 text-right text-sky-300">ยอดถือเอง (Keep)</th>
                <th className="py-3 px-3 text-right">อัตราจ่าย</th>
                <th className="py-3 px-3 text-right text-rose-300">จ่ายรางวัลตามเรท</th>
                <th className="py-3 px-3 text-right text-emerald-300">
                  ประมาณการกำไร (หักจ่ายรางวัล)
                </th>
                <th className="py-3 px-3 text-center">สถานะ / ตีเกิน</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/40">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    ไม่พบรายการตามเงื่อนไขที่เลือก
                  </td>
                </tr>
              ) : (
                filteredList.map((item, idx) => {
                  const wholeDrawEstProfit = metrics.totalKeepHeld - item.potentialPayout;
                  const isNegativeProfit = wholeDrawEstProfit < 0;
                  const isOver = item.overLimitAmount > 0;

                  return (
                    <tr
                      key={idx}
                      className={
                        isNegativeProfit
                          ? 'bg-rose-950/15 hover:bg-rose-950/30'
                          : 'hover:bg-slate-750/50'
                      }
                    >
                      <td className="py-3 px-3 text-slate-200 font-medium">{item.type}</td>
                      <td className="py-3 px-3 text-center font-mono font-bold text-amber-400 text-base">
                        {item.number}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-slate-300">
                        ฿{item.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-sky-400">
                        ฿{item.keepAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-slate-300">
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-200">
                          {item.payoutRate} บ.
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-rose-400">
                        {item.potentialPayout > 0
                          ? `-฿${item.potentialPayout.toLocaleString()}`
                          : '฿0'}
                      </td>
                      <td className="py-3 px-3 text-right font-mono">
                        <div className="flex flex-col items-end">
                          <span
                            className={`inline-flex items-center gap-1 font-bold ${
                              wholeDrawEstProfit < 0 ? 'text-rose-400' : 'text-emerald-400'
                            }`}
                          >
                            {wholeDrawEstProfit < 0 ? (
                              <ArrowDownRight className="w-3.5 h-3.5 text-rose-400" />
                            ) : (
                              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                            )}
                            <span>
                              {wholeDrawEstProfit >= 0 ? '+' : ''}฿
                              {wholeDrawEstProfit.toLocaleString()}
                            </span>
                          </span>
                          <span className="text-[10px] text-slate-400">
                            (เฉพาะหมวด: {item.estimatedProfitIfDrawn >= 0 ? '+' : ''}฿
                            {item.estimatedProfitIfDrawn.toLocaleString()})
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <div className="flex flex-col items-center gap-0.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              item.status === 'ปกติ'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : item.status === 'อั้นจ่าย'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                            }`}
                          >
                            {item.status}
                          </span>
                          {isOver && (
                            <span className="text-[10px] font-mono text-rose-400">
                              ส่งต่อ ฿{item.overLimitAmount.toLocaleString()}
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {filteredList.length > 0 && (
              <tfoot className="bg-slate-900/95 border-t-2 border-slate-700 font-bold text-xs sm:text-sm">
                <tr>
                  <td colSpan={2} className="py-3 px-3 text-slate-100">
                    รวมทั้งหมด ({filteredList.length} รายการ)
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-200">
                    ฿{filteredTotals.sumTotalAmount.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sky-400">
                    ฿{filteredTotals.sumKeepAmount.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right text-slate-400 text-xs">
                    ตามเรทตั้งค่า
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-rose-400">
                    -฿{filteredTotals.sumPotentialPayout.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    <span
                      className={
                        filteredTotals.netKeepMinusSumPayout >= 0
                          ? 'text-emerald-400'
                          : 'text-rose-400'
                      }
                    >
                      {filteredTotals.netKeepMinusSumPayout >= 0 ? '+' : ''}฿
                      {filteredTotals.netKeepMinusSumPayout.toLocaleString()}
                    </span>
                    <span className="block text-[10px] text-slate-400 font-normal">
                      (Keep รวม − ผลรวมจ่ายทุกเลข)
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center font-mono text-amber-400 text-xs">
                    ส่งต่อ ฿{filteredTotals.sumSentAmount.toLocaleString()}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};
