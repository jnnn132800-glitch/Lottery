import React from 'react';
import { AlertTriangle, Ban, CheckCircle2, Info, X, RotateCcw } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'warning' | 'error' | 'success' | 'info';
  title: string;
  message: string;
  undoAction?: () => void;
  undoLabel?: string;
}

interface ToastNotificationProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastNotification: React.FC<ToastNotificationProps> = ({ toasts, onDismiss }) => {
  if (!toasts.length) return null;

  return (
    <div className="fixed top-14 sm:top-16 right-3 sm:right-6 z-50 flex flex-col gap-2 max-w-sm w-[calc(100vw-24px)] sm:w-96 pointer-events-none">
      {toasts.map((toast) => {
        const isWarning = toast.type === 'warning';
        const isError = toast.type === 'error';
        const isSuccess = toast.type === 'success';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 sm:p-4 rounded-2xl border shadow-2xl backdrop-blur-md transition-all duration-200 animate-in slide-in-from-top-3 fade-in flex items-start justify-between gap-3 ${
              isWarning
                ? 'bg-amber-950/95 border-amber-500/80 text-amber-100 shadow-amber-950/50'
                : isError
                ? 'bg-rose-950/95 border-rose-500/80 text-rose-100 shadow-rose-950/50'
                : isSuccess
                ? 'bg-emerald-950/95 border-emerald-500/80 text-emerald-100 shadow-emerald-950/50'
                : 'bg-slate-900/95 border-slate-700 text-slate-100 shadow-slate-950/50'
            }`}
          >
            {/* Icon */}
            <div className="shrink-0 mt-0.5">
              {isWarning && (
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
                  <AlertTriangle className="w-5 h-5 animate-pulse" />
                </div>
              )}
              {isError && (
                <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40">
                  <Ban className="w-5 h-5" />
                </div>
              )}
              {isSuccess && (
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              )}
              {!isWarning && !isError && !isSuccess && (
                <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/40">
                  <Info className="w-5 h-5" />
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm">
                <span>{toast.title}</span>
              </div>
              <p className="text-xs opacity-90 mt-0.5 leading-relaxed break-words">
                {toast.message}
              </p>

              {/* Undo action button if available */}
              {toast.undoAction && (
                <button
                  type="button"
                  onClick={() => {
                    toast.undoAction?.();
                    onDismiss(toast.id);
                  }}
                  className="mt-2 px-2.5 py-1 bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{toast.undoLabel || 'กู้คืนรายการ'}</span>
                </button>
              )}
            </div>

            {/* Close Button */}
            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              className="shrink-0 p-1 rounded-lg opacity-70 hover:opacity-100 hover:bg-white/10 transition-colors cursor-pointer"
              title="ปิดการแจ้งเตือน"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
