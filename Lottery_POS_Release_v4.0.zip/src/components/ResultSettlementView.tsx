import React, { useState, useMemo } from 'react';
import { Transaction, ConfigRule, SettlementPaymentStatus } from '../types/lottery';
import { getTransactionPayoutRate, getPermutations } from '../utils/lotteryLogic';
import {
  Trophy,
  Sparkles,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  RotateCcw,
  Coins,
  User,
  Receipt,
  TrendingUp,
  TrendingDown,
  Award,
  Search,
  Percent,
  Archive,
} from 'lucide-react';

interface ResultSettlementViewProps {
  transactions: Transaction[];
  configs: ConfigRule[];
  drawPeriod?: string;
  onViewReceipt?: (billId: string) => void;
  onArchiveCurrentDraw?: (top3: string, bottom2: string) => void;
}

export interface WinningResult {
  top3: string;
  bottom2: string;
}

interface EvaluatedTx extends Transaction {
  isWinner: boolean;
  payoutRate: number;
  customerWinAmount: number;
  dealerKeepWinAmount: number;
  forwardedWinAmount: number;
  matchReason: string;
}

export const ResultSettlementView: React.FC<ResultSettlementViewProps> = ({
  transactions,
  configs,
  drawPeriod = 'งวดวันที่ 16 พ.ย. 2569',
  onViewReceipt,
  onArchiveCurrentDraw,
}) => {
  const [top3, setTop3] = useState<string>(() => {
    return localStorage.getItem('lottery_win_top3') || '538';
  });
  const [bottom2, setBottom2] = useState<string>(() => {
    return localStorage.getItem('lottery_win_bottom2') || '73';
  });
  const [filterMode, setFilterMode] = useState<'winners' | 'all'>('winners');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Payment Settlement Status per Bill (Accounting & Cash Flow)
  const [paymentStatusMap, setPaymentStatusMap] = useState<Record<string, SettlementPaymentStatus>>(() => {
    try {
      const saved = localStorage.getItem('lottery_bill_payments');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const getBillPaymentStatus = (billId: string): SettlementPaymentStatus => {
    const key = `${drawPeriod}__${billId}`;
    return paymentStatusMap[key] || 'รอเคลียร์ยอด';
  };

  const handleSetBillPaymentStatus = (billId: string, status: SettlementPaymentStatus) => {
    const key = `${drawPeriod}__${billId}`;
    setPaymentStatusMap((prev) => {
      const next = { ...prev, [key]: status };
      localStorage.setItem('lottery_bill_payments', JSON.stringify(next));
      return next;
    });
  };

  const handleSetCustomerBillsSettled = (custName: string, status: SettlementPaymentStatus) => {
    setPaymentStatusMap((prev) => {
      const next = { ...prev };
      allBillSettlements
        .filter((b) => b.customerName === custName)
        .forEach((b) => {
          next[`${drawPeriod}__${b.billId}`] = status;
        });
      localStorage.setItem('lottery_bill_payments', JSON.stringify(next));
      return next;
    });
  };

  const handleTop3Change = (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 3);
    setTop3(clean);
    localStorage.setItem('lottery_win_top3', clean);
  };

  const handleBottom2Change = (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 2);
    setBottom2(clean);
    localStorage.setItem('lottery_win_bottom2', clean);
  };

  const isResultComplete = top3.length === 3 && bottom2.length === 2;

  // Derived winning numbers
  const derivedWinning = useMemo(() => {
    const top2 = top3.length === 3 ? top3.slice(1, 3) : '';
    const toadPermutations = top3.length === 3 ? getPermutations(top3) : [];
    const runTopDigits = top3.length === 3 ? Array.from(new Set(top3.split(''))) : [];
    const runBottomDigits = bottom2.length === 2 ? Array.from(new Set(bottom2.split(''))) : [];

    return {
      top3,
      top2,
      toadPermutations,
      runTopDigits,
      bottom2,
      runBottomDigits,
    };
  }, [top3, bottom2]);

  // Evaluate every transaction using historical payoutRate at time of sale and excluding 'ปิดรับ'
  const evaluatedTransactions = useMemo<EvaluatedTx[]>(() => {
    return transactions.map((tx) => {
      const isClosedOrInvalid = tx.status === 'ปิดรับ' || (Number(tx.amount) || 0) <= 0;
      const rate = isClosedOrInvalid ? 0 : getTransactionPayoutRate(tx, configs);
      let isWinner = false;
      let matchReason = '';

      if (isResultComplete && !isClosedOrInvalid) {
        if (tx.type === '3ตัวตรง' && tx.number === derivedWinning.top3) {
          isWinner = true;
          matchReason = `ถูก 3 ตัวตรง (${derivedWinning.top3})`;
        } else if (
          tx.type === '3ตัวโต๊ด' &&
          derivedWinning.toadPermutations.includes(tx.number)
        ) {
          isWinner = true;
          matchReason = `ถูก 3 ตัวโต๊ด (จาก ${derivedWinning.top3})`;
        } else if (tx.type === '2ตัวบน' && tx.number === derivedWinning.top2) {
          isWinner = true;
          matchReason = `ถูก 2 ตัวบน (${derivedWinning.top2})`;
        } else if (tx.type === '2ตัวล่าง' && tx.number === derivedWinning.bottom2) {
          isWinner = true;
          matchReason = `ถูก 2 ตัวล่าง (${derivedWinning.bottom2})`;
        } else if (
          tx.type === 'วิ่งบน' &&
          tx.number.length === 1 &&
          derivedWinning.runTopDigits.includes(tx.number)
        ) {
          isWinner = true;
          matchReason = `ถูกวิ่งบน (${tx.number} ใน ${derivedWinning.top3})`;
        } else if (
          tx.type === 'วิ่งล่าง' &&
          tx.number.length === 1 &&
          derivedWinning.runBottomDigits.includes(tx.number)
        ) {
          isWinner = true;
          matchReason = `ถูกวิ่งล่าง (${tx.number} ใน ${derivedWinning.bottom2})`;
        }
      }

      const activeAmt = isClosedOrInvalid ? 0 : Math.max(0, Number(tx.amount) || 0);
      const activeKeep = isClosedOrInvalid ? 0 : Math.max(0, Number(tx.keepAmount) || 0);
      const activeSent = isClosedOrInvalid ? 0 : Math.max(0, Number(tx.sentAmount) || 0);

      const customerWinAmount = isWinner ? activeAmt * rate : 0;
      const dealerKeepWinAmount = isWinner ? activeKeep * rate : 0;
      const forwardedWinAmount = isWinner ? activeSent * rate : 0;

      return {
        ...tx,
        isWinner,
        payoutRate: rate,
        customerWinAmount,
        dealerKeepWinAmount,
        forwardedWinAmount,
        matchReason,
      };
    });
  }, [transactions, configs, isResultComplete, derivedWinning]);

  // Group by Bill for customer settlement (including discount %)
  const allBillSettlements = useMemo(() => {
    const map = new Map<
      string,
      {
        billId: string;
        customerName: string;
        timestamp: string;
        discountPercent: number;
        totalBuy: number;
        discountAmount: number;
        netBuy: number;
        totalWinPayout: number;
        netCustomerBalance: number; // totalWinPayout - netBuy
        winningItems: EvaluatedTx[];
        allItems: EvaluatedTx[];
      }
    >();

    evaluatedTransactions.forEach((tx) => {
      const discPct = tx.discountPercent || 0;
      if (!map.has(tx.billId)) {
        map.set(tx.billId, {
          billId: tx.billId,
          customerName: tx.customerName || 'ลูกค้าทั่วไป',
          timestamp: tx.timestamp,
          discountPercent: discPct,
          totalBuy: 0,
          discountAmount: 0,
          netBuy: 0,
          totalWinPayout: 0,
          netCustomerBalance: 0,
          winningItems: [],
          allItems: [],
        });
      }
      const b = map.get(tx.billId)!;
      const validBuyAmount = tx.status === 'ปิดรับ' ? 0 : tx.amount;
      b.totalBuy += validBuyAmount;
      b.discountAmount = Math.round((b.totalBuy * b.discountPercent) / 100);
      b.netBuy = b.totalBuy - b.discountAmount;
      b.totalWinPayout += tx.customerWinAmount;
      b.netCustomerBalance = b.totalWinPayout - b.netBuy;
      b.allItems.push(tx);
      if (tx.isWinner && tx.status !== 'ปิดรับ') {
        b.winningItems.push(tx);
      }
    });

    return Array.from(map.values());
  }, [evaluatedTransactions]);

  // Filtered Bill Settlements
  const billSettlements = useMemo(() => {
    let list = [...allBillSettlements];

    if (filterMode === 'winners') {
      list = list.filter((b) => b.winningItems.length > 0);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (b) =>
          b.billId.toLowerCase().includes(q) ||
          b.customerName.toLowerCase().includes(q) ||
          b.winningItems.some((w) => w.number.includes(q))
      );
    }

    return list.sort((a, b) => b.totalWinPayout - a.totalWinPayout);
  }, [allBillSettlements, filterMode, searchQuery]);

  // Overall Financial Settlement Summary
  const summary = useMemo(() => {
    const totalGrossSales = evaluatedTransactions.reduce(
      (s, t) => s + (t.status === 'ปิดรับ' ? 0 : t.amount),
      0
    );
    const totalDiscountGiven = allBillSettlements.reduce((s, b) => s + b.discountAmount, 0);
    const totalDealerKeepSales = evaluatedTransactions.reduce(
      (s, t) => s + (t.status === 'ปิดรับ' ? 0 : t.keepAmount),
      0
    );
    const totalSentSales = evaluatedTransactions.reduce(
      (s, t) => s + (t.status === 'ปิดรับ' ? 0 : t.sentAmount),
      0
    );

    const totalCustomerPayout = evaluatedTransactions.reduce(
      (s, t) => s + t.customerWinAmount,
      0
    );
    const totalDealerKeepPayout = evaluatedTransactions.reduce(
      (s, t) => s + t.dealerKeepWinAmount,
      0
    );
    const totalClaimFromUpstream = evaluatedTransactions.reduce(
      (s, t) => s + t.forwardedWinAmount,
      0
    );

    // Net Profit for the Dealer (ยอดถือเองทั้งหมด - ส่วนลดที่จ่ายลูกค้า - ยอดรางวัลของส่วนที่ถือเอง)
    const dealerNetProfit =
      totalDealerKeepSales - totalDiscountGiven - totalDealerKeepPayout;
    const winningItemsCount = evaluatedTransactions.filter((t) => t.isWinner).length;

    return {
      totalGrossSales,
      totalDiscountGiven,
      totalDealerKeepSales,
      totalSentSales,
      totalCustomerPayout,
      totalDealerKeepPayout,
      totalClaimFromUpstream,
      dealerNetProfit,
      winningItemsCount,
    };
  }, [evaluatedTransactions, allBillSettlements]);

  // Customer Accounting & Cash Flow Summary (หมวด 5 & หมวด 6)
  const customerAccountingSummaries = useMemo(() => {
    const map = new Map<
      string,
      {
        customerName: string;
        billsCount: number;
        totalBuy: number;
        discountAmount: number;
        netBuy: number;
        totalWinPayout: number;
        netCustomerBalance: number;
        settledBillsCount: number;
        pendingBillsCount: number;
      }
    >();

    allBillSettlements.forEach((b) => {
      const name = b.customerName || 'ลูกค้าทั่วไป';
      const curr = map.get(name) || {
        customerName: name,
        billsCount: 0,
        totalBuy: 0,
        discountAmount: 0,
        netBuy: 0,
        totalWinPayout: 0,
        netCustomerBalance: 0,
        settledBillsCount: 0,
        pendingBillsCount: 0,
      };
      const st = getBillPaymentStatus(b.billId);
      curr.billsCount += 1;
      curr.totalBuy += b.totalBuy;
      curr.discountAmount += b.discountAmount;
      curr.netBuy += b.netBuy;
      curr.totalWinPayout += b.totalWinPayout;
      curr.netCustomerBalance += b.netCustomerBalance;
      if (st === 'เคลียร์แล้ว') {
        curr.settledBillsCount += 1;
      } else {
        curr.pendingBillsCount += 1;
      }
      map.set(name, curr);
    });

    return Array.from(map.values()).sort((a, b) => b.netBuy - a.netBuy);
  }, [allBillSettlements, paymentStatusMap, drawPeriod]);

  // Copy summary for a customer to send via LINE
  const handleCopyCustomerResult = (bill: (typeof billSettlements)[0]) => {
    const lines = [
      `🏆 แจ้งผลรางวัล บิล: ${bill.billId} (${drawPeriod})`,
      `👤 ลูกค้า: ${bill.customerName}`,
      `🎯 ผลที่ออก: 3 ตัวบน [${top3}] | 2 ตัวล่าง [${bottom2}]`,
      `------------------------`,
    ];

    if (bill.winningItems.length > 0) {
      lines.push(`✅ รายการที่ถูกรางวัล (${bill.winningItems.length} รายการ):`);
      bill.winningItems.forEach((w, idx) => {
        lines.push(
          `${idx + 1}. ${w.type} เลข [${w.number}] ซื้อ ฿${w.amount.toLocaleString()} (x${w.payoutRate}) = ได้รับ ฿${w.customerWinAmount.toLocaleString()}`
        );
      });
    } else {
      lines.push(`❌ ไม่ถูกรางวัลในงวดนี้`);
    }

    lines.push(`------------------------`);
    lines.push(`💰 ยอดซื้อหน้าโพย: ฿${bill.totalBuy.toLocaleString()}`);
    if (bill.discountPercent > 0) {
      lines.push(
        `🏷️ หักส่วนลด (${bill.discountPercent}%): -฿${bill.discountAmount.toLocaleString()} (ยอดค่าโพยสุทธิ ฿${bill.netBuy.toLocaleString()})`
      );
    }
    lines.push(`🎉 ยอดถูกรางวัลรวม: ฿${bill.totalWinPayout.toLocaleString()}`);
    const netText =
      bill.netCustomerBalance >= 0
        ? `🟢 โอนจ่ายลูกค้าสุทธิ (หักค่าโพยแล้ว): +฿${bill.netCustomerBalance.toLocaleString()}`
        : `🔴 ลูกค้าชำระค่าโพยสุทธิ: ฿${Math.abs(bill.netCustomerBalance).toLocaleString()}`;
    lines.push(netText);

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedId(bill.billId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Copy Overall Dealer Summary
  const handleCopyOverallSummary = () => {
    const text = [
      `📊 สรุปปิดงวดหวย (${drawPeriod})`,
      `🎯 ผลรางวัล: 3 ตัวบน [${top3}] | 2 ตัวบน [${derivedWinning.top2}] | 2 ตัวล่าง [${bottom2}]`,
      `============================`,
      `💵 ยอดรับโพยรวมทั้งหมด: ฿${summary.totalGrossSales.toLocaleString()}`,
      ...(summary.totalDiscountGiven > 0
        ? [`🏷️ ส่วนลดค่าโพยรวม: -฿${summary.totalDiscountGiven.toLocaleString()}`]
        : []),
      `🛡️ ยอดถือสู้เอง: ฿${summary.totalDealerKeepSales.toLocaleString()}`,
      `📤 ยอดตีเกินส่งต่อ: ฿${summary.totalSentSales.toLocaleString()}`,
      `----------------------------`,
      `🏆 ยอดถูกรางวัลรวม (${summary.winningItemsCount} รายการ): ฿${summary.totalCustomerPayout.toLocaleString()}`,
      `🔻 เจ้ามือจ่ายเอง (จากยอดถือ): -฿${summary.totalDealerKeepPayout.toLocaleString()}`,
      `🔹 เคลมจากเจ้ามือใหญ่ (จากยอดส่งต่อ): +฿${summary.totalClaimFromUpstream.toLocaleString()}`,
      `============================`,
      `${summary.dealerNetProfit >= 0 ? '✅ กำไรสุทธิเจ้ามือ:' : '⚠️ ขาดทุนสุทธิเจ้ามือ:'} ${summary.dealerNetProfit >= 0 ? '+' : ''}฿${summary.dealerNetProfit.toLocaleString()}`,
    ].join('\n');

    navigator.clipboard.writeText(text);
    setCopiedId('OVERALL');
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-5 pb-12">
      {/* 1. Winning Number Input Card */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950/30 to-slate-900 border border-amber-500/40 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/25 shrink-0">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-bold text-white">
                  ระบบตรวจผลรางวัล & เคลียร์ยอดบัญชี
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                  {drawPeriod}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                กรอกผลรางวัล 3 ตัวบน และ 2 ตัวล่าง ระบบคำนวณรางวัลพร้อมหักส่วนลดค่าโพยรายบิลอัตโนมัติ
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                handleTop3Change('538');
                handleBottom2Change('73');
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>ผลตัวอย่าง (538 / 73)</span>
            </button>
            <button
              type="button"
              onClick={handleCopyOverallSummary}
              disabled={!isResultComplete}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 disabled:opacity-40 cursor-pointer"
            >
              {copiedId === 'OVERALL' ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>คัดลอกสรุปงวดแล้ว!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>คัดลอกสรุปปิดงวด</span>
                </>
              )}
            </button>

            {onArchiveCurrentDraw && transactions.length > 0 && (
              <button
                type="button"
                onClick={() => onArchiveCurrentDraw(top3, bottom2)}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
                title="บันทึกงวดนี้เข้าคลังประวัติ และล้างกระดานเพื่อเริ่มงวดใหม่"
              >
                <Archive className="w-3.5 h-3.5" />
                <span>ปิดงวดนี้ & เริ่มงวดใหม่</span>
              </button>
            )}
          </div>
        </div>

        {/* Inputs and Auto-Derived Prizes */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-4 items-center">
          <div className="lg:col-span-5 grid grid-cols-2 gap-3">
            <div className="bg-slate-950/90 p-3 rounded-xl border border-amber-500/40">
              <label className="text-xs text-amber-300 font-semibold block mb-1">
                รางวัล 3 ตัวบน (3 หลัก)
              </label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={3}
                value={top3}
                onChange={(e) => handleTop3Change(e.target.value)}
                placeholder="เช่น 538"
                className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-lg px-3 py-2 text-2xl font-mono font-extrabold text-amber-400 text-center tracking-widest outline-none"
              />
            </div>

            <div className="bg-slate-950/90 p-3 rounded-xl border border-sky-500/40">
              <label className="text-xs text-sky-300 font-semibold block mb-1">
                รางวัล 2 ตัวล่าง (2 หลัก)
              </label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={2}
                value={bottom2}
                onChange={(e) => handleBottom2Change(e.target.value)}
                placeholder="เช่น 73"
                className="w-full bg-slate-900 border border-slate-700 focus:border-sky-400 rounded-lg px-3 py-2 text-2xl font-mono font-extrabold text-sky-400 text-center tracking-widest outline-none"
              />
            </div>
          </div>

          <div className="lg:col-span-7 bg-slate-950/70 rounded-xl p-3.5 border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">2 ตัวบน (ท้าย 3 ตัว)</span>
              <span className="text-lg font-mono font-bold text-emerald-400">
                {derivedWinning.top2 || '--'}
              </span>
            </div>

            <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">
                3 ตัวโต๊ด ({derivedWinning.toadPermutations.length} หาง)
              </span>
              <span className="text-xs font-mono font-semibold text-amber-300 block mt-1 truncate">
                {derivedWinning.toadPermutations.join(', ') || '---'}
              </span>
            </div>

            <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">วิ่งบน</span>
              <span className="text-sm font-mono font-bold text-indigo-300 block mt-0.5">
                {derivedWinning.runTopDigits.join(', ') || '-'}
              </span>
            </div>

            <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">วิ่งล่าง</span>
              <span className="text-sm font-mono font-bold text-sky-300 block mt-0.5">
                {derivedWinning.runBottomDigits.join(', ') || '-'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block">ยอดถือสู้เอง (หักส่งต่อแล้ว)</span>
            <div className="text-2xl font-bold font-mono text-white mt-0.5">
              ฿{summary.totalDealerKeepSales.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-500 block mt-1">
              รับรวม: ฿{summary.totalGrossSales.toLocaleString()}
              {summary.totalDiscountGiven > 0
                ? ` | ส่วนลด: -฿${summary.totalDiscountGiven.toLocaleString()}`
                : ` | ส่งต่อ: ฿${summary.totalSentSales.toLocaleString()}`}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-800 text-sky-400">
            <Coins className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-rose-950/30 border border-rose-800/50 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-xs text-rose-300 block">
              ยอดจ่ายรางวัลส่วนที่ถือเอง ({summary.winningItemsCount} รายการถูก)
            </span>
            <div className="text-2xl font-bold font-mono text-rose-400 mt-0.5">
              -฿{summary.totalDealerKeepPayout.toLocaleString()}
            </div>
            <span className="text-[11px] text-rose-300/80 block mt-1">
              จ่ายลูกค้ารวมทั้งหมด: ฿{summary.totalCustomerPayout.toLocaleString()}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-rose-500/20 text-rose-400">
            <Award className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-indigo-950/30 border border-indigo-800/50 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-xs text-indigo-300 block">ยอดรับเคลมจากเจ้ามือใหญ่ (ตีเกินถูก)</span>
            <div className="text-2xl font-bold font-mono text-indigo-400 mt-0.5">
              +฿{summary.totalClaimFromUpstream.toLocaleString()}
            </div>
            <span className="text-[11px] text-indigo-300/80 block mt-1">
              ช่วยเซฟเงินเจ้ามือจากเลขที่ส่งต่อ
            </span>
          </div>
          <div className="p-3 rounded-xl bg-indigo-500/20 text-indigo-400">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>

        <div
          className={`p-4 rounded-2xl border flex items-center justify-between ${
            summary.dealerNetProfit >= 0
              ? 'bg-emerald-950/40 border-emerald-700/60'
              : 'bg-rose-950/50 border-rose-700/60'
          }`}
        >
          <div>
            <span className="text-xs font-semibold text-slate-200 block">
              กำไร / ขาดทุนสุทธิเจ้ามือ (Net Profit)
            </span>
            <div
              className={`text-2xl font-extrabold font-mono mt-0.5 ${
                summary.dealerNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {summary.dealerNetProfit >= 0 ? '+' : ''}฿{summary.dealerNetProfit.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-300 block mt-1">
              {summary.dealerNetProfit >= 0
                ? 'หักส่วนลดและรางวัลที่ถูกแล้ว'
                : 'งวดนี้มียอดจ่ายรางวัลสูงกว่ายอดถือ'}
            </span>
          </div>
          <div
            className={`p-3 rounded-xl ${
              summary.dealerNetProfit >= 0
                ? 'bg-emerald-500/20 text-emerald-400'
                : 'bg-rose-500/20 text-rose-400'
            }`}
          >
            {summary.dealerNetProfit >= 0 ? (
              <TrendingUp className="w-6 h-6" />
            ) : (
              <TrendingDown className="w-6 h-6" />
            )}
          </div>
        </div>
      </div>

      {/* 3. Customer Bill Settlement List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
              <Receipt className="w-4 h-4 text-amber-400" />
              <span>รายการเคลียร์บิลลูกค้า ({billSettlements.length} บิล)</span>
            </h3>
            <p className="text-xs text-slate-400">
              แสดงยอดถูกรางวัลรายบิล พร้อมคำนวณยอดหักกลบลบหนี้ (หักส่วนลดค่าโพย + หักกลบเงินรางวัล)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ค้นหาชื่อลูกค้า / เลขบิล..."
                className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setFilterMode('winners')}
                className={`px-3 py-1 rounded-lg font-semibold cursor-pointer transition-all ${
                  filterMode === 'winners'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                เฉพาะบิลถูกรางวัล
              </button>
              <button
                type="button"
                onClick={() => setFilterMode('all')}
                className={`px-3 py-1 rounded-lg font-semibold cursor-pointer transition-all ${
                  filterMode === 'all'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                ดูทุกบิล ({allBillSettlements.length})
              </button>
            </div>
          </div>
        </div>

        {/* Bills List */}
        {billSettlements.length === 0 ? (
          <div className="py-12 text-center text-slate-400 bg-slate-950/50 rounded-xl border border-slate-800/80">
            <Trophy className="w-10 h-10 mx-auto mb-2 opacity-30 text-amber-400" />
            <p className="text-sm font-medium text-slate-300">
              {filterMode === 'winners'
                ? 'ไม่มีบิลที่ถูกรางวัลจากเลขที่ระบุ'
                : 'ไม่พบบิลในระบบ'}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              ลองเปลี่ยนเลขรางวัลที่ออก หรือสลับตัวกรองเป็น "ดูทุกบิล"
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {billSettlements.map((bill) => {
              const hasWin = bill.winningItems.length > 0;
              return (
                <div
                  key={bill.billId}
                  className={`rounded-2xl border p-4 transition-all ${
                    hasWin
                      ? 'bg-emerald-950/15 border-emerald-500/40'
                      : 'bg-slate-950/60 border-slate-800'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <span className="font-mono font-bold text-base text-sky-400">
                        {bill.billId}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-lg bg-slate-800 text-slate-200 text-xs font-semibold flex items-center gap-1">
                        <User className="w-3 h-3 text-slate-400" />
                        <span>{bill.customerName}</span>
                      </span>
                      {bill.discountPercent > 0 && (
                        <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-[11px] font-bold flex items-center gap-0.5">
                          <Percent className="w-3 h-3" />
                          <span>ลด {bill.discountPercent}%</span>
                        </span>
                      )}
                      {hasWin ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>ถูกรางวัล {bill.winningItems.length} รายการ!</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[11px] flex items-center gap-1">
                          <XCircle className="w-3 h-3" />
                          <span>ไม่ถูกรางวัล</span>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {onViewReceipt && (
                        <button
                          type="button"
                          onClick={() => onViewReceipt(bill.billId)}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs border border-slate-700 cursor-pointer"
                        >
                          ดูสลิป / รูป PNG
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleCopyCustomerResult(bill)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        {copiedId === bill.billId ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>คัดลอกส่ง LINE แล้ว</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>คัดลอกผลส่งลูกค้า</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Winning Items Breakdown */}
                  {hasWin && (
                    <div className="mt-3 space-y-1.5">
                      <div className="text-[11px] font-semibold text-emerald-300">
                        รายการที่ถูกรางวัล:
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {bill.winningItems.map((w, i) => (
                          <div
                            key={i}
                            className="p-2.5 rounded-xl bg-slate-900/90 border border-emerald-500/30 flex items-center justify-between text-xs"
                          >
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-emerald-400">
                                  {w.type}
                                </span>
                                <span className="font-mono font-extrabold text-base text-amber-400">
                                  {w.number}
                                </span>
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                                  {w.matchReason}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-400 mt-0.5">
                                ซื้อ ฿{w.amount.toLocaleString()} × เรทจ่าย {w.payoutRate} บ.
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] text-slate-400 block">ได้เงินรางวัล</span>
                              <span className="font-mono font-bold text-sm text-emerald-400">
                                +฿{w.customerWinAmount.toLocaleString()}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Bill Financial Footer */}
                  <div className="mt-3 pt-2.5 border-t border-slate-800/60 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="text-slate-400">
                        ยอดซื้อสุทธิ:{' '}
                        <strong className="text-slate-200 font-mono">
                          ฿{bill.netBuy.toLocaleString()}
                        </strong>
                        {bill.discountPercent > 0 && (
                          <span className="text-indigo-300 ml-1 text-[11px]">
                            (หน้าโพย ฿{bill.totalBuy.toLocaleString()} ลด {bill.discountPercent}%)
                          </span>
                        )}
                      </span>
                      <span className="text-slate-400">
                        ยอดถูกรางวัลรวม:{' '}
                        <strong className="text-emerald-400 font-mono">
                          ฿{bill.totalWinPayout.toLocaleString()}
                        </strong>
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 justify-between w-full pt-2 border-t border-slate-800/40">
                      <div className="flex items-center gap-1.5 text-[11px]">
                        <span className="text-slate-400">สถานะเคลียร์เงิน:</span>
                        {(['รอเคลียร์ยอด', 'เคลียร์แล้ว', 'ค้างชำระ'] as SettlementPaymentStatus[]).map(
                          (st) => {
                            const currentSt = getBillPaymentStatus(bill.billId);
                            const isSelected = currentSt === st;
                            return (
                              <button
                                key={st}
                                type="button"
                                onClick={() => handleSetBillPaymentStatus(bill.billId, st)}
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                                  isSelected
                                    ? st === 'เคลียร์แล้ว'
                                      ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                                      : st === 'ค้างชำระ'
                                      ? 'bg-rose-500 text-white border-rose-400'
                                      : 'bg-amber-500 text-slate-950 border-amber-400'
                                    : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200'
                                }`}
                              >
                                {st}
                              </button>
                            );
                          }
                        )}
                      </div>

                      <div className="font-semibold">
                        {bill.netCustomerBalance >= 0 ? (
                          <span className="text-emerald-400 font-mono">
                            สุทธิโอนให้ลูกค้า (หักค่าโพยแล้ว): +฿
                            {bill.netCustomerBalance.toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-amber-400 font-mono">
                            สุทธิเก็บเงินลูกค้า: ฿
                            {Math.abs(bill.netCustomerBalance).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* SECTION: CUSTOMER ACCOUNTING & CASH FLOW SUMMARY (หมวด 5 & หมวด 6) */}
      {customerAccountingSummaries.length > 0 && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-400" />
              <div>
                <h3 className="font-bold text-sm sm:text-base text-white">
                  สรุปบัญชีและกระแสเงินสดรายลูกค้า (Customer Cash Flow Ledger)
                </h3>
                <p className="text-[11px] text-slate-400">
                  รวมยอดซื้อ หักส่วนลด หักกลบรางวัล และสถานะการเคลียร์เงินรายบุคคล
                </p>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">ลูกค้า</th>
                  <th className="py-2.5 px-2 text-center">บิล</th>
                  <th className="py-2.5 px-3 text-right">ยอดซื้อสุทธิ</th>
                  <th className="py-2.5 px-3 text-right">ถูกรางวัล</th>
                  <th className="py-2.5 px-3 text-right">ดุลสุทธิ (รับ/จ่าย)</th>
                  <th className="py-2.5 px-3 text-center">สถานะเคลียร์ยอด</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {customerAccountingSummaries.map((c) => {
                  const isAllSettled = c.pendingBillsCount === 0;
                  return (
                    <tr key={c.customerName} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-semibold text-slate-100">
                        {c.customerName}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">
                        {c.billsCount}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-200">
                        ฿{c.netBuy.toLocaleString()}
                        {c.discountAmount > 0 && (
                          <span className="block text-[10px] text-indigo-400">
                            (ลด -฿{c.discountAmount.toLocaleString()})
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-400">
                        {c.totalWinPayout > 0 ? `+฿${c.totalWinPayout.toLocaleString()}` : '-'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold">
                        {c.netCustomerBalance >= 0 ? (
                          <span className="text-rose-400">
                            จ่ายลูกค้า ฿{c.netCustomerBalance.toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-emerald-400">
                            เก็บเงิน ฿{Math.abs(c.netCustomerBalance).toLocaleString()}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          type="button"
                          onClick={() =>
                            handleSetCustomerBillsSettled(
                              c.customerName,
                              isAllSettled ? 'รอเคลียร์ยอด' : 'เคลียร์แล้ว'
                            )
                          }
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                            isAllSettled
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                              : 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                          }`}
                        >
                          {isAllSettled
                            ? '✓ เคลียร์ครบแล้ว'
                            : `รอเคลียร์ (${c.pendingBillsCount}/${c.billsCount})`}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
