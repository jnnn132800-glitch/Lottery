// Embedded Google Apps Script code strings for direct 1-click copying and downloading

export const CODE_GS_SOURCE = `/**
 * =========================================================================
 * LOTTERY POS BACKEND - Google Apps Script (Code.gs)
 * เชื่อมต่อ Google Sheets: Config_Settings, Transactions, Summary_Risk
 * พัฒนาสำหรับระบบจดรับเดิมพันหวย (Lottery POS) บนมือถือ
 * =========================================================================
 */

/**
 * แสดงผลหน้า WebApp เมื่อเปิดผ่านเบราว์เซอร์บนมือถือ
 */
function doGet(e) {
  var template = HtmlService.createTemplateFromFile('Index');
  return template.evaluate()
    .setTitle('Lottery POS - ระบบจดรับเดิมพันหวยมือถือ')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * รองรับการเชื่อมต่อจาก Express Backend Server ผ่าน HTTP POST (doPost)
 */
function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents || '{}');
    var action = body.action || '';
    var payload = body.payload || {};
    if (action === 'CREATE_BILL' && payload.createdTransactions) {
      var res = saveTransactions({
        billId: payload.billId,
        idempotencyKey: (payload.createdTransactions[0] && payload.createdTransactions[0].idempotencyKey) || ('IDEM_' + payload.billId),
        customerName: (payload.createdTransactions[0] && payload.createdTransactions[0].customerName) || 'ลูกค้าทั่วไป',
        items: payload.createdTransactions
      });
      return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
    }
    return ContentService.createTextOutput(JSON.stringify({ success: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ success: false, error: err.message })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * ดึงการตั้งค่า Config_Settings และยอดรวมความเสี่ยงปัจจุบันจาก Google Sheets
 * เพื่อนำไปใช้ตรวจสอบเลขอั้น/ปิดรับ/เพดานความเสี่ยงแบบเรียลไทม์
 */
function getSettings() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    
    // 1. ดึงข้อมูล Config_Settings
    var configSheet = ss.getSheetByName('Config_Settings');
    if (!configSheet) {
      configSheet = initializeConfigSheet(ss);
    }
    
    var configData = configSheet.getDataRange().getValues();
    var configs = [];
    // ข้าม Header: Type, Number, PayoutRate, MaxRisk, Status
    for (var i = 1; i < configData.length; i++) {
      var row = configData[i];
      if (row[0] !== '') {
        configs.push({
          type: String(row[0]).trim(),
          number: String(row[1]).trim(),
          payoutRate: Number(row[2]) || 0,
          maxRisk: Number(row[3]) || 0,
          status: String(row[4] || 'ปกติ').trim()
        });
      }
    }

    // 2. ดึงยอดสะสมปัจจุบันจากชีต Transactions เพื่อใช้คิดเพดาน MaxRisk แบบสด
    var transSheet = ss.getSheetByName('Transactions');
    var riskAccumulation = {};
    var lastBillNumber = 0;

    if (transSheet && transSheet.getLastRow() > 1) {
      var transData = transSheet.getDataRange().getValues();
      for (var j = 1; j < transData.length; j++) {
        var tRow = transData[j];
        var billId = String(tRow[1] || '');
        if (billId.startsWith('B')) {
          var bNum = parseInt(billId.replace('B', ''), 10);
          if (!isNaN(bNum) && bNum > lastBillNumber) {
            lastBillNumber = bNum;
          }
        }
        
        var tType = String(tRow[3]).trim();
        var tNum = String(tRow[4]).trim();
        var tAmt = Number(tRow[5]) || 0;
        var key = tType + '_' + tNum;
        riskAccumulation[key] = (riskAccumulation[key] || 0) + tAmt;
      }
    }

    var nextBillId = 'B' + ('000' + (lastBillNumber + 1)).slice(-3);

    return {
      success: true,
      configs: configs,
      riskAccumulation: riskAccumulation,
      nextBillId: nextBillId,
      timestamp: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss')
    };

  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * บันทึกรายการบิลลงชีต Transactions (แบบ Array หลายรายการพร้อมกัน)
 * และอัปเดตสรุปความเสี่ยงลงชีต Summary_Risk ทันที
 * 
 * @param {Object} payload {
 *   billId: "B005",
 *   customerName: "นาย สมชาย",
 *   items: [
 *     { type: "2ตัวบน", number: "38", amount: 500, status: "ปกติ", sentAmount: 0, keepAmount: 500 },
 *     ...
 *   ]
 * }
 */
function saveTransactions(payload) {
  var lock = LockService.getScriptLock();
  // ป้องกันการบันทึกทับกันเมื่อมีผู้ใช้งานหลายเครื่องพร้อมกัน
  try {
    lock.waitLock(10000);
  } catch (e) {
    return { success: false, error: 'ระบบกำลังประมวลผลบิลอื่นอยู่ กรุณาลองใหม่อีกครั้ง' };
  }

  try {
    if (!payload || !payload.items || !payload.items.length) {
      throw new Error('ไม่พบรายการเดิมพันในบิล');
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    
    // 1. ตรวจสอบ/เตรียมชีต Transactions
    var transSheet = ss.getSheetByName('Transactions');
    if (!transSheet) {
      transSheet = ss.insertSheet('Transactions');
      transSheet.appendRow([
        'Timestamp',
        'Bill_ID',
        'Customer_Name',
        'Type',
        'Number',
        'Amount',
        'Status',
        'Sent_Amount',
        'Keep_Amount'
      ]);
    }

    var nowStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
    var rowsToInsert = [];

    for (var i = 0; i < payload.items.length; i++) {
      var it = payload.items[i];
      rowsToInsert.push([
        nowStr,
        payload.billId,
        payload.customerName || 'ลูกค้าทั่วไป',
        it.type,
        "'" + it.number, // ใส่ single quote เพื่อคงเลข 0 นำหน้าไว้ เช่น '08
        Number(it.amount),
        it.status,
        Number(it.sentAmount) || 0,
        Number(it.keepAmount) || 0
      ]);
    }

    // Append ทีเดียวแบบ batch เพื่อความเร็วสูงสุด
    transSheet.getRange(transSheet.getLastRow() + 1, 1, rowsToInsert.length, 9).setValues(rowsToInsert);

    // 2. ปรับปรุงชีต Summary_Risk ให้ตรงกับโครงสร้าง CSV
    updateSummaryRiskSheet(ss);

    lock.releaseLock();
    return {
      success: true,
      message: 'บันทึกบิล ' + payload.billId + ' สำเร็จเรียบร้อย',
      billId: payload.billId,
      count: rowsToInsert.length,
      timestamp: nowStr
    };

  } catch (error) {
    lock.releaseLock();
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * คำนวณยอดสรุปความเสี่ยงใหม่ทั้งหมดจาก Transactions และ Config_Settings
 * ลงในชีต Summary_Risk ตามโครงสร้างคอลัมน์:
 * Type, Number, Total_Amount, Max_Risk_Limit, Over_Limit_Amount
 */
function updateSummaryRiskSheet(ss) {
  var transSheet = ss.getSheetByName('Transactions');
  var configSheet = ss.getSheetByName('Config_Settings');
  var summarySheet = ss.getSheetByName('Summary_Risk');

  if (!summarySheet) {
    summarySheet = ss.insertSheet('Summary_Risk');
  }

  // อ่าน Configs ไว้ใน Map
  var configsMap = {};
  var defaultsMap = {};
  if (configSheet && configSheet.getLastRow() > 1) {
    var cData = configSheet.getDataRange().getValues();
    for (var c = 1; c < cData.length; c++) {
      var cType = String(cData[c][0]).trim();
      var cNum = String(cData[c][1]).trim();
      var maxRisk = Number(cData[c][3]) || 0;
      if (cNum === '*') {
        defaultsMap[cType] = maxRisk;
      } else {
        configsMap[cType + '_' + cNum] = maxRisk;
      }
    }
  }

  // รวมยอด Transactions
  var summaryMap = {};
  var categoryKeepMap = {};
  if (transSheet && transSheet.getLastRow() > 1) {
    var tData = transSheet.getDataRange().getValues();
    for (var t = 1; t < tData.length; t++) {
      var type = String(tData[t][3]).trim();
      var num = String(tData[t][4]).replace(/^'/, '').trim();
      var amount = Number(tData[t][5]) || 0;
      var sent = Number(tData[t][7]) || 0;
      var keep = Number(tData[t][8]) || 0;
      var key = type + '_' + num;

      if (!summaryMap[key]) {
        var limit = (configsMap[key] !== undefined) ? configsMap[key] : (defaultsMap[type] !== undefined ? defaultsMap[type] : 20000);
        summaryMap[key] = {
          type: type,
          number: num,
          totalAmount: 0,
          keepAmount: 0,
          sentAmount: 0,
          maxRiskLimit: limit
        };
      }
      summaryMap[key].totalAmount += amount;
      summaryMap[key].keepAmount += keep;
      summaryMap[key].sentAmount += sent;

      categoryKeepMap[type] = (categoryKeepMap[type] || 0) + keep;
    }
  }

  // สร้างแถวข้อมูลสำหรับ Summary_Risk พร้อมคอลัมน์คำนวณกำไร
  var summaryRows = [
    ['Type', 'Number', 'Total_Amount', 'Max_Risk_Limit', 'Over_Limit_Amount', 'Keep_Amount', 'Payout_Rate', 'Potential_Payout', 'Estimated_Profit']
  ];

  for (var k in summaryMap) {
    var item = summaryMap[k];
    var overLimit = Math.max(0, item.totalAmount - item.maxRiskLimit);
    var rate = 90;
    var confSheet = ss.getSheetByName('Config_Settings');
    if (confSheet && confSheet.getLastRow() > 1) {
      var cRows = confSheet.getDataRange().getValues();
      for (var r = 1; r < cRows.length; r++) {
        var ct = String(cRows[r][0]).trim();
        var cn = String(cRows[r][1]).trim();
        if (ct === item.type && (cn === item.number || cn === '*')) {
          rate = Number(cRows[r][2]) || 0;
          if (cn === item.number) break;
        }
      }
    }

    var potentialPayout = item.keepAmount * rate;
    var catRev = categoryKeepMap[item.type] || 0;
    var estProfit = catRev - potentialPayout;

    summaryRows.push([
      item.type,
      "'" + item.number,
      item.totalAmount,
      item.maxRiskLimit,
      overLimit,
      item.keepAmount,
      rate,
      potentialPayout,
      estProfit
    ]);
  }

  summarySheet.clearContents();
  summarySheet.getRange(1, 1, summaryRows.length, 9).setValues(summaryRows);
}

/**
 * สร้างชีต Config_Settings เริ่มต้นตามข้อมูลตัวอย่าง
 */
function initializeConfigSheet(ss) {
  var sheet = ss.insertSheet('Config_Settings');
  var initialData = [
    ['Type', 'Number', 'PayoutRate', 'MaxRisk', 'Status'],
    ['3ตัวตรง', '*', 900, 5000, 'ปกติ'],
    ['3ตัวโต๊ด', '*', 150, 10000, 'ปกติ'],
    ['2ตัวบน', '*', 90, 20000, 'ปกติ'],
    ['2ตัวล่าง', '*', 90, 20000, 'ปกติ'],
    ['วิ่งบน', '*', 3.2, 50000, 'ปกติ'],
    ['วิ่งล่าง', '*', 4.2, 50000, 'ปกติ'],
    ['2ตัวบน', "'83", 45, 2000, 'อั้นจ่าย'],
    ['2ตัวล่าง', "'73", 45, 2000, 'อั้นจ่าย'],
    ['3ตัวตรง', "'538", 450, 500, 'อั้นจ่าย'],
    ['3ตัวตรง', "'999", 0, 0, 'ปิดรับ']
  ];
  sheet.getRange(1, 1, initialData.length, 5).setValues(initialData);
  return sheet;
}`;

export const INDEX_HTML_SOURCE = `<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Lottery POS - ระบบจดรับเดิมพันหวยมือถือ</title>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Google Fonts Prompt -->
  <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&family=JetBrains+Mono:wght@600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-dark: #0f172a;
      --card-dark: #1e293b;
      --card-border: #334155;
      --primary-accent: #10b981;
      --font-family: 'Prompt', sans-serif;
    }
    * {
      touch-action: manipulation;
      box-sizing: border-box;
      user-select: none;
    }
    body {
      font-family: var(--font-family);
      background-color: var(--bg-dark);
      color: #f8fafc;
      padding-bottom: 90px;
      overflow-x: hidden;
    }
    .header-bar {
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      border-bottom: 1px solid var(--card-border);
      position: sticky;
      top: 0;
      z-index: 100;
    }
    .lottery-type-btn {
      border: 1px solid #334155;
      background: #1e293b;
      color: #cbd5e1;
      font-weight: 500;
      border-radius: 12px;
      padding: 8px 12px;
      font-size: 0.85rem;
      transition: all 0.15s ease;
      white-space: nowrap;
    }
    .lottery-type-btn.active {
      background: #10b981;
      color: #0f172a;
      font-weight: 700;
      border-color: #34d399;
      box-shadow: 0 4px 12px rgba(16, 185, 129, 0.35);
    }
    .screen-display {
      background: #020617;
      border: 2px solid #334155;
      border-radius: 16px;
      padding: 12px 16px;
      min-height: 84px;
    }
    .screen-display.active-focus {
      border-color: #10b981;
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
    }
    .numpad-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
    }
    .num-btn {
      background: #1e293b;
      border: 1px solid #334155;
      color: #f8fafc;
      font-size: 1.6rem;
      font-weight: 600;
      border-radius: 14px;
      padding: 14px 0;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.1s;
    }
    .num-btn:active {
      transform: scale(0.94);
      background: #334155;
    }
    .shortcut-btn {
      background: #1e1b4b;
      border: 1px solid #4338ca;
      color: #c7d2fe;
      font-size: 0.85rem;
      font-weight: 600;
      border-radius: 12px;
      padding: 10px 4px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      line-height: 1.2;
    }
    .shortcut-btn:active {
      transform: scale(0.95);
      background: #3730a3;
    }
    .badge-status {
      font-size: 0.78rem;
      padding: 4px 10px;
      border-radius: 9999px;
      font-weight: 600;
    }
    .badge-green {
      background: rgba(16, 185, 129, 0.2);
      color: #34d399;
      border: 1px solid rgba(16, 185, 129, 0.4);
    }
    .badge-yellow {
      background: rgba(245, 158, 11, 0.2);
      color: #fbbf24;
      border: 1px solid rgba(245, 158, 11, 0.4);
    }
    .badge-red {
      background: rgba(239, 68, 68, 0.2);
      color: #f87171;
      border: 1px solid rgba(239, 68, 68, 0.4);
    }
    .quick-amt-btn {
      background: #1e293b;
      border: 1px solid #475569;
      color: #e2e8f0;
      font-size: 0.8rem;
      font-weight: 600;
      border-radius: 8px;
      padding: 6px 10px;
    }
    .quick-amt-btn:active {
      background: #334155;
    }
    .bottom-bar {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: #0f172a;
      border-top: 1px solid #334155;
      padding: 12px 16px;
      z-index: 99;
    }
    .basket-item {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 12px;
      padding: 10px 14px;
      margin-bottom: 8px;
    }
    .mono-num {
      font-family: 'JetBrains Mono', monospace;
    }
  </style>
</head>
<body>

  <!-- Top Bar -->
  <div class="header-bar py-2 px-3 d-flex align-items-center justify-content-between">
    <div class="d-flex align-items-center gap-2">
      <div class="bg-emerald-500 rounded-3 p-1 text-white bg-success d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
        <i class="bi bi-receipt"></i>
      </div>
      <div>
        <div class="fw-bold fs-6 lh-1">Lottery POS</div>
        <small class="text-secondary" style="font-size: 0.72rem;">บิล: <span id="displayBillId" class="text-info fw-bold">B005</span></small>
      </div>
    </div>
    <div class="d-flex gap-2 align-items-center">
      <button class="btn btn-sm btn-outline-warning py-1 px-2" data-bs-toggle="modal" data-bs-target="#gridModal" title="แผงจิ้มเลข 10x10 (00-99)">
        <i class="bi bi-grid-3x3 me-1"></i>แผง 00-99
      </button>
      <button class="btn btn-sm btn-outline-secondary text-light py-1 px-2" onclick="refreshSettings()" title="รีเฟรชข้อมูล">
        <i class="bi bi-arrow-repeat" id="refreshIcon"></i>
      </button>
      <button class="btn btn-sm btn-outline-info py-1 px-2 position-relative" data-bs-toggle="offcanvas" data-bs-target="#basketOffcanvas">
        <i class="bi bi-basket2-fill"></i>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="basketBadgeCount" style="display:none;">0</span>
      </button>
    </div>
  </div>

  <div class="container px-3 py-2" style="max-width: 520px;">

    <!-- Customer Name Input -->
    <div class="mb-2">
      <div class="input-group input-group-sm">
        <span class="input-group-text bg-secondary border-secondary text-white"><i class="bi bi-person-fill"></i></span>
        <input type="text" id="customerNameInput" class="form-control bg-dark text-white border-secondary" placeholder="ชื่อลูกค้า (เช่น นาย ก / ไม่ระบุ)">
      </div>
    </div>

    <!-- Type Selector -->
    <div class="d-flex gap-1 overflow-x-auto pb-2 mb-2" style="scrollbar-width: none;">
      <button class="lottery-type-btn active" onclick="selectType('2ตัวบน')">2ตัวบน</button>
      <button class="lottery-type-btn" onclick="selectType('2ตัวล่าง')">2ตัวล่าง</button>
      <button class="lottery-type-btn" onclick="selectType('3ตัวตรง')">3ตัวตรง</button>
      <button class="lottery-type-btn" onclick="selectType('3ตัวโต๊ด')">3ตัวโต๊ด</button>
      <button class="lottery-type-btn" onclick="selectType('วิ่งบน')">วิ่งบน</button>
      <button class="lottery-type-btn" onclick="selectType('วิ่งล่าง')">วิ่งล่าง</button>
    </div>

    <!-- Display Screen (Number & Amount) -->
    <div class="screen-display mb-2">
      <div class="row align-items-center g-2">
        <div class="col-6 cursor-pointer" onclick="setActiveField('number')">
          <small class="text-secondary d-block" style="font-size: 0.72rem;">เลขที่ต้องการแทง</small>
          <div class="d-flex align-items-baseline">
            <span class="fs-2 fw-bold text-warning mono-num" id="displayNumber">-</span>
            <span class="ms-1 text-secondary" style="font-size:0.75rem;" id="numberDigitLen">(0 หลัก)</span>
          </div>
        </div>
        <div class="col-6 text-end cursor-pointer" onclick="setActiveField('amount')">
          <small class="text-secondary d-block" style="font-size: 0.72rem;">จำนวนเงิน (บาท)</small>
          <div class="fs-2 fw-bold text-success mono-num" id="displayAmount">0</div>
        </div>
      </div>

      <!-- Live Validation Alert Bar -->
      <div class="mt-2 pt-2 border-top border-secondary d-flex align-items-center justify-content-between" id="alertContainer">
        <div class="d-flex align-items-center gap-1">
          <span class="badge-status badge-green" id="statusBadge"><i class="bi bi-check-circle-fill me-1"></i>ปกติ</span>
          <span class="text-secondary" style="font-size: 0.72rem;" id="validationText">พร้อมรับแทง จ่ายเต็มเรท</span>
        </div>
        <div class="text-end" style="font-size: 0.72rem;">
          <span class="text-muted">จ่าย:</span> <span class="fw-bold text-light mono-num" id="payoutRateDisplay">90</span> บ.
        </div>
      </div>
    </div>

    <!-- Quick Amounts -->
    <div class="d-flex gap-1 justify-content-between mb-2">
      <button class="quick-amt-btn flex-fill" onclick="setQuickAmount(10)">10</button>
      <button class="quick-amt-btn flex-fill" onclick="setQuickAmount(20)">20</button>
      <button class="quick-amt-btn flex-fill" onclick="setQuickAmount(50)">50</button>
      <button class="quick-amt-btn flex-fill" onclick="setQuickAmount(100)">100</button>
      <button class="quick-amt-btn flex-fill" onclick="setQuickAmount(500)">500</button>
      <button class="quick-amt-btn flex-fill" onclick="setQuickAmount(1000)">1000</button>
    </div>

    <!-- Shortcuts Grid -->
    <div class="row g-2 mb-2">
      <div class="col-3">
        <button class="shortcut-btn w-100" onclick="applyShortcut('reverse')">
          <i class="bi bi-arrow-left-right mb-1"></i>
          <span>กลับเลข</span>
        </button>
      </div>
      <div class="col-3">
        <button class="shortcut-btn w-100" onclick="applyShortcut('19door')">
          <i class="bi bi-door-open-fill mb-1"></i>
          <span>19 ประตู</span>
        </button>
      </div>
      <div class="col-3">
        <button class="shortcut-btn w-100" onclick="applyShortcut('swipeFront')">
          <i class="bi bi-arrow-bar-right mb-1"></i>
          <span>รูดหน้า</span>
        </button>
      </div>
      <div class="col-3">
        <button class="shortcut-btn w-100" onclick="applyShortcut('swipeBack')">
          <i class="bi bi-arrow-bar-left mb-1"></i>
          <span>รูดหลัง</span>
        </button>
      </div>
    </div>

    <!-- Custom Numpad -->
    <div class="numpad-grid mb-2">
      <button class="num-btn" onclick="pressKey('1')">1</button>
      <button class="num-btn" onclick="pressKey('2')">2</button>
      <button class="num-btn" onclick="pressKey('3')">3</button>
      <button class="num-btn" onclick="pressKey('4')">4</button>
      <button class="num-btn" onclick="pressKey('5')">5</button>
      <button class="num-btn" onclick="pressKey('6')">6</button>
      <button class="num-btn" onclick="pressKey('7')">7</button>
      <button class="num-btn" onclick="pressKey('8')">8</button>
      <button class="num-btn" onclick="pressKey('9')">9</button>
      <button class="num-btn text-danger" onclick="pressKey('C')" title="ล้างค่า"><i class="bi bi-x-circle"></i></button>
      <button class="num-btn" onclick="pressKey('0')">0</button>
      <button class="num-btn text-warning" onclick="pressKey('DEL')" title="ลบตัวเลข"><i class="bi bi-backspace"></i></button>
    </div>

    <!-- Add to Basket Button -->
    <button class="btn btn-success w-100 py-3 fw-bold fs-5 rounded-4 shadow-lg d-flex align-items-center justify-content-center gap-2" id="btnAddItem" onclick="handleAddToBasket()">
      <i class="bi bi-plus-circle-fill"></i>
      <span>เพิ่มลงตะกร้า</span>
    </button>

  </div>

  <!-- Sticky Bottom Bar -->
  <div class="bottom-bar">
    <div class="d-flex align-items-center justify-content-between" style="max-width: 520px; margin: 0 auto;">
      <div>
        <small class="text-secondary d-block" style="font-size: 0.72rem;">ยอดรวมในตะกร้า (<span id="bottomItemCount">0</span> รายการ)</small>
        <span class="fs-5 fw-bold text-warning mono-num" id="bottomTotalAmount">฿0</span>
      </div>
      <button class="btn btn-warning fw-bold px-4 py-2 rounded-3 text-dark d-flex align-items-center gap-2" data-bs-toggle="offcanvas" data-bs-target="#basketOffcanvas">
        <i class="bi bi-receipt-cutoff"></i>
        <span>ดูตะกร้าบิล</span>
      </button>
    </div>
  </div>

  <!-- Offcanvas Basket (ตะกร้าบิล) -->
  <div class="offcanvas offcanvas-bottom bg-dark text-white border-top border-secondary" tabindex="-1" id="basketOffcanvas" style="height: 80vh;">
    <div class="offcanvas-header border-bottom border-secondary py-3">
      <h5 class="offcanvas-title fw-bold text-warning d-flex align-items-center gap-2">
        <i class="bi bi-basket2-fill"></i>
        <span>ตะกร้าบิลหวย (<span id="canvasItemCount">0</span>)</span>
      </h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body p-3">
      <!-- Summary Chips -->
      <div class="row g-2 mb-3">
        <div class="col-4">
          <div class="p-2 rounded bg-secondary bg-opacity-25 text-center">
            <small class="text-secondary d-block" style="font-size: 0.7rem;">ยอดรวม</small>
            <span class="fw-bold mono-num text-light" id="canvasSummaryTotal">฿0</span>
          </div>
        </div>
        <div class="col-4">
          <div class="p-2 rounded bg-success bg-opacity-25 text-center border border-success">
            <small class="text-success d-block" style="font-size: 0.7rem;">ยอดถือเอง</small>
            <span class="fw-bold mono-num text-success" id="canvasSummaryKeep">฿0</span>
          </div>
        </div>
        <div class="col-4">
          <div class="p-2 rounded bg-danger bg-opacity-25 text-center border border-danger">
            <small class="text-danger d-block" style="font-size: 0.7rem;">ตีเกิน(ส่งต่อ)</small>
            <span class="fw-bold mono-num text-danger" id="canvasSummarySent">฿0</span>
          </div>
        </div>
      </div>

      <!-- Item List -->
      <div id="basketItemList" class="mb-4">
        <div class="text-center text-muted py-5">
          <i class="bi bi-cart-x fs-1 d-block mb-2"></i>
          ยังไม่มีรายการในตะกร้า
        </div>
      </div>
    </div>
    <div class="p-3 border-top border-secondary bg-dark">
      <div class="d-flex gap-2">
        <button class="btn btn-outline-danger flex-fill py-2" onclick="clearBasket()">
          <i class="bi bi-trash3 me-1"></i>ล้างทั้งหมด
        </button>
        <button class="btn btn-success flex-fill py-2 fw-bold" id="btnConfirmSave" onclick="confirmSaveBill()">
          <i class="bi bi-cloud-arrow-up-fill me-1"></i>ยืนยันบันทึกบิล
        </button>
      </div>
    </div>
  </div>

  <!-- Modal Warning เลขอั้นจ่าย (Yellow Alert) -->
  <div class="modal fade" id="halfPayModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content bg-dark text-white border-warning">
        <div class="modal-header border-secondary">
          <h5 class="modal-title text-warning"><i class="bi bi-exclamation-triangle-fill me-2"></i>แจ้งเตือน: เลขอั้นจ่าย</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p id="halfPayModalText" class="mb-2">เลขนี้จัดอยู่ในกลุ่มอั้นจ่าย (จ่ายครึ่งราคาหรือตามอัตราพิเศษ)</p>
          <div class="p-3 rounded bg-warning bg-opacity-10 border border-warning mb-2">
            <div class="d-flex justify-content-between mb-1">
              <span>ประเภท / เลข:</span>
              <strong id="halfPayModalNum" class="text-warning mono-num">-</strong>
            </div>
            <div class="d-flex justify-content-between mb-1">
              <span>อัตราจ่ายปกติ:</span>
              <span id="halfPayModalNormalRate" class="text-muted mono-num">90 บ.</span>
            </div>
            <div class="d-flex justify-content-between">
              <span>อัตราจ่ายที่รับ:</span>
              <strong id="halfPayModalSpecialRate" class="text-success mono-num fs-5">45 บ.</strong>
            </div>
          </div>
          <small class="text-secondary">ท่านต้องการยืนยันเพิ่มรายการนี้ลงในตะกร้าบิลหรือไม่?</small>
        </div>
        <div class="modal-footer border-secondary">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">ยกเลิก</button>
          <button type="button" class="btn btn-warning text-dark fw-bold" id="btnConfirmHalfPay">รับเดิมพันตามเรทนี้</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal 10x10 Grid (00-99) -->
  <div class="modal fade" id="gridModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
      <div class="modal-content bg-dark text-white border-secondary">
        <div class="modal-header border-secondary py-2 bg-black bg-opacity-40">
          <h6 class="modal-title text-warning fw-bold d-flex align-items-center gap-2">
            <i class="bi bi-grid-3x3"></i>แผงจิ้มเลขด่วน 00 - 99
          </h6>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-3">
          <div class="mb-3">
            <label class="small text-secondary fw-bold mb-1 d-block">1. เลือกประเภทการแทง</label>
            <div class="btn-group w-100" role="group">
              <input type="radio" class="btn-check" name="gridBetType" id="gridTypeTop" value="2ตัวบน" checked onchange="updateGridUI()">
              <label class="btn btn-outline-success btn-sm py-2" for="gridTypeTop">2ตัวบน</label>

              <input type="radio" class="btn-check" name="gridBetType" id="gridTypeBottom" value="2ตัวล่าง" onchange="updateGridUI()">
              <label class="btn btn-outline-success btn-sm py-2" for="gridTypeBottom">2ตัวล่าง</label>

              <input type="radio" class="btn-check" name="gridBetType" id="gridTypeBoth" value="2ตัวบน+ล่าง" onchange="updateGridUI()">
              <label class="btn btn-outline-warning btn-sm py-2 fw-bold" for="gridTypeBoth">2ตัวบน+ล่าง</label>
            </div>
          </div>

          <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <label class="small text-secondary fw-bold">2. ระบุจำนวนเงิน (บาท/เลข)</label>
              <div class="d-flex gap-1">
                <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-2" style="font-size:0.75rem;" onclick="setGridAmt(10)">฿10</button>
                <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-2" style="font-size:0.75rem;" onclick="setGridAmt(20)">฿20</button>
                <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-2" style="font-size:0.75rem;" onclick="setGridAmt(50)">฿50</button>
                <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-2" style="font-size:0.75rem;" onclick="setGridAmt(100)">฿100</button>
              </div>
            </div>
            <div class="input-group">
              <span class="input-group-text bg-secondary border-secondary text-white">฿</span>
              <input type="number" id="gridAmountInput" class="form-control bg-dark text-warning fw-bold fs-5 border-secondary mono-num" value="10" min="1" placeholder="จำนวนเงิน" oninput="updateGridUI()">
            </div>
          </div>

          <div class="mb-2">
            <label class="small text-secondary fw-bold mb-1 d-block">3. ปุ่มลัดเลือกกลุ่มเลข</label>
            <div class="d-flex flex-wrap gap-1">
              <button type="button" class="btn btn-sm btn-outline-info py-1 px-2" style="font-size:0.75rem;" onclick="quickSelectGrid('doubles')">เลขเบิ้ล</button>
              <button type="button" class="btn btn-sm btn-outline-info py-1 px-2" style="font-size:0.75rem;" onclick="quickSelectGrid('siblings')">เลขพี่น้อง</button>
              <button type="button" class="btn btn-sm btn-outline-secondary py-1 px-2 text-light" style="font-size:0.75rem;" onclick="quickSelectGrid('evens')">เลขคู่</button>
              <button type="button" class="btn btn-sm btn-outline-secondary py-1 px-2 text-light" style="font-size:0.75rem;" onclick="quickSelectGrid('odds')">เลขคี่</button>
              <button type="button" class="btn btn-sm btn-outline-primary py-1 px-2" style="font-size:0.75rem;" onclick="quickSelectGrid('all')">เลือกหมด (100 ตัว)</button>
              <button type="button" class="btn btn-sm btn-outline-danger py-1 px-2" style="font-size:0.75rem;" onclick="quickSelectGrid('clear')">ยกเลิกที่เลือก</button>
            </div>
          </div>

          <div class="p-2 rounded bg-black bg-opacity-50 border border-secondary">
            <div class="d-flex justify-content-between align-items-center mb-1 text-secondary" style="font-size: 0.72rem;">
              <span>แตะตัวเลข 00 - 99:</span>
              <span id="gridSelectedCountText" class="text-success fw-bold">เลือกแล้ว 0 ตัว</span>
            </div>
            <div id="gridContainer" class="d-grid" style="grid-template-columns: repeat(10, 1fr); gap: 3px;"></div>
          </div>
        </div>
        <div class="modal-footer border-secondary py-2 bg-black bg-opacity-40 d-flex justify-content-between">
          <div>
            <small class="text-secondary d-block" style="font-size: 0.7rem;">ยอดรวมโดยประมาณ:</small>
            <span id="gridTotalCost" class="text-warning fw-bold fs-5 mono-num">฿0</span>
          </div>
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-danger btn-sm px-3" onclick="clearGridForm()">
              <i class="bi bi-trash3 me-1"></i>ล้าง
            </button>
            <button type="button" class="btn btn-success btn-sm px-3 fw-bold" id="btnConfirmGrid" onclick="confirmGridToBasket()">
              <i class="bi bi-check-circle-fill me-1"></i>ยืนยันแทง
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap 5 JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Client-Side Logic -->
  <script>
    // 10x10 Grid State & Logic
    let gridSelected = new Set();
    const ALL_100 = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'));

    function init10x10Grid() {
      const container = document.getElementById('gridContainer');
      if (!container) return;
      container.innerHTML = '';

      ALL_100.forEach(num => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.id = 'gridNum_' + num;
        btn.className = 'btn btn-outline-secondary p-0 d-flex align-items-center justify-content-center mono-num fw-bold text-light';
        btn.style.height = '34px';
        btn.style.fontSize = '0.85rem';
        btn.innerText = num;
        btn.onclick = () => toggleGridNumber(num);
        container.appendChild(btn);
      });
      updateGridUI();
    }

    function toggleGridNumber(num) {
      if (gridSelected.has(num)) {
        gridSelected.delete(num);
      } else {
        gridSelected.add(num);
      }
      updateGridUI();
    }

    function setGridAmt(amt) {
      const input = document.getElementById('gridAmountInput');
      if (input) input.value = amt;
      updateGridUI();
    }

    function clearGridForm() {
      gridSelected.clear();
      updateGridUI();
    }

    function quickSelectGrid(action) {
      if (action === 'clear') {
        gridSelected.clear();
      } else if (action === 'all') {
        gridSelected = new Set(ALL_100);
      } else if (action === 'doubles') {
        gridSelected = new Set(ALL_100.filter(n => n[0] === n[1]));
      } else if (action === 'siblings') {
        gridSelected = new Set(ALL_100.filter(n => {
          const d1 = Number(n[0]), d2 = Number(n[1]);
          const diff = Math.abs(d1 - d2);
          return diff === 1 || (d1 === 0 && d2 === 9) || (d1 === 9 && d2 === 0);
        }));
      } else if (action === 'evens') {
        gridSelected = new Set(ALL_100.filter(n => Number(n) % 2 === 0));
      } else if (action === 'odds') {
        gridSelected = new Set(ALL_100.filter(n => Number(n) % 2 === 1));
      }
      updateGridUI();
    }

    function getSelectedGridType() {
      const r = document.querySelector('input[name="gridBetType"]:checked');
      return r ? r.value : '2ตัวบน';
    }

    function updateGridUI() {
      const count = gridSelected.size;
      const type = getSelectedGridType();
      const amt = Number(document.getElementById('gridAmountInput')?.value) || 0;
      const mult = type === '2ตัวบน+ล่าง' ? 2 : 1;
      const totalItems = count * mult;
      const totalCost = totalItems * amt;

      const countText = document.getElementById('gridSelectedCountText');
      if (countText) {
        countText.innerText = 'เลือกแล้ว ' + count + ' ตัว' + (type === '2ตัวบน+ล่าง' ? ' (' + totalItems + ' รายการ)' : '');
      }

      const totalCostEl = document.getElementById('gridTotalCost');
      if (totalCostEl) {
        totalCostEl.innerText = '฿' + totalCost.toLocaleString();
      }

      ALL_100.forEach(num => {
        const btn = document.getElementById('gridNum_' + num);
        if (!btn) return;
        const evTop = evaluateRisk('2ตัวบน', num, amt || 1);
        const evBot = evaluateRisk('2ตัวล่าง', num, amt || 1);
        let badges = '';
        if (evTop.status !== 'ปกติ' || evTop.sentAmount > 0) {
          badges += '<span class="badge bg-warning text-dark" style="font-size:0.5rem;padding:1px 2px;">บน:' + (evTop.status === 'ปิดรับ' ? 'ปิด' : evTop.sentAmount > 0 ? 'เต็ม' : 'อั้น') + '</span>';
        }
        if (evBot.status !== 'ปกติ' || evBot.sentAmount > 0) {
          badges += '<span class="badge bg-info text-dark" style="font-size:0.5rem;padding:1px 2px;">ล่าง:' + (evBot.status === 'ปิดรับ' ? 'ปิด' : evBot.sentAmount > 0 ? 'เต็ม' : 'อั้น') + '</span>';
        }
        btn.style.height = '44px';
        btn.innerHTML = '<div class="d-flex flex-column align-items-center justify-content-center lh-1"><span>' + num + '</span>' + (badges ? '<div class="d-flex gap-1 mt-1">' + badges + '</div>' : '') + '</div>';
        if (gridSelected.has(num)) {
          btn.className = 'btn btn-success p-0 d-flex align-items-center justify-content-center mono-num fw-bold shadow-sm';
        } else if (badges) {
          btn.className = 'btn btn-outline-warning p-0 d-flex align-items-center justify-content-center mono-num fw-bold text-warning';
        } else {
          btn.className = 'btn btn-outline-secondary p-0 d-flex align-items-center justify-content-center mono-num fw-bold text-light';
        }
      });
    }

    function confirmGridToBasket() {
      const count = gridSelected.size;
      const amt = Number(document.getElementById('gridAmountInput')?.value) || 0;
      if (count === 0) {
        showToast('warning', '⚠️ ยังไม่ได้เลือกเลข', 'กรุณาแตะเลือกตัวเลขอย่างน้อย 1 ตัวจากตาราง');
        return;
      }
      if (amt <= 0) {
        showToast('warning', '⚠️ ยังไม่ได้ระบุราคา', 'กรุณาระบุจำนวนเงินเดิมพัน (บาท)');
        return;
      }

      const type = getSelectedGridType();
      const typesToAdd = type === '2ตัวบน+ล่าง' ? ['2ตัวบน', '2ตัวล่าง'] : [type];
      const sorted = Array.from(gridSelected).sort();
      let addedCount = 0;
      let closedCount = 0;
      let halfPayCount = 0;

      sorted.forEach(num => {
        typesToAdd.forEach(t => {
          const val = evaluateRisk(t, num, amt);
          if (val.status === 'ปิดรับ' || val.canAccept === false) {
            closedCount++;
            return;
          }
          if (val.status === 'อั้นจ่าย') {
            halfPayCount++;
          }
          basket.push({
            id: Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            type: t,
            number: num,
            amount: amt,
            payoutRate: val.payoutRate,
            status: val.status,
            sentAmount: val.sentAmount,
            keepAmount: val.keepAmount
          });
          addedCount++;
        });
      });

      renderBasket();
      updateUI();
      gridSelected.clear();
      updateGridUI();

      const modalEl = document.getElementById('gridModal');
      const modalInst = bootstrap.Modal.getInstance(modalEl);
      if (modalInst) modalInst.hide();

      if (addedCount > 0) {
        alert('เพิ่ม ' + addedCount + ' รายการลงตะกร้าเรียบร้อย' + (halfPayCount > 0 ? ' (มีเลขอั้นจ่ายตามเรทพิเศษ)' : ''));
      }
      if (closedCount > 0) {
        alert('มี ' + closedCount + ' ตัวเลขที่ปิดรับแทงเนื่องจากยอดเต็มเพดาน');
      }
    }

    // State
    let currentType = '2ตัวบน';
    let currentNumber = '';
    let currentAmount = '';
    let activeField = 'number';
    let basket = [];
    let billId = 'B005';
    let configs = [
      { type: '3ตัวตรง', number: '*', payoutRate: 900, maxRisk: 5000, status: 'ปกติ' },
      { type: '3ตัวโต๊ด', number: '*', payoutRate: 150, maxRisk: 10000, status: 'ปกติ' },
      { type: '2ตัวบน', number: '*', payoutRate: 90, maxRisk: 20000, status: 'ปกติ' },
      { type: '2ตัวล่าง', number: '*', payoutRate: 90, maxRisk: 20000, status: 'ปกติ' },
      { type: 'วิ่งบน', number: '*', payoutRate: 3.2, maxRisk: 50000, status: 'ปกติ' },
      { type: 'วิ่งล่าง', number: '*', payoutRate: 4.2, maxRisk: 50000, status: 'ปกติ' },
      { type: '2ตัวบน', number: '83', payoutRate: 45, maxRisk: 2000, status: 'อั้นจ่าย' },
      { type: '2ตัวล่าง', number: '73', payoutRate: 45, maxRisk: 2000, status: 'อั้นจ่าย' },
      { type: '3ตัวตรง', number: '538', payoutRate: 450, maxRisk: 500, status: 'อั้นจ่าย' },
      { type: '3ตัวตรง', number: '999', payoutRate: 0, maxRisk: 0, status: 'ปิดรับ' }
    ];
    let riskAccumulation = {
      '2ตัวบน_38': 500,
      '2ตัวบน_83': 2500,
      '3ตัวตรง_538': 300,
      '3ตัวตรง_999': 100
    };

    let pendingHalfPayAction = null;
    const halfPayModal = new bootstrap.Modal(document.getElementById('halfPayModal'));

    window.addEventListener('DOMContentLoaded', () => {
      init10x10Grid();
      updateUI();
      if (typeof google !== 'undefined' && google.script && google.script.run) {
        refreshSettings();
      }
    });

    function refreshSettings() {
      const icon = document.getElementById('refreshIcon');
      if (icon) icon.classList.add('bi-spin');
      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler((res) => {
            if (icon) icon.classList.remove('bi-spin');
            if (res && res.success) {
              configs = res.configs || configs;
              riskAccumulation = res.riskAccumulation || riskAccumulation;
              if (res.nextBillId) {
                billId = res.nextBillId;
                document.getElementById('displayBillId').innerText = billId;
              }
              validateCurrentInput();
            }
          })
          .withFailureHandler((err) => {
            if (icon) icon.classList.remove('bi-spin');
            alert('ไม่สามารถเชื่อมต่อ Google Sheets: ' + err);
          })
          .getSettings();
      } else {
        setTimeout(() => {
          if (icon) icon.classList.remove('bi-spin');
        }, 500);
      }
    }

    function selectType(t) {
      currentType = t;
      document.querySelectorAll('.lottery-type-btn').forEach(btn => {
        btn.classList.toggle('active', btn.innerText === t);
      });
      currentNumber = '';
      activeField = 'number';
      updateUI();
    }

    function setActiveField(f) {
      activeField = f;
      updateUI();
    }

    function pressKey(k) {
      if (k === 'C') {
        if (activeField === 'number') currentNumber = '';
        else currentAmount = '';
      } else if (k === 'DEL') {
        if (activeField === 'number') currentNumber = currentNumber.slice(0, -1);
        else currentAmount = currentAmount.slice(0, -1);
      } else {
        if (activeField === 'number') {
          const maxDigits = currentType.startsWith('3') ? 3 : currentType.startsWith('2') ? 2 : 1;
          if (currentNumber.length < maxDigits) {
            currentNumber += k;
            if (currentNumber.length === maxDigits && !currentAmount) {
              activeField = 'amount';
            }
          }
        } else {
          if (currentAmount.length < 7) {
            currentAmount += k;
          }
        }
      }
      updateUI();
    }

    function setQuickAmount(amt) {
      currentAmount = String(amt);
      updateUI();
    }

    function applyShortcut(type) {
      const amt = Number(currentAmount) || 0;
      if (amt <= 0) {
        alert('กรุณาใส่จำนวนเงินก่อนใช้ปุ่มลัด');
        activeField = 'amount';
        updateUI();
        return;
      }

      const maxDigits = currentType.startsWith('3') ? 3 : currentType.startsWith('2') ? 2 : 1;
      let numbersToAdd = [];
      if (type === 'reverse') {
        if (!currentNumber) {
          alert('กรุณาใส่เลขให้ครบ ' + maxDigits + ' หลักก่อนกดกลับเลข');
          return;
        }
        if (currentNumber.length !== maxDigits) {
          alert('เลข ' + currentType + ' ต้องใส่ให้ครบ ' + maxDigits + ' หลักก่อนกดกลับเลข (เช่น ถ้ามี 0 ต้องใส่ 0x หรือ x0 เช่น 05, 50)');
          return;
        }
        numbersToAdd = getPermutations(currentNumber);
      } else if (type === '19door') {
        if (!currentType.startsWith('2')) {
          alert('ปุ่มลัด 19 ประตู ใช้สำหรับเลข 2 ตัวบน / 2 ตัวล่าง');
          return;
        }
        if (!currentNumber) {
          alert('กรุณาระบุเลขหลัก 1 ตัว (0-9) ก่อนกด 19 ประตู (เช่น ใส่ 0 เพื่อสร้าง 0x และ x0 รวม 19 ตัว)');
          return;
        }
        const digit = currentNumber.slice(-1);
        numbersToAdd = get19Doors(digit);
      } else if (type === 'swipeFront') {
        if (!currentType.startsWith('2')) {
          alert('ปุ่มลัด รูดหน้า ใช้สำหรับเลข 2 ตัวบน / 2 ตัวล่าง');
          return;
        }
        if (!currentNumber) {
          alert('กรุณาระบุเลข 1 ตัว (0-9) ก่อนกดรูดหน้า (เช่น ใส่ 0 เพื่อสร้าง 00 ถึง 09)');
          return;
        }
        const digit = currentNumber.slice(-1);
        numbersToAdd = getSwipeFront(digit);
      } else if (type === 'swipeBack') {
        if (!currentType.startsWith('2')) {
          alert('ปุ่มลัด รูดหลัง ใช้สำหรับเลข 2 ตัวบน / 2 ตัวล่าง');
          return;
        }
        if (!currentNumber) {
          alert('กรุณาระบุเลข 1 ตัว (0-9) ก่อนกดรูดหลัง (เช่น ใส่ 0 เพื่อสร้าง 00, 10, ... 90)');
          return;
        }
        const digit = currentNumber.slice(-1);
        numbersToAdd = getSwipeBack(digit);
      }

      if (!numbersToAdd.length) return;

      let hasYellow = false;
      let yellowItems = [];

      for (let num of numbersToAdd) {
        const val = evaluateRisk(currentType, num, amt);
        if (val.status === 'ปิดรับ' || val.canAccept === false) {
          continue;
        }
        if (val.status === 'อั้นจ่าย') {
          hasYellow = true;
          yellowItems.push({ num, val });
        }
        basket.push({
          id: Date.now() + '_' + Math.random().toString(36).substr(2, 5),
          type: currentType,
          number: num,
          amount: amt,
          payoutRate: val.payoutRate,
          status: val.status,
          sentAmount: val.sentAmount,
          keepAmount: val.keepAmount
        });
      }

      currentNumber = '';
      activeField = 'number';
      updateUI();
      renderBasket();

      if (hasYellow) {
        alert('มีเลขอั้นจ่ายในชุดที่เพิ่ม ' + yellowItems.length + ' ตัว (อัตราจ่ายพิเศษ)');
      }
    }

    function getPermutations(str) {
      if (str.length <= 1) return [str];
      let results = new Set();
      function permute(arr, m = []) {
        if (arr.length === 0) results.add(m.join(''));
        else {
          for (let i = 0; i < arr.length; i++) {
            let curr = arr.slice();
            let next = curr.splice(i, 1);
            permute(curr.slice(), m.concat(next));
          }
        }
      }
      permute(str.split(''));
      return Array.from(results);
    }

    function get19Doors(d) {
      let res = [];
      for (let i = 0; i <= 9; i++) res.push('' + i + d);
      for (let i = 0; i <= 9; i++) {
        let n = '' + d + i;
        if (!res.includes(n)) res.push(n);
      }
      return res;
    }

    function getSwipeFront(d) {
      let res = [];
      for (let i = 0; i <= 9; i++) res.push('' + d + i);
      return res;
    }

    function getSwipeBack(d) {
      let res = [];
      for (let i = 0; i <= 9; i++) res.push('' + i + d);
      return res;
    }

    function evaluateRisk(type, num, amt) {
      let rule = configs.find(c => c.type === type && c.number === num);
      if (!rule) {
        rule = configs.find(c => c.type === type && c.number === '*');
      }
      if (!rule) {
        rule = { type, number: '*', payoutRate: 90, maxRisk: 20000, status: 'ปกติ' };
      }

      const key = type + '_' + num;
      const prevTotal = riskAccumulation[key] || 0;
      const inBasketTotal = basket.filter(b => b.type === type && b.number === num).reduce((s, b) => s + b.amount, 0);
      const accumulated = prevTotal + inBasketTotal;
      const newTotal = accumulated + amt;

      let status = rule.status;
      let canAccept = true;
      let alertType = 'green';
      let alertMessage = 'บันทึกได้ปกติ';
      let keepAmount = 0;
      let sentAmount = 0;

      if (rule.status === 'ปิดรับ' || rule.maxRisk <= 0) {
        return {
          rule,
          status: 'ปิดรับ',
          payoutRate: rule.payoutRate,
          maxRisk: rule.maxRisk,
          canAccept: false,
          alertType: 'red',
          alertMessage: 'เลขปิดรับ (เต็มเพดานความเสี่ยง)',
          keepAmount: 0,
          sentAmount: amt
        };
      }

      const availableRoom = Math.max(0, rule.maxRisk - accumulated);
      keepAmount = Math.min(amt, availableRoom);
      sentAmount = amt - keepAmount;

      if (rule.status === 'อั้นจ่าย') {
        alertType = 'yellow';
        alertMessage = 'เลขอั้นจ่าย! อัตราจ่ายพิเศษ ' + rule.payoutRate + ' บ.';
      } else if (newTotal > rule.maxRisk) {
        alertType = 'yellow';
        alertMessage = 'เกินเพดานความเสี่ยง! ตีเกินส่งต่อ ' + sentAmount.toLocaleString() + ' บ.';
      } else {
        alertType = 'green';
        alertMessage = 'ปกติ บันทึกได้ตามเพดานความเสี่ยง';
      }

      return {
        rule,
        status,
        payoutRate: rule.payoutRate,
        maxRisk: rule.maxRisk,
        canAccept: true,
        alertType,
        alertMessage,
        keepAmount,
        sentAmount
      };
    }

    function updateUI() {
      const numElem = document.getElementById('displayNumber');
      const amtElem = document.getElementById('displayAmount');
      numElem.innerText = currentNumber || '-';
      amtElem.innerText = currentAmount ? Number(currentAmount).toLocaleString() : '0';

      const maxDigits = currentType.startsWith('3') ? 3 : currentType.startsWith('2') ? 2 : 1;
      document.getElementById('numberDigitLen').innerText = '(' + currentNumber.length + '/' + maxDigits + ' หลัก)';

      validateCurrentInput();
      renderBasketSummary();
    }

    function validateCurrentInput() {
      const amt = Number(currentAmount) || 0;
      const num = currentNumber;
      const statusBadge = document.getElementById('statusBadge');
      const validationText = document.getElementById('validationText');
      const payoutDisplay = document.getElementById('payoutRateDisplay');
      const btnAdd = document.getElementById('btnAddItem');
      const maxDigits = currentType.startsWith('3') ? 3 : currentType.startsWith('2') ? 2 : 1;

      // Incomplete digits check:
      if (num.length < maxDigits) {
        if (num.length === 0) {
          statusBadge.className = 'badge-status badge-green';
          statusBadge.innerHTML = '<i class="bi bi-info-circle me-1"></i>รอระบุเลข';
          validationText.innerText = 'ใส่ตัวเลข ' + maxDigits + ' หลัก (เช่น ' + (maxDigits === 2 ? '0x, x0' : '0xx, x0x, xx0, 0x0') + ')';
        } else {
          statusBadge.className = 'badge-status badge-yellow';
          statusBadge.innerHTML = '<i class="bi bi-exclamation-circle me-1"></i>รอครบ ' + maxDigits + ' หลัก (' + num.length + '/' + maxDigits + ')';
          validationText.innerText = maxDigits === 2 ? 'เลข 2 ตัวห้ามใส่หลักเดียว ต้องใส่ 2 หลัก เช่น 0x หรือ x0 (เช่น 0' + num + ' หรือ ' + num + '0)' : 'เลข 3 ตัวต้องใส่ 3 หลัก เช่น 0xx, x0x, xx0, 0x0';
        }
        const defaultRule = configs.find(c => c.type === currentType && c.number === '*') || { payoutRate: 90 };
        payoutDisplay.innerText = defaultRule.payoutRate;
        btnAdd.disabled = true;
        btnAdd.className = 'btn btn-secondary w-100 py-3 fw-bold fs-6 rounded-4 shadow-sm disabled text-white-50';
        btnAdd.innerHTML = '<i class="bi bi-dash-circle me-1"></i><span>ต้องใส่ให้ครบ ' + maxDigits + ' หลัก (' + (num.length === 0 ? (maxDigits === 2 ? 'เช่น 0x หรือ x0' : 'เช่น 0xx') : (maxDigits === 2 ? 'เช่น 0' + num + ' หรือ ' + num + '0' : 'เช่น 0' + num)) + ')</span>';
        return;
      }

      const val = evaluateRisk(currentType, num, amt);
      payoutDisplay.innerText = val.payoutRate;

      if (val.alertType === 'red' || !val.canAccept) {
        statusBadge.className = 'badge-status badge-red';
        statusBadge.innerHTML = '<i class="bi bi-x-circle-fill me-1"></i>ปิดรับ';
        validationText.innerText = val.alertMessage;
        btnAdd.disabled = true;
        btnAdd.className = 'btn btn-danger w-100 py-3 fw-bold fs-5 rounded-4 shadow-lg disabled';
        btnAdd.innerHTML = '<i class="bi bi-slash-circle me-1"></i><span>เลขปิดรับ (ไม่สามารถรับได้)</span>';
      } else if (val.alertType === 'yellow') {
        statusBadge.className = 'badge-status badge-yellow';
        statusBadge.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-1"></i>' + val.status;
        validationText.innerText = val.alertMessage;
        btnAdd.disabled = false;
        btnAdd.className = 'btn btn-warning w-100 py-3 fw-bold fs-5 rounded-4 shadow-lg text-dark';
        btnAdd.innerHTML = '<i class="bi bi-plus-circle-fill me-1"></i><span>เพิ่มลงตะกร้า (อั้นจ่าย/ส่งต่อ)</span>';
      } else {
        statusBadge.className = 'badge-status badge-green';
        statusBadge.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i>ปกติ';
        validationText.innerText = val.alertMessage;
        btnAdd.disabled = false;
        btnAdd.className = 'btn btn-success w-100 py-3 fw-bold fs-5 rounded-4 shadow-lg';
        btnAdd.innerHTML = '<i class="bi bi-plus-circle-fill"></i><span>เพิ่มลงตะกร้า</span>';
      }
    }

    function handleAddToBasket() {
      const amt = Number(currentAmount) || 0;
      const maxDigits = currentType.startsWith('3') ? 3 : currentType.startsWith('2') ? 2 : 1;

      if (!currentNumber || currentNumber.length !== maxDigits) {
        if (maxDigits === 2) {
          alert('เลข 2 ตัวไม่สามารถเลือกเพียง 1 ตัวเลขแล้วกดแทงได้! กรุณากรอกให้ครบ 2 หลัก (ถ้าหากแทงเลขที่มี 0 ต้องใส่ 0x หรือ x0 เช่น 05, 50, 00)');
        } else if (maxDigits === 3) {
          alert('เลข 3 ตัวต้องกรอกให้ครบ 3 หลัก (ถ้าหากแทงเลขที่มี 0 ต้องใส่ 0xx, x0x, xx0, 0x0 หรือ 00x เช่น 058, 508, 580)');
        } else {
          alert('กรุณากรอกตัวเลขให้ครบ ' + maxDigits + ' หลัก');
        }
        activeField = 'number';
        updateUI();
        return;
      }

      if (amt <= 0) {
        alert('กรุณาระบุจำนวนเงิน');
        activeField = 'amount';
        updateUI();
        return;
      }

      const val = evaluateRisk(currentType, currentNumber, amt);

      if (!val.canAccept || val.status === 'ปิดรับ') {
        alert('ขออภัย เลขนี้ปิดรับแทง');
        return;
      }
      if (amt <= 0) {
        alert('กรุณาระบุจำนวนเงิน');
        activeField = 'amount';
        updateUI();
        return;
      }

      const val = evaluateRisk(currentType, currentNumber, amt);

      if (!val.canAccept || val.status === 'ปิดรับ') {
        alert('ขออภัย เลขนี้ปิดรับแทง');
        return;
      }

      if (val.status === 'อั้นจ่าย') {
        const defaultRule = configs.find(c => c.type === currentType && c.number === '*') || { payoutRate: 90 };
        document.getElementById('halfPayModalNum').innerText = currentType + ' : ' + currentNumber;
        document.getElementById('halfPayModalNormalRate').innerText = defaultRule.payoutRate + ' บาท';
        document.getElementById('halfPayModalSpecialRate').innerText = val.payoutRate + ' บาท';
        
        pendingHalfPayAction = () => {
          pushBasketItem(val);
          halfPayModal.hide();
        };

        document.getElementById('btnConfirmHalfPay').onclick = pendingHalfPayAction;
        halfPayModal.show();
        return;
      }

      pushBasketItem(val);
    }

    function pushBasketItem(val) {
      basket.push({
        id: Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        type: currentType,
        number: currentNumber,
        amount: Number(currentAmount),
        payoutRate: val.payoutRate,
        status: val.status,
        sentAmount: val.sentAmount,
        keepAmount: val.keepAmount
      });

      currentNumber = '';
      activeField = 'number';
      updateUI();
      renderBasket();
    }

    function removeItem(id) {
      basket = basket.filter(b => b.id !== id);
      renderBasket();
      updateUI();
    }

    function clearBasket() {
      if (!basket.length) return;
      basket = [];
      renderBasket();
      updateUI();
    }

    function renderBasket() {
      const listElem = document.getElementById('basketItemList');
      if (!basket.length) {
        listElem.innerHTML = '<div class="text-center text-muted py-5"><i class="bi bi-cart-x fs-1 d-block mb-2"></i>ยังไม่มีรายการในตะกร้า</div>';
        renderBasketSummary();
        return;
      }

      let html = '';
      basket.forEach((item, idx) => {
        const badgeClass = item.status === 'ปกติ' ? 'badge-green' : 'badge-yellow';
        html += '<div class="basket-item d-flex align-items-center justify-content-between">' +
          '<div>' +
            '<div class="d-flex align-items-center gap-2">' +
              '<span class="badge bg-secondary" style="font-size:0.75rem;">#' + (idx + 1) + '</span>' +
              '<span class="badge-status ' + badgeClass + '">' + item.status + '</span>' +
              '<strong class="text-light">' + item.type + '</strong>' +
              '<span class="fs-5 fw-bold text-warning mono-num">' + item.number + '</span>' +
            '</div>' +
            '<div class="text-secondary mt-1" style="font-size:0.75rem;">' +
              'ถือเอง: <span class="text-success fw-bold mono-num">฿' + item.keepAmount.toLocaleString() + '</span>' +
              (item.sentAmount > 0 ? ' | ส่งต่อ: <span class="text-danger fw-bold mono-num">฿' + item.sentAmount.toLocaleString() + '</span>' : '') +
              ' | จ่าย: <span class="mono-num">' + item.payoutRate + '</span> บ.' +
            '</div>' +
          '</div>' +
          '<div class="d-flex align-items-center gap-2">' +
            '<span class="fs-5 fw-bold text-light mono-num">฿' + item.amount.toLocaleString() + '</span>' +
            '<button class="btn btn-sm btn-outline-danger p-1" onclick="removeItem(\\'' + item.id + '\\')">' +
              '<i class="bi bi-trash"></i>' +
            '</button>' +
          '</div>' +
        '</div>';
      });

      listElem.innerHTML = html;
      renderBasketSummary();
    }

    function renderBasketSummary() {
      const count = basket.length;
      const total = basket.reduce((s, b) => s + b.amount, 0);
      const totalKeep = basket.reduce((s, b) => s + b.keepAmount, 0);
      const totalSent = basket.reduce((s, b) => s + b.sentAmount, 0);

      document.getElementById('bottomItemCount').innerText = count;
      document.getElementById('bottomTotalAmount').innerText = '฿' + total.toLocaleString();

      document.getElementById('canvasItemCount').innerText = count;
      document.getElementById('canvasSummaryTotal').innerText = '฿' + total.toLocaleString();
      document.getElementById('canvasSummaryKeep').innerText = '฿' + totalKeep.toLocaleString();
      document.getElementById('canvasSummarySent').innerText = '฿' + totalSent.toLocaleString();

      const badge = document.getElementById('basketBadgeCount');
      if (count > 0) {
        badge.style.display = 'inline-block';
        badge.innerText = count;
      } else {
        badge.style.display = 'none';
      }
    }

    function confirmSaveBill() {
      if (!basket.length) {
        alert('กรุณาเพิ่มรายการลงในตะกร้าก่อนบันทึกบิล');
        return;
      }

      const customerName = document.getElementById('customerNameInput').value.trim() || 'ลูกค้าทั่วไป';
      const payload = {
        billId: billId,
        customerName: customerName,
        items: basket.map(b => ({
          type: b.type,
          number: b.number,
          amount: b.amount,
          status: b.status,
          sentAmount: b.sentAmount,
          keepAmount: b.keepAmount
        }))
      };

      const btnSave = document.getElementById('btnConfirmSave');
      btnSave.disabled = true;
      btnSave.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>กำลังบันทึก...';

      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler((res) => {
            btnSave.disabled = false;
            btnSave.innerHTML = '<i class="bi bi-cloud-arrow-up-fill me-1"></i>ยืนยันบันทึกบิล';
            if (res && res.success) {
              alert('บันทึกบิล ' + res.billId + ' ลง Google Sheets เรียบร้อยแล้ว!');
              basket.forEach(b => {
                const k = b.type + '_' + b.number;
                riskAccumulation[k] = (riskAccumulation[k] || 0) + b.amount;
              });
              basket = [];
              renderBasket();
              refreshSettings();
              const offcanvas = bootstrap.Offcanvas.getInstance(document.getElementById('basketOffcanvas'));
              if (offcanvas) offcanvas.hide();
            } else {
              alert('เกิดข้อผิดพลาด: ' + (res.error || 'ไม่สามารถบันทึกได้'));
            }
          })
          .withFailureHandler((err) => {
            btnSave.disabled = false;
            btnSave.innerHTML = '<i class="bi bi-cloud-arrow-up-fill me-1"></i>ยืนยันบันทึกบิล';
            alert('การเชื่อมต่อล้มเหลว: ' + err);
          })
          .saveTransactions(payload);
      } else {
        setTimeout(() => {
          btnSave.disabled = false;
          btnSave.innerHTML = '<i class="bi bi-cloud-arrow-up-fill me-1"></i>ยืนยันบันทึกบิล';
          alert('บันทึกบิล ' + billId + ' สำเร็จ! (โหมดทดสอบในเบราว์เซอร์)');
          basket.forEach(b => {
            const k = b.type + '_' + b.number;
            riskAccumulation[k] = (riskAccumulation[k] || 0) + b.amount;
          });
          basket = [];
          renderBasket();
          updateUI();
          const offcanvas = bootstrap.Offcanvas.getInstance(document.getElementById('basketOffcanvas'));
          if (offcanvas) offcanvas.hide();
        }, 600);
      }
    }
  </script>
</body>
</html>`;
