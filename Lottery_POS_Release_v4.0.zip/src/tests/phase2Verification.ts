import assert from 'node:assert/strict';
import {
  normalizeLotteryNumber,
  isValidLotteryNumber,
  getPermutations,
  reverseNumber,
  nineteenDoors,
  swipeFront,
  swipeBack,
  findConfigRule,
  getTransactionPayoutRate,
  evaluateNumberRisk,
  reconcileTransactionsRisk,
  calculateSummaryRisk,
  calculateProfitSummaryMetrics,
  calculateUnifiedAccountingSummary,
  parseFastBetText,
} from '../utils/lotteryLogic';
import { INITIAL_CONFIG_SETTINGS, INITIAL_TRANSACTIONS } from '../data/initialData';
import { ConfigRule, Transaction } from '../types/lottery';

console.log('=== RUNNING PHASE 2 AUTOMATED VERIFICATION TESTS ===');

// 1. Test 00-99 and 000-999 leading zeros & String formatting
for (let i = 0; i <= 99; i++) {
  const s = normalizeLotteryNumber(String(i), '2ตัวบน');
  assert.equal(s.length, 2, `2-digit padding failed for ${i}`);
  assert.equal(isValidLotteryNumber(s, '2ตัวบน'), true, `2-digit validation failed for ${s}`);
}
for (let i = 0; i <= 999; i++) {
  const s = normalizeLotteryNumber(String(i), '3ตัวตรง');
  assert.equal(s.length, 3, `3-digit padding failed for ${i}`);
  assert.equal(isValidLotteryNumber(s, '3ตัวตรง'), true, `3-digit validation failed for ${s}`);
}
console.log('[PASS] 1. เลข 00-99 และ 000-999 เก็บเป็น String และรองรับเลขศูนย์นำหน้าครบ 1,100 กรณี');

// 2. Test Permutations (กลับเลข / โต๊ด ไม่ซ้ำ)
assert.deepEqual(reverseNumber('05'), ['05', '50']);
assert.deepEqual(reverseNumber('00'), ['00']); // เลขเบิ้ลไม่ซ้ำ
assert.equal(getPermutations('012').length, 6); // 3 ตัวไม่ซ้ำ = 6 ประตู
assert.equal(getPermutations('010').length, 3); // เลขหาม = 3 ประตู
assert.equal(getPermutations('000').length, 1); // เลขตอง = 1 ประตู
assert.equal(nineteenDoors('0').length, 19); // 19 ประตู
assert.equal(new Set(nineteenDoors('0')).size, 19); // ไม่ซ้ำ
assert.equal(swipeFront('0').length, 10);
assert.equal(swipeBack('0').length, 10);
console.log('[PASS] 2. เลขกลับ, 3ตัวโต๊ด, 19 ประตู, รูดหน้า, รูดหลัง คำนวณ Permutation ไม่ซ้ำ');

// 3. Test Historical Payout Rate Snapshot (BUG-01 Fix)
const baseConfigs: ConfigRule[] = [
  { type: '2ตัวบน', number: '*', payoutRate: 90, maxRisk: 2000, status: 'ปกติ' },
];
const morningTx: Transaction = {
  id: 'TX_1',
  timestamp: '2026-11-01 10:00:00',
  billId: 'B001',
  customerName: 'ลูกค้าเช้า',
  type: '2ตัวบน',
  number: '38',
  amount: 500,
  payoutRate: 90, // รับตอนเช้าที่เรท 90
  status: 'ปกติ',
  keepAmount: 500,
  sentAmount: 0,
};
// ตอนบ่ายเจ้ามือเปลี่ยนเลข 38 เป็นอั้นจ่าย 45 บาท
const afternoonConfigs: ConfigRule[] = [
  ...baseConfigs,
  { type: '2ตัวบน', number: '38', payoutRate: 45, maxRisk: 2000, status: 'อั้นจ่าย' },
];
const afternoonTx: Transaction = {
  id: 'TX_2',
  timestamp: '2026-11-01 14:00:00',
  billId: 'B002',
  customerName: 'ลูกค้าบ่าย',
  type: '2ตัวบน',
  number: '38',
  amount: 500,
  payoutRate: 45, // รับตอนบ่ายที่เรท 45
  status: 'อั้นจ่าย',
  keepAmount: 500,
  sentAmount: 0,
};

assert.equal(getTransactionPayoutRate(morningTx, afternoonConfigs), 90, 'บิลเช้าต้องคงเรท 90 บาท');
assert.equal(getTransactionPayoutRate(afternoonTx, afternoonConfigs), 45, 'บิลบ่ายต้องได้เรท 45 บาท');

const riskCombined = calculateSummaryRisk([morningTx, afternoonTx], afternoonConfigs);
const r38 = riskCombined.find((r) => r.number === '38')!;
// ยอดจ่ายรางวัลหากเลข 38 ออก ต้องเท่ากับ (500 * 90) + (500 * 45) = 45,000 + 22,500 = 67,500 บาท
assert.equal(r38.potentialPayout, 67500, 'Potential payout ต้องคำนวณตามเรท ณ เวลารับบิลแต่ละใบ');
console.log('[PASS] 3. ใช้อัตราจ่าย ณ เวลารับรายการ (Historical Payout Rate Snapshot) แม่นยำ 100%');

// 4. Test Closed Status ('ปิดรับ') Exclusion (BUG-02 Fix)
const summaryInitial = calculateSummaryRisk(INITIAL_TRANSACTIONS, INITIAL_CONFIG_SETTINGS);
const r999 = summaryInitial.find((r) => r.number === '999')!;
assert.equal(r999.keepAmount, 0, 'เลขปิดรับต้องไม่มี keepAmount');
assert.equal(r999.potentialPayout, 0, 'เลขปิดรับต้องไม่มี potentialPayout');

const profitMetrics = calculateProfitSummaryMetrics(INITIAL_TRANSACTIONS, summaryInitial);
const unifiedAcc = calculateUnifiedAccountingSummary(INITIAL_TRANSACTIONS);
assert.equal(
  profitMetrics.totalGrossSales,
  profitMetrics.totalKeepHeld + profitMetrics.totalSentOut,
  'Gross Sales ต้องเท่ากับ Keep + Sent เสมอ (ไม่รวมรายการปิดรับ)'
);
assert.equal(unifiedAcc.totalGrossSales, profitMetrics.totalGrossSales);
assert.equal(unifiedAcc.totalKeepAmount, profitMetrics.totalKeepHeld);
assert.equal(unifiedAcc.totalSentAmount, profitMetrics.totalSentOut);
console.log('[PASS] 4. รายการสถานะ ปิดรับ ไม่ถูกนำไปคิดเป็นยอดขายหรือรางวัล และยอด POS/Risk/Settlement/Accounting ตรงกัน 100%');

// 5. Test Risk Reconciliation when Deleting/Voiding a Bill (BUG-03 Fix)
const capConfigs: ConfigRule[] = [
  { type: '2ตัวบน', number: '*', payoutRate: 90, maxRisk: 2000, status: 'ปกติ' },
];
const bill1Tx: Transaction = {
  id: 'TX_B1',
  timestamp: '2026-11-01 10:00:00',
  billId: 'B001',
  customerName: 'นาย A',
  type: '2ตัวบน',
  number: '55',
  amount: 1500,
  payoutRate: 90,
  status: 'ปกติ',
  keepAmount: 1500,
  sentAmount: 0,
};
const bill2Tx: Transaction = {
  id: 'TX_B2',
  timestamp: '2026-11-01 10:05:00',
  billId: 'B002',
  customerName: 'นาย B',
  type: '2ตัวบน',
  number: '55',
  amount: 1200,
  payoutRate: 90,
  status: 'ปกติ',
  keepAmount: 500,
  sentAmount: 700,
};
// หากยกเลิกบิล B001 บิล B002 ที่เหลือยอด 1,200 บาท ต้องถูกดึงกลับมาเป็น keepAmount = 1,200 และ sentAmount = 0
const afterDeleteB1 = reconcileTransactionsRisk([bill2Tx], capConfigs);
assert.equal(afterDeleteB1[0].keepAmount, 1200);
assert.equal(afterDeleteB1[0].sentAmount, 0);
console.log('[PASS] 5. เมื่อยกเลิก/ลบบิล ระบบเกลี่ยยอด Keep / Sent ของบิลถัดมาใหม่ตามลำดับเวลาอย่างถูกต้อง');

// 6. Test Fast Bet Parser (BUG-06 Fix)
const parsed = parseFastBetText('05 = 100x50\n45 บน 200\n538 โต๊ด 100\n38 = 100 กลับ');
assert.equal(parsed.every((p) => p.isValid), true);
assert.equal(parsed.length, 6); // 05(บน,ล่าง) + 45(บน) + 538(โต๊ด) + 38,83(บน) = 6 รายการ
console.log('[PASS] 6. ระบบแปลงโพยด่วน (parseFastBetText) รองรับทั้งรูปแบบมาตรฐานและคำไทยครบถ้วน');

console.log('=== ALL PHASE 2 VERIFICATION TESTS PASSED SUCCESSFULLY ===');
