import fs from 'fs';
import path from 'path';
import { LotteryServerEngine } from '../server/dbService';
import {
  normalizeLotteryNumber,
  isValidLotteryNumber,
  getPermutations,
  reverseNumber,
  nineteenDoors,
  swipeFront,
  swipeBack,
  calculateSummaryRisk,
  calculateProfitSummaryMetrics,
  calculateUnifiedAccountingSummary,
  getTransactionPayoutRate,
  parseFastBetText,
  computeDataChecksum,
  validateSystemDataIntegrity,
  verifySystemBackupPayload,
} from '../utils/lotteryLogic';
import {
  getOfflineQueue,
  saveOfflineQueue,
  enqueueOfflineAction,
} from '../utils/apiClient';

function assert(condition: boolean, message: string): void {
  if (!condition) {
    throw new Error(`❌ QA ASSERTION FAILED: ${message}`);
  }
}

async function runMasterQA() {
  console.log('======================================================================');
  console.log('🛡️  STARTING PHASE 6: MASTER QA & EDGE-CASE STRESS TEST (MODULES 1–16)');
  console.log('======================================================================');

  const tempDbPath = path.resolve(process.cwd(), 'data', `test_phase6_qa_${Date.now()}.json`);
  const engine = new LotteryServerEngine(tempDbPath);

  try {
    // =========================================================================
    // QA-01: Core Calculation, 00-99 & 000-999 Leading Zeros, Permutations
    // =========================================================================
    console.log('\n[QA-01] Testing 00–99 (100), 000–999 (1,000), Reverse, Tod & Shortcuts...');

    for (let i = 0; i <= 99; i++) {
      const expected = String(i).padStart(2, '0');
      const norm = normalizeLotteryNumber(expected, '2ตัวบน');
      assert(norm === expected && typeof norm === 'string', `2-digit ${expected} failed`);
      assert(isValidLotteryNumber(norm, '2ตัวบน'), `isValid 2-digit ${expected} failed`);
    }

    for (let i = 0; i <= 999; i++) {
      const expected = String(i).padStart(3, '0');
      const norm = normalizeLotteryNumber(expected, '3ตัวตรง');
      assert(norm === expected && typeof norm === 'string', `3-digit ${expected} failed`);
      assert(isValidLotteryNumber(norm, '3ตัวตรง'), `isValid 3-digit ${expected} failed`);
    }

    // Permutations & Reverse uniqueness
    assert(reverseNumber('05').join(',') === '05,50', 'reverseNumber(05) must be 05,50');
    assert(reverseNumber('77').join(',') === '77', 'reverseNumber(77) must not duplicate');
    assert(getPermutations('538').length === 6, '538 must have 6 unique permutations');
    assert(getPermutations('050').length === 3, '050 must have 3 unique permutations');
    assert(getPermutations('000').length === 1, '000 must have 1 unique permutation');
    assert(new Set(nineteenDoors('0')).size === 19, '19 doors for 0 must have 19 unique numbers');
    assert(new Set(swipeFront('0')).size === 10, 'swipeFront(0) must have 10 unique numbers (00-09)');
    assert(new Set(swipeBack('0')).size === 10, 'swipeBack(0) must have 10 unique numbers (00-90)');

    // Fast Bet LINE/SMS parser edge cases
    const parsedFast = parseFastBetText('05 = 100x50 กลับ\n007 โต๊ด 200\n99 บน 0');
    const validFast = parsedFast.filter((p) => p.isValid);
    const invalidFast = parsedFast.filter((p) => !p.isValid);
    assert(validFast.length === 5, '05=100x50 กลับ (4 items) + 007 โต๊ด 200 (1 item) = 5 valid items');
    assert(invalidFast.length === 1, '99 บน 0 must be marked invalid (amount <= 0)');

    console.log('  ✅ QA-01 Passed (1,110 number formats + permutations + LINE parser).');

    // =========================================================================
    // QA-02: High-Concurrency Stress Test (25 Simultaneous Bills + 5 Duplicates)
    // =========================================================================
    console.log('\n[QA-02] Running High-Concurrency Stress Test (25 simultaneous bills + 5 duplicate retries)...');

    // Number '45' in '2ตัวล่าง' has maxRisk = 20,000.
    // 25 concurrent bills x 2,000 = 50,000 total.
    // Plus 5 duplicate retries reusing idempotencyKeys 1..5.
    const stressJobs: Promise<Awaited<ReturnType<typeof engine.createBill>>>[] = [];
    for (let i = 1; i <= 25; i++) {
      stressJobs.push(
        engine.createBill({
          idempotencyKey: `STRESS_IDEM_45_${i}`,
          customerName: `ลูกค้า Stress #${i}`,
          discountPercent: 10,
          items: [{ type: '2ตัวล่าง', number: '45', amount: 2000 }],
        })
      );
    }
    // 5 concurrent duplicate retries
    for (let d = 1; d <= 5; d++) {
      stressJobs.push(
        engine.createBill({
          idempotencyKey: `STRESS_IDEM_45_${d}`,
          customerName: `ลูกค้า Stress #${d}`,
          discountPercent: 10,
          items: [{ type: '2ตัวล่าง', number: '45', amount: 2000 }],
        })
      );
    }

    const stressResults = await Promise.all(stressJobs);
    const createdCount = stressResults.filter((r) => r.success && !r.duplicate).length;
    const duplicateCount = stressResults.filter((r) => r.success && r.duplicate).length;

    assert(createdCount === 25, `Expected 25 unique bills created, got ${createdCount}`);
    assert(duplicateCount === 5, `Expected 5 duplicate retries blocked, got ${duplicateCount}`);

    const snapAfterStress = engine.getStateSnapshot();
    const rows45 = snapAfterStress.state.transactions.filter(
      (t) => t.type === '2ตัวล่าง' && t.number === '45'
    );
    const sum45Amount = rows45.reduce((s, t) => s + t.amount, 0);
    const sum45Keep = rows45.reduce((s, t) => s + t.keepAmount, 0);
    const sum45Sent = rows45.reduce((s, t) => s + t.sentAmount, 0);

    assert(rows45.length === 25, 'Exactly 25 transaction rows for 2ตัวล่าง 45 must exist');
    assert(sum45Amount === 50000, `Total amount for 45 must be 50,000 (got ${sum45Amount})`);
    assert(sum45Keep === 20000, `Keep amount for 45 must be capped at 20,000 (got ${sum45Keep})`);
    assert(sum45Sent === 30000, `Sent amount for 45 must be 30,000 (got ${sum45Sent})`);

    console.log('  ✅ QA-02 Passed (25 concurrent writes + 5 duplicate retries serialized with 0 race conditions).');

    // =========================================================================
    // QA-03: Full Lifecycle (Edit Bill, Cancel Bill, Historical Payout & Lock)
    // =========================================================================
    console.log('\n[QA-03] Testing Bill Edit, Cancellation, Historical Payout Snapshot & Period Lock...');

    // Create a bill on '08' (2ตัวบน, default rate 90, maxRisk 20,000)
    const bill08A = await engine.createBill({
      idempotencyKey: 'QA03_BILL_08_A',
      customerName: 'เฮียชัย VIP',
      discountPercent: 10,
      items: [{ type: '2ตัวบน', number: '08', amount: 15000 }],
    });
    assert(bill08A.success && Boolean(bill08A.billId), 'Bill 08 A must succeed');

    // Now admin changes '2ตัวบน' '08' to Half-Pay (rate 45, maxRisk 18,000)
    await engine.updateConfigs({
      action: 'upsert',
      rule: {
        type: '2ตัวบน',
        number: '08',
        payoutRate: 45,
        maxRisk: 18000,
        status: 'อั้นจ่าย',
      },
    });

    // Create a second bill on '08' for 5,000 -> should get rate 45, keep 3,000, sent 2,000
    const bill08B = await engine.createBill({
      idempotencyKey: 'QA03_BILL_08_B',
      customerName: 'เจ๊พร สายใต้',
      discountPercent: 12,
      items: [{ type: '2ตัวบน', number: '08', amount: 5000 }],
    });
    assert(bill08B.success && Boolean(bill08B.billId), 'Bill 08 B must succeed');

    const stateAfter08B = engine.getStateSnapshot().state;
    const tx08A = stateAfter08B.transactions.find((t) => t.billId === bill08A.billId)!;
    const tx08B = stateAfter08B.transactions.find((t) => t.billId === bill08B.billId)!;

    assert(
      getTransactionPayoutRate(tx08A, stateAfter08B.configs) === 90,
      'Bill 08 A must preserve historical payoutRate 90 even after config changed to 45'
    );
    assert(
      getTransactionPayoutRate(tx08B, stateAfter08B.configs) === 45,
      'Bill 08 B must use the new payoutRate 45 active when it was received'
    );
    assert(
      tx08B.keepAmount === 3000 && tx08B.sentAmount === 2000,
      'Bill 08 B must split keep=3,000 and sent=2,000 against updated 18,000 ceiling'
    );

    // Edit Bill 08 A from 15,000 down to 10,000 -> Bill 08 B should now keep all 5,000 (sent=0)!
    const edit08A = await engine.editBill({
      billId: bill08A.billId!,
      customerName: 'เฮียชัย VIP',
      discountPercent: 10,
      items: [{ originalIndex: 0, type: '2ตัวบน', number: '08', amount: 10000 }],
    });
    assert(edit08A.success, 'Editing Bill 08 A must succeed');

    const tx08BAfterEdit = engine
      .getStateSnapshot()
      .state.transactions.find((t) => t.billId === bill08B.billId)!;
    assert(
      tx08BAfterEdit.keepAmount === 5000 && tx08BAfterEdit.sentAmount === 0,
      'After reducing Bill 08 A to 10,000, Bill 08 B must automatically absorb freed risk (keep=5,000, sent=0)'
    );

    // Lock the period and verify all mutations (create, edit, delete) are blocked
    await engine.syncMetadata({ isPeriodLocked: true });
    const blockedCreate = await engine.createBill({
      idempotencyKey: 'QA03_BLOCKED_CREATE',
      customerName: 'ทดสอบล็อกงวด',
      items: [{ type: '2ตัวบน', number: '08', amount: 100 }],
    });
    const blockedEdit = await engine.editBill({
      billId: bill08A.billId!,
      customerName: 'เฮียชัย VIP',
      discountPercent: 10,
      items: [{ originalIndex: 0, type: '2ตัวบน', number: '08', amount: 5000 }],
    });
    const blockedDelete = await engine.deleteBill(bill08A.billId!);
    assert(
      !blockedCreate.success && !blockedEdit.success && !blockedDelete.success,
      'Locked period must strictly block createBill, editBill, and deleteBill'
    );
    await engine.syncMetadata({ isPeriodLocked: false });

    console.log('  ✅ QA-03 Passed (Historical Payout Rate, Dynamic Risk Re-allocation & Period Lock).');

    // =========================================================================
    // QA-04: Cross-Module Accounting, Risk Summary & Integrity Checksum
    // =========================================================================
    console.log('\n[QA-04] Verifying Cross-Module Accounting, Risk Summary & Integrity Checksum...');

    const finalSnap = engine.getStateSnapshot();
    const summaryRisks = calculateSummaryRisk(
      finalSnap.state.transactions,
      finalSnap.state.configs
    );
    const profitMetrics = calculateProfitSummaryMetrics(
      finalSnap.state.transactions,
      summaryRisks
    );
    const accounting = calculateUnifiedAccountingSummary(finalSnap.state.transactions);

    assert(finalSnap.integrity.isValid === true, 'Database integrity report must be 100% valid');
    assert(
      profitMetrics.totalGrossSales === accounting.totalGrossSales &&
        profitMetrics.totalKeepHeld === accounting.totalKeepAmount &&
        profitMetrics.totalSentOut === accounting.totalSentAmount,
      'POS, Risk Summary, Profit Metrics, and Unified Accounting must match 100%'
    );

    console.log('  ✅ QA-04 Passed (POS ↔ Risk ↔ Profit ↔ Accounting 100% reconciled).');

    // =========================================================================
    // QA-05: Offline Queue Fallback & Network Recovery Simulation
    // =========================================================================
    console.log('\n[QA-05] Testing Network Disconnection & Offline Queue Recovery...');

    // Mock localStorage in Node environment for Offline Queue testing
    const memoryStorage = new Map<string, string>();
    (globalThis as unknown as { window: unknown }).window = {
      localStorage: {
        getItem: (k: string) => memoryStorage.get(k) ?? null,
        setItem: (k: string, v: string) => memoryStorage.set(k, v),
        removeItem: (k: string) => memoryStorage.delete(k),
      },
    };

    saveOfflineQueue([]);
    assert(getOfflineQueue().length === 0, 'Offline queue must start empty');

    // Enqueue an offline bill action (simulating network outage)
    const offlineBillPayload = {
      idempotencyKey: 'OFFLINE_IDEM_BILL_99',
      customerName: 'ลูกค้าขณะเน็ตหลุด',
      discountPercent: 5,
      items: [{ type: '3ตัวตรง', number: '042', amount: 300 }],
    };
    enqueueOfflineAction({
      idempotencyKey: offlineBillPayload.idempotencyKey,
      endpoint: '/api/bills',
      method: 'POST',
      payload: offlineBillPayload,
    });
    // Attempting to enqueue the same idempotencyKey again must deduplicate in the queue
    enqueueOfflineAction({
      idempotencyKey: offlineBillPayload.idempotencyKey,
      endpoint: '/api/bills',
      method: 'POST',
      payload: offlineBillPayload,
    });

    const queuedNow = getOfflineQueue();
    assert(queuedNow.length === 1, 'Offline queue must deduplicate identical idempotencyKey entries');

    // Simulate network recovery by replaying the queued payload into the server engine
    const replayRes = await engine.createBill(
      queuedNow[0].payload as Parameters<typeof engine.createBill>[0]
    );
    assert(replayRes.success === true, 'Queued offline bill must commit cleanly when connection restores');
    saveOfflineQueue([]);
    assert(getOfflineQueue().length === 0, 'Offline queue must clear after successful flush');

    console.log('  ✅ QA-05 Passed (Offline Queue fallback, deduplication & recovery verified).');

    // =========================================================================
    // QA-06: Live Express Server HTTP API Integration Check (Port 3000)
    // =========================================================================
    console.log('\n[QA-06] Verifying Live Express HTTP API Endpoints on Port 3000...');

    const stateHttpRes = await fetch('http://localhost:3000/api/state');
    assert(stateHttpRes.ok, 'GET http://localhost:3000/api/state must return HTTP 200');
    const stateJson = (await stateHttpRes.json()) as {
      success: boolean;
      integrity: { isValid: boolean; checksum: string };
    };
    assert(
      stateJson.success === true && stateJson.integrity.isValid === true,
      'Live /api/state endpoint must return valid integrity report'
    );

    const backupHttpRes = await fetch('http://localhost:3000/api/backup');
    assert(backupHttpRes.ok, 'GET http://localhost:3000/api/backup must return HTTP 200');
    const backupJson = (await backupHttpRes.json()) as {
      success: boolean;
      backup: unknown;
    };
    const backupCheck = verifySystemBackupPayload(backupJson.backup);
    assert(
      backupJson.success === true && backupCheck.isValid === true,
      'Live /api/backup payload must pass Checksum & Data Integrity verification'
    );

    console.log('  ✅ QA-06 Passed (Live HTTP /api/state & /api/backup verified on port 3000).');

    console.log('\n======================================================================');
    console.log('🏆 ALL PHASE 6 MASTER QA & STRESS TESTS PASSED 100% WITH ZERO ERRORS!');
    console.log('======================================================================');
  } finally {
    if (fs.existsSync(tempDbPath)) {
      fs.unlinkSync(tempDbPath);
    }
  }
}

runMasterQA().catch((err) => {
  console.error(err);
  process.exit(1);
});
