import assert from 'node:assert/strict';
import {
  editBillTransactions,
  calculateUnifiedAccountingSummary,
  calculateSummaryRisk,
} from '../utils/lotteryLogic';
import { INITIAL_CONFIG_SETTINGS, INITIAL_CUSTOMERS } from '../data/initialData';
import { ConfigRule, Transaction } from '../types/lottery';

console.log('=== RUNNING PHASE 3 AUTOMATED VERIFICATION TESTS ===');

// 1. Test Edit Bill (editBillTransactions) & Chronological Risk Re-allocation
const configs: ConfigRule[] = [
  ...INITIAL_CONFIG_SETTINGS,
  { type: '2ตัวบน', number: '45', payoutRate: 90, maxRisk: 1000, status: 'ปกติ' },
];

const initialTxs: Transaction[] = [
  {
    id: 'TX_1',
    timestamp: '2026-11-01 10:00:00',
    billId: 'B001',
    customerName: 'นาย ก',
    discountPercent: 10,
    type: '2ตัวบน',
    number: '45',
    amount: 800,
    payoutRate: 90,
    status: 'ปกติ',
    keepAmount: 800,
    sentAmount: 0,
  },
  {
    id: 'TX_2',
    timestamp: '2026-11-01 10:05:00',
    billId: 'B002',
    customerName: 'นาย ข',
    discountPercent: 12,
    type: '2ตัวบน',
    number: '45',
    amount: 600,
    payoutRate: 90,
    status: 'ปกติ',
    keepAmount: 200,
    sentAmount: 400,
  },
];

// แก้ไขบิล B001 ลดยอดแทงเลข 45 จาก 800 เหลือ 300 บาท และเปลี่ยนส่วนลดเป็น 15%
const editRes = editBillTransactions(
  initialTxs,
  'B001',
  { customerName: 'นาย ก (VIP)', discountPercent: 15 },
  [{ originalIndex: 0, type: '2ตัวบน', number: '45', amount: 300 }],
  configs
);

assert.equal(editRes.success, true, 'การแก้ไขบิล B001 ต้องสำเร็จ');
const updatedB1 = editRes.transactions.find((t) => t.billId === 'B001')!;
const updatedB2 = editRes.transactions.find((t) => t.billId === 'B002')!;

assert.equal(updatedB1.customerName, 'นาย ก (VIP)');
assert.equal(updatedB1.discountPercent, 15);
assert.equal(updatedB1.amount, 300);
assert.equal(updatedB1.keepAmount, 300);
assert.equal(updatedB1.sentAmount, 0);

// บิล B002 ที่ตามมา มียอด 600 บาท เมื่อ B001 ใช้เพดานไปเพียง 300/1,000 บาท บิล B002 ต้องถูกดึงกลับมาถือสู้เองเต็ม 600 บาท!
assert.equal(updatedB2.keepAmount, 600, 'บิล B002 ต้องถูกเกลี่ยยอดกลับมาเป็น keepAmount = 600');
assert.equal(updatedB2.sentAmount, 0, 'บิล B002 ต้องมียอดตีออก sentAmount = 0');
console.log('[PASS] 1. การแก้ไขบิล (Edit Bill) ปรับชื่อลูกค้า ส่วนลด จำนวนเงิน และเกลี่ยยอด Keep/Sent บิลถัดมาอัตโนมัติถูกต้อง');

// 2. Test Blocking Edit to Closed Number ('ปิดรับ')
const editToClosedRes = editBillTransactions(
  editRes.transactions,
  'B001',
  { customerName: 'นาย ก (VIP)', discountPercent: 15 },
  [{ originalIndex: 0, type: '3ตัวตรง', number: '999', amount: 300 }], // 999 is 'ปิดรับ' in INITIAL_CONFIG_SETTINGS
  configs
);
assert.equal(editToClosedRes.success, false, 'ห้ามแก้ไขเปลี่ยนไปเป็นเลขที่อยู่ในสถานะปิดรับ');
console.log('[PASS] 2. บล็อกการแก้ไขบิลไปเป็นเลขที่อยู่ในสถานะปิดรับอย่างถูกต้อง');

// 3. Test Unified Accounting & Discount Calculation after Bill Edit
const acc = calculateUnifiedAccountingSummary(editRes.transactions);
// B001: 300 ลด 15% = ลด 45 สุทธิ 255
// B002: 600 ลด 12% = ลด 72 สุทธิ 528
// รวม Gross = 900, Discount = 117, Net = 783, Keep = 900, Sent = 0
assert.equal(acc.totalGrossSales, 900);
assert.equal(acc.totalDiscountGiven, 117);
assert.equal(acc.totalNetSales, 783);
assert.equal(acc.totalKeepAmount, 900);
assert.equal(acc.totalSentAmount, 0);

const riskSummary = calculateSummaryRisk(editRes.transactions, configs);
const r45 = riskSummary.find((r) => r.number === '45')!;
assert.equal(r45.keepAmount, 900);
assert.equal(r45.overLimitAmount, 0);
console.log('[PASS] 3. ยอดทางบัญชี (Gross, Discount, Net Sales, Keep, Sent) สัมพันธ์กันตรงทุกโมดูลหลังแก้ไขบิล');

// 4. Test Initial Customer Profiles Integrity
assert.equal(INITIAL_CUSTOMERS.length >= 3, true);
assert.equal(INITIAL_CUSTOMERS[0].defaultDiscountPercent, 10);
console.log('[PASS] 4. ข้อมูลทะเบียนลูกค้า (Customer Management) พร้อมส่วนลดเริ่มต้นและวงเงินเครดิตครบถ้วน');

console.log('=== ALL PHASE 3 VERIFICATION TESTS PASSED SUCCESSFULLY ===');
