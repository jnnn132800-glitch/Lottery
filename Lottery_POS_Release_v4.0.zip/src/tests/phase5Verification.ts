import fs from 'fs';
import path from 'path';
import { INITIAL_CONFIG_SETTINGS, INITIAL_TRANSACTIONS } from '../data/initialData';
import {
  calculateSummaryRisk,
  calculateProfitSummaryMetrics,
  calculateUnifiedAccountingSummary,
  getPermutations,
} from '../utils/lotteryLogic';
import { ConfigRule, Transaction } from '../types/lottery';

function assert(condition: boolean, message: string): void {
  if (!condition) {
    throw new Error(`❌ ASSERTION FAILED: ${message}`);
  }
}

function runPhase5Verification() {
  console.log('================================================================');
  console.log('🚀 STARTING PHASE 5 VERIFICATION: DASHBOARD, SIMULATOR & S22 UI');
  console.log('================================================================');

  // ------------------------------------------------------------------
  // SUITE 1: Dashboard & Reporting Cross-Module Consistency (Module 11)
  // ------------------------------------------------------------------
  console.log('\n[Suite 1] Verifying Dashboard & Reporting Cross-Module Consistency...');

  const summaryRisks = calculateSummaryRisk(INITIAL_TRANSACTIONS, INITIAL_CONFIG_SETTINGS);
  const profitMetrics = calculateProfitSummaryMetrics(INITIAL_TRANSACTIONS, summaryRisks);
  const unifiedAccounting = calculateUnifiedAccountingSummary(INITIAL_TRANSACTIONS);

  assert(
    profitMetrics.totalGrossSales === unifiedAccounting.totalGrossSales,
    `Gross sales mismatch: ${profitMetrics.totalGrossSales} vs ${unifiedAccounting.totalGrossSales}`
  );
  assert(
    profitMetrics.totalKeepHeld === unifiedAccounting.totalKeepAmount,
    `Keep amount mismatch: ${profitMetrics.totalKeepHeld} vs ${unifiedAccounting.totalKeepAmount}`
  );
  assert(
    profitMetrics.totalSentOut === unifiedAccounting.totalSentAmount,
    `Sent amount mismatch: ${profitMetrics.totalSentOut} vs ${unifiedAccounting.totalSentAmount}`
  );
  assert(
    unifiedAccounting.totalKeepAmount + unifiedAccounting.totalSentAmount ===
      unifiedAccounting.totalGrossSales,
    'Keep + Sent must equal Gross Sales 100%'
  );

  // Verify Top 5 High-Exposure Leaderboard sorting
  const topExposureItems = [...summaryRisks]
    .filter((r) => r.status !== 'ปิดรับ' || r.keepAmount > 0)
    .sort((a, b) => b.potentialPayout - a.potentialPayout || b.totalAmount - a.totalAmount)
    .slice(0, 5);

  assert(topExposureItems.length > 0 && topExposureItems.length <= 5, 'Top 5 leaderboard must populate');
  for (let i = 1; i < topExposureItems.length; i++) {
    assert(
      topExposureItems[i - 1].potentialPayout >= topExposureItems[i].potentialPayout,
      'Top exposure items must be sorted in descending order of potentialPayout'
    );
  }

  console.log('  ✅ Suite 1 Passed: POS, Risk Summary, Profit Metrics & Accounting match 100%.');

  // ------------------------------------------------------------------
  // SUITE 2: What-If Simulator Historical Payout & 3ตัวโต๊ด Permutation
  // ------------------------------------------------------------------
  console.log('\n[Suite 2] Verifying What-If Simulator Historical Payout & 3ตัวโต๊ด Permutations...');

  const customTx: Transaction[] = [
    {
      id: 'TX_SIM_1',
      timestamp: '2026-11-01 10:00:00',
      billId: 'B001',
      customerName: 'ลูกค้าทดสอบ Simulator',
      type: '3ตัวโต๊ด',
      number: '538',
      amount: 1000,
      payoutRate: 150, // Historical rate at bet time = 150
      status: 'ปกติ',
      keepAmount: 1000,
      sentAmount: 0,
    },
  ];

  // Suppose admin later changes 3ตัวโต๊ด config rate from 150 to 100
  const alteredConfigs: ConfigRule[] = INITIAL_CONFIG_SETTINGS.map((c) =>
    c.type === '3ตัวโต๊ด' && c.number === '*' ? { ...c, payoutRate: 100 } : c
  );

  const customSummary = calculateSummaryRisk(customTx, alteredConfigs);
  // Simulate winning number '853' (a permutation of '538') in '3ตัวโต๊ด'
  const simType = '3ตัวโต๊ด';
  const simNumber = '853';
  const simPerms = new Set(getPermutations(simNumber));
  const matchedItems = customSummary.filter(
    (r) => r.type === simType && simPerms.has(r.number) && (r.status !== 'ปิดรับ' || r.keepAmount > 0)
  );

  assert(matchedItems.length === 1, '3ตัวโต๊ด simulation of 853 must match bet on 538');
  const simTotalPayout = matchedItems.reduce((s, r) => s + r.potentialPayout, 0);
  assert(
    simTotalPayout === 150000,
    `Simulator must use historical payoutRate 150 (expected 150,000, got ${simTotalPayout})`
  );

  console.log('  ✅ Suite 2 Passed: What-If Simulator respects historical payoutRate & 3ตัวโต๊ด permutations.');

  // ------------------------------------------------------------------
  // SUITE 3: Samsung S22 5G Viewport & Frontend Security Audit (Module 13)
  // ------------------------------------------------------------------
  console.log('\n[Suite 3] Verifying Samsung S22 5G Viewport & Frontend Security Boundaries...');

  const appSource = fs.readFileSync(path.resolve(process.cwd(), 'src/App.tsx'), 'utf-8');
  assert(
    appSource.includes('Samsung Galaxy S22 5G') && appSource.includes('360×780'),
    'App.tsx must include Samsung Galaxy S22 5G (360×780) viewport configuration'
  );
  assert(
    !appSource.includes('GAS_API_SECRET') && !appSource.includes('process.env.GAS_API_SECRET'),
    'Frontend App.tsx must never expose server-side GAS_API_SECRET'
  );

  console.log('  ✅ Suite 3 Passed: S22 5G viewport & Frontend security boundary verified.');

  console.log('\n================================================================');
  console.log('🎉 ALL PHASE 5 VERIFICATION SUITES PASSED 100%!');
  console.log('================================================================');
}

runPhase5Verification();
