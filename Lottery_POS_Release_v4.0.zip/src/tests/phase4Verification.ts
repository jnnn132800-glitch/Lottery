import fs from 'fs';
import path from 'path';
import { LotteryServerEngine } from '../server/dbService';
import {
  computeDataChecksum,
  validateSystemDataIntegrity,
  verifySystemBackupPayload,
} from '../utils/lotteryLogic';

function assert(condition: boolean, message: string): void {
  if (!condition) {
    throw new Error(`❌ ASSERTION FAILED: ${message}`);
  }
}

async function runPhase4Verification() {
  console.log('================================================================');
  console.log('🚀 STARTING PHASE 4 VERIFICATION: BACKEND, SYNC, SECURITY & DB');
  console.log('================================================================');

  const tempDbPath = path.resolve(process.cwd(), 'data', `test_phase4_${Date.now()}.json`);
  const engine = new LotteryServerEngine(tempDbPath);

  try {
    // ------------------------------------------------------------------
    // SUITE 1: Server-side Validation & Closed Number / Period Lock Guard
    // ------------------------------------------------------------------
    console.log('\n[Suite 1] Testing Server-side Validation & Closed Number / Period Lock Guard...');

    // 1.1 Missing Idempotency Key
    const resNoIdem = await engine.createBill({
      idempotencyKey: '',
      customerName: 'ทดสอบ',
      items: [{ type: '2ตัวบน', number: '05', amount: 100 }],
    });
    assert(resNoIdem.success === false, 'Server must reject missing idempotencyKey');

    // 1.2 Invalid number format (3 digits for 2ตัวบน)
    const resBadDigits = await engine.createBill({
      idempotencyKey: 'IDEM_TEST_BAD_DIGITS',
      customerName: 'ทดสอบ',
      items: [{ type: '2ตัวบน', number: '123', amount: 100 }],
    });
    assert(resBadDigits.success === false, 'Server must reject 3-digit number for 2ตัวบน');

    // 1.3 Closed number ('999' is 'ปิดรับ' in INITIAL_CONFIG_SETTINGS)
    const resClosedNum = await engine.createBill({
      idempotencyKey: 'IDEM_TEST_CLOSED_999',
      customerName: 'ทดสอบ',
      items: [{ type: '3ตัวตรง', number: '999', amount: 100 }],
    });
    assert(
      resClosedNum.success === false && Boolean(resClosedNum.error?.includes('ปิดรับ')),
      'Server must reject closed number 999 (3ตัวตรง)'
    );

    // 1.4 Period Lock check
    await engine.syncMetadata({ isPeriodLocked: true });
    const resLocked = await engine.createBill({
      idempotencyKey: 'IDEM_TEST_LOCKED',
      customerName: 'ทดสอบ',
      items: [{ type: '2ตัวบน', number: '05', amount: 100 }],
    });
    assert(resLocked.success === false, 'Server must reject bill creation when period is locked');
    await engine.syncMetadata({ isPeriodLocked: false });

    console.log('  ✅ Suite 1 Passed: Server-side validation rejects invalid/closed/locked submissions.');

    // ------------------------------------------------------------------
    // SUITE 2: Idempotency Key Duplicate Submission Protection
    // ------------------------------------------------------------------
    console.log('\n[Suite 2] Testing Idempotency Key Duplicate Submission Protection...');

    const beforeCount = engine.getStateSnapshot().state.transactions.length;
    const idemKey = 'IDEM_UNIQUE_BILL_001';

    const firstSave = await engine.createBill({
      idempotencyKey: idemKey,
      customerName: 'ลูกค้าทดสอบ Idempotency',
      discountPercent: 10,
      items: [
        { type: '2ตัวบน', number: '07', amount: 500 },
        { type: '3ตัวตรง', number: '007', amount: 200 },
      ],
    });

    assert(firstSave.success === true && firstSave.duplicate === false, 'First submission must succeed');
    const afterFirstCount = engine.getStateSnapshot().state.transactions.length;
    assert(afterFirstCount === beforeCount + 2, 'First submission must add exactly 2 transaction rows');

    // Duplicate retry with exact same idempotencyKey
    const secondSave = await engine.createBill({
      idempotencyKey: idemKey,
      customerName: 'ลูกค้าทดสอบ Idempotency',
      discountPercent: 10,
      items: [
        { type: '2ตัวบน', number: '07', amount: 500 },
        { type: '3ตัวตรง', number: '007', amount: 200 },
      ],
    });

    assert(
      secondSave.success === true && secondSave.duplicate === true,
      'Second submission with same idempotencyKey must be flagged as duplicate'
    );
    const afterSecondCount = engine.getStateSnapshot().state.transactions.length;
    assert(
      afterSecondCount === afterFirstCount,
      'Duplicate submission must NOT insert duplicate rows'
    );
    assert(
      secondSave.billId === firstSave.billId,
      'Duplicate submission must return the original billId'
    );

    console.log('  ✅ Suite 2 Passed: Idempotency Key prevents duplicate bills 100%.');

    // ------------------------------------------------------------------
    // SUITE 3: Race Condition Protection (Concurrent Submissions Mutex Lock)
    // ------------------------------------------------------------------
    console.log('\n[Suite 3] Testing Concurrent Race Condition Mutex Lock (5 simultaneous bills)...');

    // Number '09' in '2ตัวบน' has default maxRisk = 20,000.
    // Let's fire 5 concurrent bills of 5,000 each (total = 25,000) at the exact same millisecond.
    const concurrentPromises = [1, 2, 3, 4, 5].map((i) =>
      engine.createBill({
        idempotencyKey: `IDEM_RACE_09_${i}`,
        customerName: `สายส่งพร้อมกัน #${i}`,
        items: [{ type: '2ตัวบน', number: '09', amount: 5000 }],
      })
    );

    const concurrentResults = await Promise.all(concurrentPromises);
    concurrentResults.forEach((r, idx) => {
      assert(r.success === true, `Concurrent request #${idx + 1} must succeed`);
    });

    const all09Rows = engine
      .getStateSnapshot()
      .state.transactions.filter((t) => t.type === '2ตัวบน' && t.number === '09');
    assert(all09Rows.length === 5, 'All 5 concurrent bills must be recorded with distinct Bill IDs');

    const uniqueBillIds = new Set(all09Rows.map((t) => t.billId));
    assert(uniqueBillIds.size === 5, 'Concurrent bills must never collide on the same billId');

    const total09Amount = all09Rows.reduce((s, t) => s + t.amount, 0);
    const total09Keep = all09Rows.reduce((s, t) => s + t.keepAmount, 0);
    const total09Sent = all09Rows.reduce((s, t) => s + t.sentAmount, 0);

    assert(total09Amount === 25000, `Total amount for 09 must be 25,000 (got ${total09Amount})`);
    assert(
      total09Keep === 20000,
      `Mutex lock must cap total keepAmount at 20,000 (got ${total09Keep})`
    );
    assert(
      total09Sent === 5000,
      `Mutex lock must route excess 5,000 to sentAmount (got ${total09Sent})`
    );

    console.log(
      '  ✅ Suite 3 Passed: Promise Mutex Lock serialized 5 concurrent requests with 0 race condition leakage.'
    );

    // ------------------------------------------------------------------
    // SUITE 4: Server-side Bill Edit, Delete & Audit Log Trail
    // ------------------------------------------------------------------
    console.log('\n[Suite 4] Testing Server-side Bill Edit, Delete & Audit Log...');

    const firstRaceBillId = all09Rows[0].billId;
    // Edit the first bill from 5,000 down to 2,000 -> total becomes 22,000 (keep 20,000, sent 2,000)
    const editRes = await engine.editBill({
      billId: firstRaceBillId,
      customerName: 'สายส่งพร้อมกัน #1 (แก้ไข)',
      discountPercent: 5,
      items: [{ originalIndex: 0, type: '2ตัวบน', number: '09', amount: 2000 }],
    });
    assert(editRes.success === true, 'Server bill edit must succeed');

    const rowsAfterEdit = engine
      .getStateSnapshot()
      .state.transactions.filter((t) => t.type === '2ตัวบน' && t.number === '09');
    const keepAfterEdit = rowsAfterEdit.reduce((s, t) => s + t.keepAmount, 0);
    const sentAfterEdit = rowsAfterEdit.reduce((s, t) => s + t.sentAmount, 0);
    assert(keepAfterEdit === 20000 && sentAfterEdit === 2000, 'Risk must reconcile after server edit');

    // Delete the first bill (2,000) -> remaining 4 bills = 20,000 (keep 20,000, sent 0)
    const delRes = await engine.deleteBill(firstRaceBillId);
    assert(delRes.success === true, 'Server bill delete must succeed');

    const rowsAfterDel = engine
      .getStateSnapshot()
      .state.transactions.filter((t) => t.type === '2ตัวบน' && t.number === '09');
    const keepAfterDel = rowsAfterDel.reduce((s, t) => s + t.keepAmount, 0);
    const sentAfterDel = rowsAfterDel.reduce((s, t) => s + t.sentAmount, 0);
    assert(keepAfterDel === 20000 && sentAfterDel === 0, 'Risk must reconcile after server delete');

    const auditLogs = engine.getStateSnapshot().state.auditLogs;
    assert(
      auditLogs.some((a) => a.action === 'CREATE_BILL') &&
        auditLogs.some((a) => a.action === 'EDIT_BILL') &&
        auditLogs.some((a) => a.action === 'DELETE_BILL'),
      'Audit log must record CREATE_BILL, EDIT_BILL, and DELETE_BILL actions'
    );

    console.log('  ✅ Suite 4 Passed: Server Edit, Delete, Risk Reconciliation & Audit Trail verified.');

    // ------------------------------------------------------------------
    // SUITE 5: Data Integrity Validation, Checksum & Backup/Restore
    // ------------------------------------------------------------------
    console.log('\n[Suite 5] Testing Data Integrity Validation, Checksum & Backup/Restore...');

    const snapBeforeBackup = engine.getStateSnapshot();
    assert(snapBeforeBackup.integrity.isValid === true, 'Current database state must pass integrity check');
    assert(
      snapBeforeBackup.integrity.checksum.startsWith('CHK-'),
      'Integrity report must include FNV-1a checksum'
    );

    const backupPayload = engine.exportBackup();
    const verifyClean = verifySystemBackupPayload(backupPayload);
    assert(verifyClean.isValid === true, 'Exported backup payload must pass verification');

    // Tamper with backup checksum -> must fail verification
    const tamperedBackup = {
      ...backupPayload,
      checksum: 'CHK-DEADBEEF',
    };
    const verifyTampered = verifySystemBackupPayload(tamperedBackup);
    assert(
      verifyTampered.isValid === false && Boolean(verifyTampered.error?.includes('Checksum')),
      'Tampered backup checksum must be rejected'
    );

    // Corrupt a transaction's keepAmount + sentAmount !== amount -> must fail integrity check
    const corruptedData = structuredClone(backupPayload.data);
    corruptedData.transactions[0].keepAmount = 999999;
    const corruptedBackup = {
      ...backupPayload,
      checksum: computeDataChecksum(corruptedData),
      data: corruptedData,
    };
    const verifyCorrupted = verifySystemBackupPayload(corruptedBackup);
    assert(
      verifyCorrupted.isValid === false &&
        Boolean(verifyCorrupted.error?.includes('ไม่เท่ากับยอดซื้อ')),
      'Corrupted keepAmount + sentAmount split must be caught by Data Integrity validator'
    );

    // Mutate state, then restore from valid backupPayload
    await engine.deleteBill('B001');
    const restoreRes = await engine.restoreBackup(backupPayload);
    assert(restoreRes.success === true, 'Valid backup restore must succeed');
    assert(
      Boolean(restoreRes.preRestoreBackupFile),
      'Restore must automatically create a pre-restore backup file on disk'
    );
    assert(
      engine.getStateSnapshot().state.transactions.some((t) => t.billId === 'B001'),
      'Restored state must recover deleted bill B001'
    );

    console.log('  ✅ Suite 5 Passed: Checksum, Data Integrity Validation & Backup/Restore verified.');

    console.log('\n================================================================');
    console.log('🎉 ALL 5 PHASE 4 SUITES PASSED 100% WITH ZERO ERRORS!');
    console.log('================================================================');
  } finally {
    // Clean up temporary test DB file and pre-restore backups created during test
    if (fs.existsSync(tempDbPath)) {
      fs.unlinkSync(tempDbPath);
    }
  }
}

runPhase4Verification().catch((err) => {
  console.error(err);
  process.exit(1);
});
