export type LotteryType = '3ตัวตรง' | '3ตัวโต๊ด' | '2ตัวบน' | '2ตัวล่าง' | 'วิ่งบน' | 'วิ่งล่าง';

export type RiskStatus = 'ปกติ' | 'อั้นจ่าย' | 'ปิดรับ';

export interface ConfigRule {
  type: string; // '3ตัวตรง', '2ตัวบน', etc.
  number: string; // '*' or specific number like '83', '538', '999'
  payoutRate: number; // e.g. 90, 45, 900, 450, 0
  maxRisk: number; // max risk amount e.g. 20000, 2000, 0
  status: RiskStatus;
}

export interface Transaction {
  id?: string; // Unique row Transaction ID (e.g. TX_...)
  idempotencyKey?: string; // Idempotency guard key per bill submission
  timestamp: string; // '2026-11-01 11:00:00'
  updatedAt?: string;
  billId: string;    // 'B001'
  customerName: string;
  type: string;
  number: string;
  amount: number;
  payoutRate?: number; // อัตราจ่าย ณ เวลารับรายการ (Historical Payout Rate Snapshot)
  status: RiskStatus;
  sentAmount: number; // ตีเกิน/ส่งต่อ
  keepAmount: number; // ถือเอง
  discountPercent?: number; // ส่วนลด % ค่าโพย เช่น 10, 15
  drawPeriod?: string; // งวดประจำวันที่ เช่น 'งวด 16 พ.ย. 2569'
}

export interface SummaryRisk {
  type: string;
  number: string;
  totalAmount: number;
  maxRiskLimit: number;
  overLimitAmount: number;
  keepAmount: number;
  sentAmount: number;
  payoutRate: number;
  potentialPayout: number; // keepAmount * payoutRate
  estimatedProfitIfDrawn: number; // categoryRevenue - potentialPayout
  status: RiskStatus;
}

export interface BasketItem {
  id: string;
  type: string;
  number: string;
  amount: number;
  payoutRate: number;
  status: RiskStatus;
  sentAmount: number;
  keepAmount: number;
  note?: string;
}

export interface ArchivedDraw {
  id: string;
  drawPeriod: string;
  archivedAt: string;
  isLocked?: boolean; // ล็อกข้อมูลงวดที่ปิดแล้ว ห้ามแก้ไขโดยไม่ได้รับอนุญาต
  winningTop3: string;
  winningBottom2: string;
  totalGrossSales: number;
  totalNetSales: number;
  totalKeepAmount: number;
  totalSentAmount: number;
  transactionsCount: number;
  billsCount: number;
  transactions: Transaction[];
}

export interface CustomerProfile {
  id: string;
  name: string;
  phone?: string;
  defaultDiscountPercent: number; // ส่วนลดค่าโพยเริ่มต้น (%) เช่น 0, 10, 15
  creditLimit?: number; // วงเงินเครดิตสูงสุด (0 = ไม่จำกัด)
  note?: string;
  createdAt: string;
}

export type SettlementPaymentStatus = 'รอเคลียร์ยอด' | 'เคลียร์แล้ว' | 'ค้างชำระ';

export interface BillPaymentRecord {
  billId: string;
  drawPeriod: string;
  status: SettlementPaymentStatus;
  paidAmount: number;
  updatedAt: string;
  note?: string;
}

export type InputMode = 'number' | 'amount';

export interface SoundSettings {
  enabled: boolean;        // เปิด/ปิดเสียงทั้งหมด (Master switch)
  volume: number;          // ระดับความดัง 0 - 100
  onBillSaved: boolean;    // เสียงเตือนเมื่อบันทึกบิลสำเร็จ
  onHalfPayAlert: boolean; // เสียงเตือนเมื่อคีย์เลขที่อยู่ในสถานะอั้นจ่าย
  onClosedAlert: boolean;  // เสียงเตือนเมื่อคีย์เลขปิดรับ/เต็มเพดาน
  onKeyPress: boolean;     // เสียงกดปุ่มแป้นตัวเลข Numpad
}

export type AuditActionType =
  | 'CREATE_BILL'
  | 'EDIT_BILL'
  | 'DELETE_BILL'
  | 'UPSERT_CONFIG'
  | 'DELETE_CONFIG'
  | 'RESET_CONFIGS'
  | 'UPSERT_CUSTOMER'
  | 'DELETE_CUSTOMER'
  | 'ARCHIVE_DRAW'
  | 'RESTORE_BACKUP'
  | 'PAYMENT_STATUS_UPDATE';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: AuditActionType;
  actor: string;
  targetId: string;
  summary: string;
  idempotencyKey?: string;
  metadata?: Record<string, unknown>;
}

export type SyncStatusType = 'synced' | 'syncing' | 'offline' | 'error';

export interface OfflineQueueAction {
  id: string;
  idempotencyKey: string;
  endpoint: string;
  method: 'POST' | 'PUT' | 'DELETE';
  payload: unknown;
  createdAt: string;
  retryCount: number;
}

export interface DataIntegrityIssue {
  severity: 'error' | 'warning';
  code: string;
  message: string;
  entityId?: string;
}

export interface DataIntegrityReport {
  isValid: boolean;
  checkedAt: string;
  totalTransactions: number;
  totalConfigs: number;
  totalCustomers: number;
  totalArchivedDraws: number;
  checksum: string;
  issues: DataIntegrityIssue[];
}

export interface SystemBackupPayload {
  version: string;
  exportedAt: string;
  checksum: string;
  data: {
    configs: ConfigRule[];
    transactions: Transaction[];
    customers: CustomerProfile[];
    archivedDraws: ArchivedDraw[];
    paymentRecords: Record<string, BillPaymentRecord>;
    auditLogs: AuditLogEntry[];
  };
}



