/**
 * =========================================================================
 * LOTTERY POS BACKEND - Google Apps Script (Code.gs) v4.0
 * เชื่อมต่อ Google Sheets: Config_Settings, Transactions, Summary_Risk, Audit_Log
 * รองรับ Server-side Validation, Idempotency Key, Historical PayoutRate และ Webhook Sync
 * =========================================================================
 */

/**
 * แสดงผลหน้า WebApp เมื่อเปิดผ่านเบราว์เซอร์บนมือถือ
 */
function doGet(e) {
  var template = HtmlService.createTemplateFromFile('Index');
  return template.evaluate()
    .setTitle('Lottery POS - ระบบจดรับเดิมพันหวยมือถือ')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * รองรับการเชื่อมต่อจาก Express Backend Server ผ่าน HTTP POST (doPost)
 */
function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents || '{}');
    var action = body.action || '';
    var payload = body.payload || {};

    if (action === 'CREATE_BILL' && payload.createdTransactions) {
      var res = saveTransactions({
        billId: payload.billId,
        idempotencyKey: (payload.createdTransactions[0] && payload.createdTransactions[0].idempotencyKey) || ('IDEM_' + payload.billId),
        customerName: (payload.createdTransactions[0] && payload.createdTransactions[0].customerName) || 'ลูกค้าทั่วไป',
        items: payload.createdTransactions
      });
      return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
    }

    appendAuditSheetLog(action || 'WEBHOOK_EVENT', payload.billId || 'SYSTEM', JSON.stringify(payload));
    return ContentService.createTextOutput(JSON.stringify({ success: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ success: false, error: err.message })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * บันทึกประวัติการทำงานลงในชีต Audit_Log
 */
function appendAuditSheetLog(action, targetId, summary, idempotencyKey) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var auditSheet = ss.getSheetByName('Audit_Log');
  if (!auditSheet) {
    auditSheet = ss.insertSheet('Audit_Log');
    auditSheet.appendRow(['Timestamp', 'Action', 'Target_ID', 'Summary', 'Idempotency_Key']);
  }
  var nowStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
  auditSheet.appendRow([nowStr, action, targetId, summary, idempotencyKey || '']);
}

/**
 * ดึงการตั้งค่า Config_Settings และยอดรวมความเสี่ยงปัจจุบันจาก Google Sheets
 */
function getSettings() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var configSheet = ss.getSheetByName('Config_Settings');
    if (!configSheet) {
      configSheet = initializeConfigSheet(ss);
    }

    var configData = configSheet.getDataRange().getValues();
    var configs = [];
    for (var i = 1; i < configData.length; i++) {
      var row = configData[i];
      if (row[0] !== '') {
        configs.push({
          type: String(row[0]).trim(),
          number: String(row[1]).replace(/^'/, '').trim(),
          payoutRate: Number(row[2]) || 0,
          maxRisk: Number(row[3]) || 0,
          status: String(row[4] || 'ปกติ').trim()
        });
      }
    }

    var transSheet = ss.getSheetByName('Transactions');
    var riskAccumulation = {};
    var lastBillNumber = 0;

    if (transSheet && transSheet.getLastRow() > 1) {
      var transData = transSheet.getDataRange().getValues();
      for (var j = 1; j < transData.length; j++) {
        var tRow = transData[j];
        var billId = String(tRow[1] || '');
        if (billId.startsWith('B')) {
          var bNum = parseInt(billId.replace('B', ''), 10);
          if (!isNaN(bNum) && bNum > lastBillNumber) {
            lastBillNumber = bNum;
          }
        }
        var tType = String(tRow[3]).trim();
        var tNum = String(tRow[4]).replace(/^'/, '').trim();
        var tAmt = Number(tRow[5]) || 0;
        var tStatus = String(tRow[6] || 'ปกติ').trim();
        if (tStatus !== 'ปิดรับ') {
          var key = tType + '_' + tNum;
          riskAccumulation[key] = (riskAccumulation[key] || 0) + tAmt;
        }
      }
    }

    var nextBillId = 'B' + ('000' + (lastBillNumber + 1)).slice(-3);

    return {
      success: true,
      configs: configs,
      riskAccumulation: riskAccumulation,
      nextBillId: nextBillId,
      timestamp: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss')
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * บันทึกรายการบิลลงชีต Transactions พร้อม Server-side Validation, Idempotency Key และ Audit_Log
 */
function saveTransactions(payload) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(10000);
  } catch (e) {
    return { success: false, error: 'ระบบกำลังประมวลผลบิลอื่นอยู่ กรุณาลองใหม่อีกครั้ง' };
  }

  try {
    if (!payload || !payload.items || !payload.items.length) {
      throw new Error('ไม่พบรายการเดิมพันในบิล');
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var transSheet = ss.getSheetByName('Transactions');
    if (!transSheet) {
      transSheet = ss.insertSheet('Transactions');
      transSheet.appendRow([
        'Timestamp',
        'Bill_ID',
        'Customer_Name',
        'Type',
        'Number',
        'Amount',
        'Status',
        'Sent_Amount',
        'Keep_Amount',
        'Payout_Rate',
        'Idempotency_Key'
      ]);
    }

    var idemKey = String(payload.idempotencyKey || ('IDEM_' + payload.billId));

    // 1. ตรวจสอบ Idempotency Key ป้องกันการบันทึกบิลซ้ำ
    if (transSheet.getLastRow() > 1) {
      var existingRows = transSheet.getDataRange().getValues();
      for (var k = 1; k < existingRows.length; k++) {
        if (String(existingRows[k][10] || '') === idemKey) {
          lock.releaseLock();
          return {
            success: true,
            duplicate: true,
            message: 'บิลนี้ถูกบันทึกไปแล้ว (Idempotency Protected)',
            billId: existingRows[k][1]
          };
        }
      }
    }

    var nowStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
    var rowsToInsert = [];

    for (var i = 0; i < payload.items.length; i++) {
      var it = payload.items[i];
      if (it.status === 'ปิดรับ') {
        throw new Error('ไม่สามารถบันทึกเลขที่อยู่ในสถานะปิดรับแทง (' + it.number + ')');
      }
      var numStr = String(it.number || '').replace(/\D/g, '');
      rowsToInsert.push([
        nowStr,
        payload.billId,
        payload.customerName || 'ลูกค้าทั่วไป',
        it.type,
        "'" + numStr,
        Number(it.amount) || 0,
        it.status || 'ปกติ',
        Number(it.sentAmount) || 0,
        Number(it.keepAmount) || 0,
        Number(it.payoutRate) || 0,
        idemKey
      ]);
    }

    transSheet.getRange(transSheet.getLastRow() + 1, 1, rowsToInsert.length, 11).setValues(rowsToInsert);
    updateSummaryRiskSheet(ss);
    appendAuditSheetLog('CREATE_BILL', payload.billId, 'บันทึกบิล ' + payload.billId + ' จำนวน ' + rowsToInsert.length + ' รายการ', idemKey);

    lock.releaseLock();
    return {
      success: true,
      message: 'บันทึกบิล ' + payload.billId + ' สำเร็จเรียบร้อย',
      billId: payload.billId,
      count: rowsToInsert.length,
      timestamp: nowStr
    };
  } catch (error) {
    lock.releaseLock();
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * คำนวณยอดสรุปความเสี่ยงใหม่ทั้งหมดจาก Transactions และ Config_Settings
 */
function updateSummaryRiskSheet(ss) {
  var transSheet = ss.getSheetByName('Transactions');
  var configSheet = ss.getSheetByName('Config_Settings');
  var summarySheet = ss.getSheetByName('Summary_Risk');

  if (!summarySheet) {
    summarySheet = ss.insertSheet('Summary_Risk');
  }

  var configsMap = {};
  var defaultsMap = {};
  if (configSheet && configSheet.getLastRow() > 1) {
    var cData = configSheet.getDataRange().getValues();
    for (var c = 1; c < cData.length; c++) {
      var cType = String(cData[c][0]).trim();
      var cNum = String(cData[c][1]).replace(/^'/, '').trim();
      var maxRisk = Number(cData[c][3]) || 0;
      if (cNum === '*') {
        defaultsMap[cType] = maxRisk;
      } else {
        configsMap[cType + '_' + cNum] = maxRisk;
      }
    }
  }

  var summaryMap = {};
  var categoryKeepMap = {};
  if (transSheet && transSheet.getLastRow() > 1) {
    var tData = transSheet.getDataRange().getValues();
    for (var t = 1; t < tData.length; t++) {
      var type = String(tData[t][3]).trim();
      var num = String(tData[t][4]).replace(/^'/, '').trim();
      var amount = Number(tData[t][5]) || 0;
      var status = String(tData[t][6] || 'ปกติ').trim();
      var sent = Number(tData[t][7]) || 0;
      var keep = Number(tData[t][8]) || 0;
      var txRate = Number(tData[t][9]) || 0;
      if (status === 'ปิดรับ') continue;

      var key = type + '_' + num;
      if (!summaryMap[key]) {
        var limit = (configsMap[key] !== undefined) ? configsMap[key] : (defaultsMap[type] !== undefined ? defaultsMap[type] : 20000);
        summaryMap[key] = {
          type: type,
          number: num,
          totalAmount: 0,
          keepAmount: 0,
          sentAmount: 0,
          potentialPayout: 0,
          maxRiskLimit: limit
        };
      }
      summaryMap[key].totalAmount += amount;
      summaryMap[key].keepAmount += keep;
      summaryMap[key].sentAmount += sent;
      if (txRate > 0) {
        summaryMap[key].potentialPayout += keep * txRate;
      }
      categoryKeepMap[type] = (categoryKeepMap[type] || 0) + keep;
    }
  }

  var summaryRows = [
    ['Type', 'Number', 'Total_Amount', 'Max_Risk_Limit', 'Over_Limit_Amount', 'Keep_Amount', 'Payout_Rate', 'Potential_Payout', 'Estimated_Profit']
  ];

  for (var k in summaryMap) {
    var item = summaryMap[k];
    var overLimit = Math.max(0, item.totalAmount - item.maxRiskLimit);
    var rate = 90;
    var confSheet = ss.getSheetByName('Config_Settings');
    if (confSheet && confSheet.getLastRow() > 1) {
      var cRows = confSheet.getDataRange().getValues();
      for (var r = 1; r < cRows.length; r++) {
        var ct = String(cRows[r][0]).trim();
        var cn = String(cRows[r][1]).replace(/^'/, '').trim();
        if (ct === item.type && (cn === item.number || cn === '*')) {
          rate = Number(cRows[r][2]) || 0;
          if (cn === item.number) break;
        }
      }
    }

    var potentialPayout = item.potentialPayout > 0 ? item.potentialPayout : (item.keepAmount * rate);
    var catRev = categoryKeepMap[item.type] || 0;
    var estProfit = catRev - potentialPayout;

    summaryRows.push([
      item.type,
      "'" + item.number,
      item.totalAmount,
      item.maxRiskLimit,
      overLimit,
      item.keepAmount,
      rate,
      potentialPayout,
      estProfit
    ]);
  }

  summarySheet.clearContents();
  summarySheet.getRange(1, 1, summaryRows.length, 9).setValues(summaryRows);
}

/**
 * สร้างชีต Config_Settings เริ่มต้นตามข้อมูลตัวอย่าง
 */
function initializeConfigSheet(ss) {
  var sheet = ss.insertSheet('Config_Settings');
  var initialData = [
    ['Type', 'Number', 'PayoutRate', 'MaxRisk', 'Status'],
    ['3ตัวตรง', '*', 900, 5000, 'ปกติ'],
    ['3ตัวโต๊ด', '*', 150, 10000, 'ปกติ'],
    ['2ตัวบน', '*', 90, 20000, 'ปกติ'],
    ['2ตัวล่าง', '*', 90, 20000, 'ปกติ'],
    ['วิ่งบน', '*', 3.2, 50000, 'ปกติ'],
    ['วิ่งล่าง', '*', 4.2, 50000, 'ปกติ'],
    ['2ตัวบน', "'83", 45, 2000, 'อั้นจ่าย'],
    ['2ตัวล่าง', "'73", 45, 2000, 'อั้นจ่าย'],
    ['3ตัวตรง', "'538", 450, 500, 'อั้นจ่าย'],
    ['3ตัวตรง', "'999", 0, 0, 'ปิดรับ']
  ];
  sheet.getRange(1, 1, initialData.length, 5).setValues(initialData);
  return sheet;
}
