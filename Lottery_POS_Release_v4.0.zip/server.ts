import 'dotenv/config';
import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { LotteryServerEngine } from './src/server/dbService';

const PORT = 3000;
const engine = new LotteryServerEngine();

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // 1. Health & Authoritative State Snapshot
  app.get('/api/state', (_req, res) => {
    const snapshot = engine.getStateSnapshot();
    res.json({
      success: true,
      serverTime: new Date().toISOString(),
      ...snapshot,
    });
  });

  // 2. Create Bill (Server-side Validation, Idempotency Key, Mutex Lock, Audit Log)
  app.post('/api/bills', async (req, res) => {
    try {
      const result = await engine.createBill(req.body || {});
      if (!result.success) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err instanceof Error ? err.message : 'Server Error while saving bill',
      });
    }
  });

  // 3. Edit Bill (Server-side Validation, Risk Reconciliation, Audit Log)
  app.put('/api/bills/:billId', async (req, res) => {
    try {
      const result = await engine.editBill({
        billId: req.params.billId,
        customerName: req.body?.customerName || 'ลูกค้าทั่วไป',
        discountPercent: Number(req.body?.discountPercent) || 0,
        items: req.body?.items || [],
        actor: req.body?.actor,
      });
      if (!result.success) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err instanceof Error ? err.message : 'Server Error while editing bill',
      });
    }
  });

  // 4. Delete / Cancel Bill
  app.delete('/api/bills/:billId', async (req, res) => {
    try {
      const result = await engine.deleteBill(req.params.billId);
      if (!result.success) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err instanceof Error ? err.message : 'Server Error while deleting bill',
      });
    }
  });

  // 5. Update Risk / Payout Config Rules
  app.post('/api/configs', async (req, res) => {
    try {
      const result = await engine.updateConfigs(req.body || {});
      if (!result.success) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err instanceof Error ? err.message : 'Server Error while updating configs',
      });
    }
  });

  // 6. Sync Customers, Archived Draws, Payment Records, Market Status & Period Lock
  app.post('/api/sync-meta', async (req, res) => {
    try {
      const result = await engine.syncMetadata(req.body || {});
      res.json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err instanceof Error ? err.message : 'Server Error while syncing metadata',
      });
    }
  });

  // 7. Export Full Checksummed Backup JSON
  app.get('/api/backup', (_req, res) => {
    const backup = engine.exportBackup();
    res.json({
      success: true,
      backup,
    });
  });

  // 8. Verify & Restore Backup JSON (Creates pre-restore backup automatically)
  app.post('/api/restore', async (req, res) => {
    try {
      const payload = req.body?.backup || req.body;
      const result = await engine.restoreBackup(payload);
      if (!result.success) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err instanceof Error ? err.message : 'Server Error while restoring backup',
      });
    }
  });

  // Mount Vite in development or static dist in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Lottery POS Server] Listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
