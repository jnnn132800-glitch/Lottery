# คู่มือการสำรองและกู้คืนข้อมูล (Backup & Restore Manual)

เอกสารฉบับนี้อธิบายขั้นตอนการสำรองข้อมูล (Backup) การตรวจสอบความสมบูรณ์ของข้อมูล (Data Integrity Checksum) และการกู้คืนข้อมูล (Restore) สำหรับระบบ **Lottery POS & Risk Management System v4.0**

---

## 1. โครงสร้างการจัดเก็บข้อมูลหลัก (Authoritative Storage Architecture)

1. **ฐานข้อมูลหลักฝั่ง Server (`/data/lottery_db.json`)**:
   - บันทึกข้อมูลแบบ Atomic Write (`lottery_db.json.tmp` -> `lottery_db.json`) ป้องกันไฟล์เสียหายกรณีไฟดับหรือเซิร์ฟเวอร์ปิดกะทันหัน
   - เก็บข้อมูลครบทุกส่วน: `configs`, `transactions`, `customers`, `archivedDraws`, `paymentRecords`, `auditLogs`, และ `processedIdempotencyKeys`
2. **ระบบสำรองอัตโนมัติก่อนกู้คืน (`/data/backups/pre_restore_<timestamp>.json`)**:
   - ทุกครั้งที่มีการสั่งกู้คืนข้อมูล (Restore) ระบบจะสำรองฐานข้อมูลปัจจุบันลงโฟลเดอร์ `/data/backups/` และ `localStorage` (`lottery_pre_restore_snapshot`) อัตโนมัติก่อนเขียนทับเสมอ
3. **ระบบคิวออฟไลน์ (`lottery_offline_queue` ใน `localStorage`)**:
   - หากอินเทอร์เน็ตหรือการเชื่อมต่อ Server ขัดข้องชั่วคราวขณะรับโพย ระบบจะเก็บรายการไว้ใน Offline Queue พร้อม `idempotencyKey` และซิงก์เข้า Server อัตโนมัติทันทีที่ออนไลน์ โดยไม่เกิดบิลซ้ำ

---

## 2. วิธีสำรองฐานข้อมูลทั้งระบบ (Full System JSON Backup)

### วิธีที่ 1: สำรองผ่านหน้าเว็บแอป (แนะนำ)
1. ไปที่แท็บ **ตั้งค่า (Settings)** (ไอคอนฟันเฟือง)
2. เลื่อนลงไปที่หมวด **"สำรองและกู้คืนฐานข้อมูล & ตรวจสอบความสมบูรณ์ (Backup, Restore & Integrity)"**
3. ตรวจสอบสถานะความสมบูรณ์ข้อมูลว่าแสดง **`สมบูรณ์ 100% (Valid)`** พร้อมรหัส Checksum เช่น `CHK-XXXXXXXX`
4. กดปุ่ม **"สำรองฐานข้อมูล (Backup JSON)"**
5. ระบบจะดาวน์โหลดไฟล์ `LotteryPOS_Backup_YYYY-MM-DD.json` ลงเครื่องทันที

### วิธีที่ 2: สำรองผ่าน HTTP API
```bash
curl -s http://localhost:3000/api/backup -o LotteryPOS_Backup.json
```

---

## 3. วิธีกู้คืนข้อมูลจากไฟล์สำรอง (Restore System Backup)

1. ไปที่แท็บ **ตั้งค่า (Settings)**
2. เลื่อนลงไปที่หมวด **"สำรองและกู้คืนฐานข้อมูล & ตรวจสอบความสมบูรณ์ (Backup, Restore & Integrity)"**
3. กดปุ่ม **"กู้คืนจากไฟล์สำรอง (Restore JSON)"** และเลือกไฟล์ `.json` ที่สำรองไว้
4. ระบบจะดำเนินการตรวจสอบ 3 ขั้นตอนอัตโนมัติก่อนกู้คืน:
   - **ขั้นตอนที่ 1 (Schema Verification)**: ตรวจสอบโครงสร้างไฟล์ JSON ว่าครบถ้วน
   - **ขั้นตอนที่ 2 (Checksum Verification)**: คำนวณรหัส FNV-1a 32-bit Checksum เทียบกับค่า `checksum` ในไฟล์ หากไฟล์ถูกดัดแปลงแก้ไขจากภายนอก ระบบจะปฏิเสธการนำเข้าทันที
   - **ขั้นตอนที่ 3 (Data Integrity Validation)**: ตรวจสอบทุกแถวของรายการเดิมพันว่ารูปแบบตัวเลข (`00`–`99`, `000`–`999`) ถูกต้อง และยอด `keepAmount + sentAmount === amount` ตรงกัน 100%
5. เมื่อผ่านการตรวจสอบ ระบบจะสร้างไฟล์สำรองของข้อมูลเดิมไว้ที่ `/data/backups/pre_restore_<timestamp>.json` ก่อนกู้คืนข้อมูลใหม่เข้าสู่ระบบทันที

---

## 4. การส่งออกไฟล์ CSV รายหมวด (สำหรับเปิดใน Microsoft Excel / Google Sheets)

นอกจากการสำรองทั้งระบบแบบ JSON แล้ว ผู้ใช้ยังสามารถส่งออกรายงาน CSV (เข้ารหัส UTF-8 with BOM รองรับภาษาไทยและเลขศูนย์นำหน้า) ได้ทุกหน้า:
- **แท็บ บิล (`Transactions`)**: ปุ่ม `ส่งออก Transactions.csv`
- **แท็บ ความเสี่ยง (`Risk Summary`)**: ปุ่ม `ส่งออก Summary_Risk.csv` และ `Export ใบส่งต่อ CSV` (`Forwarding_Upstream_Sheet.csv`)
- **แท็บ ตั้งค่า (`Settings`)**: ปุ่ม `ส่งออก CSV` (`Config_Settings.csv`) และปุ่ม `ส่งออก CSV` ของแต่ละงวดที่ปิดแล้วในคลังประวัติ (`Archive_<ชื่องวด>.csv`)
