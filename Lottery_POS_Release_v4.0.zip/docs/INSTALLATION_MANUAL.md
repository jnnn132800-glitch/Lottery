# คู่มือการติดตั้งและใช้งานระบบ Lottery POS & Risk Management (v4.0)

เอกสารฉบับนี้อธิบายขั้นตอนการติดตั้ง ตั้งค่า และรันระบบ **Lottery POS & Risk Management System v4.0** ทั้งในรูปแบบ **Full-Stack Node.js + Express + React Server** และรูปแบบเชื่อมต่อ **Google Sheets + Google Apps Script (`Code.gs` v4.0)**

---

## 1. ความต้องการของระบบ (System Requirements)

- **Node.js**: เวอร์ชัน `20.x` หรือ `22.x` ขึ้นไป
- **NPM**: เวอร์ชัน `10.x` ขึ้นไป
- **อุปกรณ์ปลายทาง (Client Browser)**:
  - รองรับสมาร์ทโฟน Android / iOS ทุกขนาดหน้าจอ โดยเฉพาะ **Samsung Galaxy S22 5G** (6.1" Dynamic AMOLED 2X, ความละเอียด FHD+ `1080×2340` / Viewport `360×780px`, อัตรารีเฟรช `120Hz`)
  - รองรับคอมพิวเตอร์ Desktop / Tablet ทุกรุ่น

---

## 2. ขั้นตอนการติดตั้งและรันระบบ (Full-Stack Node.js + Express Server)

### ขั้นตอนที่ 2.1: แตกไฟล์และติดตั้งแพ็กเกจ
```bash
npm install
```

### ขั้นตอนที่ 2.2: ตั้งค่าตัวแปรสภาพแวดล้อม (`.env`)
คัดลอกไฟล์ `.env.example` ไปเป็น `.env`:
```bash
cp .env.example .env
```
ภายในไฟล์ `.env` สามารถกำหนดค่า (Optional สำหรับซิงก์เข้า Google Sheets อัตโนมัติ):
```env
# URL ของ Google Apps Script Web App (หากต้องการให้ Server ซิงก์บิลเข้า Google Sheets อัตโนมัติ)
GAS_WEBAPP_URL=

# รหัสลับสำหรับยืนยันตัวตนระหว่าง Express Server กับ Google Apps Script (ไม่เปิดเผยใน Frontend)
GAS_API_SECRET=
```
> **หมายเหตุ**: แม้ไม่ได้ตั้งค่า `GAS_WEBAPP_URL` ระบบฐานข้อมูลหลักฝั่ง Server (`/data/lottery_db.json`) จะทำงานและบันทึกข้อมูลพร้อมตรวจสอบ Checksum อัตโนมัติทันที

### ขั้นตอนที่ 2.3: รันเซิร์ฟเวอร์สำหรับใช้งาน (Development / Production)
- **รันโหมดใช้งานทันที (Full-Stack Server บนพอร์ต 3000)**:
  ```bash
  npm run dev
  ```
  จากนั้นเปิดเบราว์เซอร์ไปที่ `http://localhost:3000`
- **ตรวจสอบความถูกต้องของ TypeScript และรันชุดทดสอบอัตโนมัติ (Automated QA Tests)**:
  ```bash
  npm run lint
  npm test
  ```
- **สั่ง Build สำหรับ Production**:
  ```bash
  npm run build
  npm start
  ```

---

## 3. ขั้นตอนการติดตั้งร่วมกับ Google Sheets & Google Apps Script (`Code.gs` v4.0)

1. สร้างไฟล์ **Google Sheets** ใหม่ใน Google Drive ของคุณ
2. ไปที่เมนู **Extensions (ส่วนขยาย) > Apps Script**
3. คัดลอกโค้ดจากไฟล์ `gas/Code.gs` (หรือคัดลอกจากแท็บ **Apps Script** ในหน้าเว็บแอป) ไปวางทับในไฟล์ `Code.gs`
4. สร้างไฟล์ HTML ชื่อ `Index.html` ใน Apps Script และวางโค้ดจากแท็บ **Apps Script (`Index.html`)**
5. กดปุ่ม **Deploy > New deployment**
   - เลือกชนิดเป็น **Web app**
   - **Execute as**: `Me`
   - **Who has access**: `Anyone`
6. คัดลอก **Web App URL** ที่ได้มาใส่ในไฟล์ `.env` ที่ตัวแปร `GAS_WEBAPP_URL` บนฝั่ง Server
7. ระบบจะสร้างชีตทั้ง 4 ชีตให้อัตโนมัติเมื่อมีการรับบิล:
   - `Config_Settings`: ตารางตั้งค่าเรทจ่ายและเพดานความเสี่ยง
   - `Transactions`: ตารางรายการบิลทั้งหมด (เก็บเลขเป็น String นำหน้าด้วย `'` เพื่อรักษาเลข `0` นำหน้า พร้อมคอลัมน์ `Payout_Rate` และ `Idempotency_Key`)
   - `Summary_Risk`: ตารางคำนวณความเสี่ยงและประมาณการกำไรอัตโนมัติ
   - `Audit_Log`: ตารางบันทึกประวัติการสร้าง/แก้ไข/ยกเลิกบิลทุกขั้นตอน
